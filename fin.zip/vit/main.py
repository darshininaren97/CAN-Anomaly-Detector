"""
main.py
Unified Command-Line Application for CAN Bus Anomaly Detection.

Usage:
  python main.py --dbc CAN.dbc --log CAN.log.txt
  python main.py --dbc CAN.dbc --log CAN.log.txt --format json --output results.json
  python main.py --dbc CAN.dbc --log CAN.log.txt --format csv --output results.csv
  python main.py --dbc CAN.dbc --log CAN.log.txt --detectors range,logic,timing
  python main.py --dbc CAN.dbc --log CAN.log.txt --verbose
"""

from __future__ import annotations
import argparse
import logging
import os
import sys
from pathlib import Path
from typing import List, Optional

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.pipeline import PipelineConfig, UnifiedAnomalyPipeline
from detectors.registry import DetectorRegistry

# Exit codes
EXIT_SUCCESS = 0
EXIT_GENERAL_ERROR = 1
EXIT_INVALID_ARGS = 2
EXIT_FILE_NOT_FOUND = 3
EXIT_DBC_ERROR = 4
EXIT_LOG_ERROR = 5
EXIT_OUTPUT_ERROR = 6


def setup_logging(verbose: bool = False) -> None:
    """Configure console logging level and format."""
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
        force=True,
    )


def parse_arguments(args: Optional[List[str]] = None) -> argparse.Namespace:
    """Parse and validate command line arguments."""
    available_detectors = ", ".join(DetectorRegistry.get_available_keys()) + ", or 'all'"

    parser = argparse.ArgumentParser(
        description="Unified Automotive CAN Bus Anomaly Detection Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
Available Detector Modules:
  {available_detectors}

Examples:
  python main.py --dbc CAN.dbc --log CAN.log.txt
  python main.py --dbc CAN.dbc --log CAN.log.txt --format json --output report.json
  python main.py --dbc CAN.dbc --log CAN.log.txt --format csv --output report.csv
  python main.py --dbc CAN.dbc --log CAN.log.txt --detectors range,logic,timing
  python main.py --dbc CAN.dbc --log CAN.log.txt --verbose
        """,
    )

    parser.add_argument(
        "--dbc",
        type=str,
        required=True,
        help="Path to automotive DBC definition file (e.g. CAN.dbc)",
    )
    parser.add_argument(
        "--log",
        type=str,
        required=True,
        help="Path to CAN log file (Vector ASC, plain text, or JSON)",
    )
    parser.add_argument(
        "--detectors",
        type=str,
        default="all",
        help=f"Comma-separated list of detectors to execute (default: all). Options: {available_detectors}",
    )
    parser.add_argument(
        "--output",
        "-o",
        type=str,
        default=None,
        help="Optional destination path to write the formatted anomaly report file",
    )
    parser.add_argument(
        "--format",
        "-f",
        choices=["text", "json", "csv"],
        default="text",
        help="Output report format (default: text)",
    )
    parser.add_argument(
        "--export-parsed-csv",
        "--parsed-csv",
        dest="export_parsed_csv",
        type=str,
        default=None,
        help="Optional destination path to export human-readable decoded CAN/DBC data in CSV format",
    )
    parser.add_argument(
        "--integrity-config",
        type=str,
        default=None,
        help="Optional path to external timing/CRC configuration JSON for CAN integrity detector",
    )
    parser.add_argument(
        "--dashboard",
        "-d",
        type=str,
        default=None,
        metavar="PATH",
        help="Optional path to write a self-contained interactive HTML signal-timeline dashboard",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable detailed diagnostic logging and tracebacks",
    )

    return parser.parse_args(args)


def run_app(args: Optional[List[str]] = None) -> int:
    """Application main execution entry point."""
    try:
        parsed_args = parse_arguments(args)
    except SystemExit as e:
        return EXIT_INVALID_ARGS if e.code != 0 else EXIT_SUCCESS

    setup_logging(verbose=parsed_args.verbose)

    # 1. Path existence and sanity checks
    for label, file_path in [("DBC", parsed_args.dbc), ("Log", parsed_args.log)]:
        if not os.path.exists(file_path):
            print(f"Error: {label} file not found: '{file_path}'", file=sys.stderr)
            return EXIT_FILE_NOT_FOUND
        if os.path.isdir(file_path):
            print(f"Error: {label} path must be a file, not a directory: '{file_path}'", file=sys.stderr)
            return EXIT_INVALID_ARGS

    if parsed_args.output and os.path.isdir(parsed_args.output):
        print(f"Error: Output path must be a file, not a directory: '{parsed_args.output}'", file=sys.stderr)
        return EXIT_INVALID_ARGS

    # 2. Build Pipeline Configuration
    config = PipelineConfig(
        dbc_path=parsed_args.dbc,
        log_path=parsed_args.log,
        detectors=parsed_args.detectors,
        output_path=parsed_args.output,
        output_format=parsed_args.format,
        export_parsed_csv_path=parsed_args.export_parsed_csv,
        integrity_config_path=parsed_args.integrity_config,
        dashboard_path=parsed_args.dashboard,
        verbose=parsed_args.verbose,
    )

    # 3. Instantiate and Run Pipeline
    try:
        pipeline = UnifiedAnomalyPipeline(config)
        result = pipeline.run()
    except ValueError as e:
        print(f"Configuration / Argument Error: {e}", file=sys.stderr)
        return EXIT_INVALID_ARGS
    except FileNotFoundError as e:
        print(f"File Error: {e}", file=sys.stderr)
        return EXIT_FILE_NOT_FOUND
    except Exception as e:
        print(f"Pipeline Runtime Error: {e}", file=sys.stderr)
        if parsed_args.verbose:
            import traceback
            traceback.print_exc()
        return EXIT_GENERAL_ERROR

    # 4. Print Report to Console
    if result.report_text:
        print(result.report_text)

    if parsed_args.output:
        print(f"\n[INFO] Anomaly report successfully exported to: {parsed_args.output}")

    if parsed_args.dashboard:
        if os.path.exists(parsed_args.dashboard):
            print(f"[INFO] Interactive HTML dashboard written to: {parsed_args.dashboard}")
        else:
            print(f"[WARN] Dashboard generation did not produce output at: {parsed_args.dashboard}", file=sys.stderr)

    return EXIT_SUCCESS


def main(args: Optional[List[str]] = None) -> int:
    """CLI entry point."""
    return run_app(args)


if __name__ == "__main__":
    main()
