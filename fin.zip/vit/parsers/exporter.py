"""
parsers/exporter.py
Human-Readable Parsed CAN and DBC Data Exporter.
Leverages can.dbc_decoder to generate detailed tabular CSV representations
of decoded CAN frames and signals.
"""

from __future__ import annotations
import sys
from pathlib import Path
from typing import Optional, Union

# Ensure can module is accessible
_CAN_DIR = Path(__file__).resolve().parent.parent / "can"
if str(_CAN_DIR) not in sys.path:
    sys.path.append(str(_CAN_DIR))

from can.dbc_decoder import decode_file, StreamingCSVWriter, DECODED_CSV_FIELDS


def export_parsed_can_csv(
    dbc_path: Union[str, Path],
    log_path: Union[str, Path],
    output_csv_path: Union[str, Path],
    include_unmatched: bool = True,
) -> int:
    """
    Decode CAN log frames against DBC database and export human-readable CSV.
    
    :param dbc_path: Path to automotive DBC definition file
    :param log_path: Path to CAN log file (Vector ASC, TXT, or JSON)
    :param output_csv_path: Destination path for decoded tabular CSV file
    :param include_unmatched: Include unmatched/unknown frames with blank signal fields
    :return: Count of processed frames
    """
    dbc_p = Path(dbc_path)
    log_p = Path(log_path)
    out_p = Path(output_csv_path)

    if not dbc_p.exists():
        raise FileNotFoundError(f"DBC file not found: {dbc_p}")
    if not log_p.exists():
        raise FileNotFoundError(f"CAN log file not found: {log_p}")

    out_p.parent.mkdir(parents=True, exist_ok=True)

    results = decode_file(
        dbc_source=dbc_p,
        frames_or_file=log_p,
        output_csv=out_p,
        include_unmatched=include_unmatched,
    )
    return len(results)
