"""
parsers/log_parser.py
Unified CAN Log Parser supporting Vector ASC, Plain Text, and JSON log formats.
Yields validated, normalized CANFrame instances with diagnostic tracking.
"""

from __future__ import annotations
import json
import os
import re
from pathlib import Path
from typing import Any, Dict, Generator, Iterable, Iterator, List, Optional, Tuple, Union
from core.models import CANFrame


class LogParseError(Exception):
    """Raised on critical log parse failures."""
    pass


class CANLogParser:
    """
    Unified high-performance parser for automotive CAN log streams.
    """

    # Regex for Vector ASC logs (e.g. "   0.000000 1  0C9             Rx   d 8 00 00 00 00 00 00 00 00")
    ASC_FRAME_RE = re.compile(
        r"^\s*([0-9]+\.?[0-9]*)\s+(\d+)\s+([0-9a-fA-F]+x?)\s+([A-Za-z]+)\s+([drRxX])\s+(\d+)(.*)$"
    )

    @classmethod
    def parse_file(
        cls, filepath: Union[str, Path]
    ) -> Generator[Union[CANFrame, Tuple[str, str]], None, None]:
        """
        Stream parsed items from a log file.
        Yields CANFrame instances for valid frames, or ('warning'|'error', msg) for diagnostics.
        """
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"CAN log file not found at: {path}")
        if path.is_dir():
            raise ValueError(f"Expected CAN log file path, got directory: {path}")

        # Check for JSON extension or JSON file content
        if path.suffix.lower() == ".json":
            yield from cls.parse_json_file(path)
            return

        with open(path, "r", encoding="utf-8", errors="replace") as f:
            first_line = f.readline()
            f.seek(0)
            if first_line.strip().startswith("[") or first_line.strip().startswith("{"):
                try:
                    yield from cls.parse_json_file(path)
                    return
                except Exception:
                    f.seek(0)

            yield from cls.parse_asc_stream(f)

    @classmethod
    def parse_asc_stream(
        cls, lines: Iterable[str]
    ) -> Generator[Union[CANFrame, Tuple[str, str]], None, None]:
        """
        Parse Vector ASC or standard text log lines into CANFrame objects.
        """
        base_is_hex = True  # Default Vector ASC base

        for line_num, line in enumerate(lines, 1):
            raw_line = line.rstrip("\r\n")
            stripped = raw_line.strip()
            if not stripped:
                continue

            # Header detection
            lower_s = stripped.lower()
            if lower_s.startswith("base hex"):
                base_is_hex = True
                continue
            if lower_s.startswith("base dec"):
                base_is_hex = False
                continue
            if lower_s.startswith("date") or lower_s.startswith("version") or lower_s.startswith("begin"):
                continue

            match = cls.ASC_FRAME_RE.match(raw_line)
            if not match:
                # Check if it's an unrecognized header or comment
                if any(lower_s.startswith(w) for w in ["end", "timestamp", "//", "#", ";", "start", "***"]):
                    continue
                yield ("warning", f"Line {line_num}: Unrecognized frame format: '{raw_line}'")
                continue

            try:
                ts_str, chan_str, id_str, dir_str, type_str, dlc_str, data_str = match.groups()
                timestamp = float(ts_str)
                channel = int(chan_str)

                # CAN ID normalization (extended 'x' suffix or numeric)
                is_extended = False
                clean_id = id_str.strip()
                if clean_id.lower().endswith("x"):
                    is_extended = True
                    can_id = int(clean_id[:-1], 16)
                elif base_is_hex:
                    can_id = int(clean_id, 16)
                    if can_id > 0x7FF:
                        is_extended = True
                else:
                    can_id = int(clean_id, 10)
                    if can_id > 0x7FF:
                        is_extended = True

                dlc = int(dlc_str)
                data_tokens = data_str.strip().split()
                # If trailing tokens exist, parse byte values up to dlc
                byte_vals = []
                for tok in data_tokens:
                    if len(byte_vals) >= dlc and dlc > 0:
                        break
                    try:
                        byte_vals.append(int(tok, 16))
                    except ValueError:
                        break

                payload = bytes(byte_vals)

                frame = CANFrame(
                    timestamp=timestamp,
                    can_id=can_id,
                    dlc=dlc,
                    data=payload,
                    channel=channel,
                    direction=dir_str,
                    frame_type=type_str,
                    is_extended=is_extended,
                    raw_line=raw_line,
                    line_number=line_num,
                )
                yield frame

            except Exception as e:
                yield ("error", f"Line {line_num}: Failed parsing CAN frame '{raw_line}': {e}")

    @classmethod
    def parse_json_file(
        cls, filepath: Union[str, Path]
    ) -> Generator[Union[CANFrame, Tuple[str, str]], None, None]:
        """
        Parse JSON array containing CAN frame dictionaries.
        """
        with open(filepath, "r", encoding="utf-8") as f:
            try:
                records = json.load(f)
            except Exception as e:
                yield ("error", f"JSON log decode failure: {e}")
                return

        if not isinstance(records, list):
            yield ("error", f"Expected JSON array of CAN frames, got {type(records).__name__}")
            return

        for idx, rec in enumerate(records, 1):
            if not isinstance(rec, dict):
                yield ("warning", f"Record #{idx}: Expected dict, got {type(rec).__name__}")
                continue

            try:
                # Extract timestamp
                ts = float(rec.get("timestamp", rec.get("time", 0.0)))
                
                # Extract CAN ID
                raw_id = rec.get("can_id", rec.get("can_id_hex", rec.get("id", 0)))
                is_ext = bool(rec.get("is_extended", False))
                if isinstance(raw_id, str):
                    clean_id = raw_id.strip()
                    if clean_id.lower().startswith("0x"):
                        can_id = int(clean_id, 16)
                    elif any(c in "abcdefABCDEF" for c in clean_id):
                        can_id = int(clean_id, 16)
                    else:
                        can_id = int(clean_id)
                else:
                    can_id = int(raw_id)

                if can_id > 0x7FF:
                    is_ext = True

                # Extract payload
                raw_data = rec.get("data", rec.get("payload", ""))
                if isinstance(raw_data, bytes):
                    payload = raw_data
                elif isinstance(raw_data, list):
                    payload = bytes(raw_data)
                elif isinstance(raw_data, str):
                    clean_data = raw_data.strip().replace(" ", "").replace("0x", "")
                    payload = bytes.fromhex(clean_data) if clean_data else b""
                else:
                    payload = b""

                dlc = int(rec.get("dlc", len(payload)))
                chan = int(rec.get("channel", 1))
                direction = str(rec.get("direction", "Rx"))
                frame_type = str(rec.get("frame_type", "d"))
                ecu = rec.get("ecu")

                frame = CANFrame(
                    timestamp=ts,
                    can_id=can_id,
                    dlc=dlc,
                    data=payload,
                    channel=chan,
                    direction=direction,
                    frame_type=frame_type,
                    is_extended=is_ext,
                    line_number=idx,
                    ecu=ecu,
                )
                yield frame
            except Exception as e:
                yield ("error", f"Record #{idx}: Failed parsing JSON frame: {e}")


def parse_can_log(
    filepath: Union[str, Path]
) -> Generator[Union[CANFrame, Tuple[str, str]], None, None]:
    """Convenience helper to stream items from any CAN log format."""
    return CANLogParser.parse_file(filepath)
