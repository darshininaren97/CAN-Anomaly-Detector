"""
parsers/signal_decoder.py
Unified Signal Extractor and Decoder for automotive CAN Bus messages.
Supports Intel (little-endian), Motorola (big-endian), signed/unsigned,
floating-point scaling, offset application, and multiplexed signal handling.
"""

from __future__ import annotations
import math
from typing import Dict, List, Optional, Tuple, Union
from core.models import CANFrame, DecodedFrame, DecodedSignal
from parsers.dbc_parser import DBCDatabase, MessageDef, SignalDef


def extract_raw_signal(
    payload: bytes,
    start_bit: int,
    length: int,
    byte_order: int,
    is_signed: bool
) -> int:
    """
    Extract raw integer signal bits from byte payload.
    
    :param payload: Raw CAN frame payload bytes
    :param start_bit: DBC bit offset
    :param length: Signal bit length (1-64)
    :param byte_order: 1 for Intel (little-endian), 0 for Motorola (big-endian)
    :param is_signed: True for two's complement signed integer
    """
    if length <= 0:
        raise ValueError(f"Signal length must be positive, got {length}")

    payload_len = len(payload)
    if payload_len == 0:
        raise ValueError("Cannot extract signal from empty payload")

    if byte_order == 1:
        # Intel (Little-Endian)
        # Convert entire payload to little-endian integer
        full_int = int.from_bytes(payload, byteorder="little", signed=False)
        # Check boundary
        if start_bit + length > payload_len * 8:
            raise ValueError(
                f"Intel signal span [bit {start_bit}..{start_bit + length - 1}] "
                f"exceeds payload boundary ({payload_len * 8} bits)"
            )
        raw_val = (full_int >> start_bit) & ((1 << length) - 1)
    else:
        # Motorola (Big-Endian / Sequential)
        # In DBC standard Motorola convention:
        # start_bit is the MSB (most significant bit).
        start_byte = start_bit // 8
        bit_in_byte = start_bit % 8
        
        # Calculate how many bits before MSB
        # Sequential bit indexing:
        raw_val = 0
        current_bit = start_bit
        for _ in range(length):
            byte_idx = current_bit // 8
            bit_idx = current_bit % 8
            if byte_idx >= payload_len or byte_idx < 0:
                raise ValueError(
                    f"Motorola bit extraction out of payload bounds: byte {byte_idx} (payload len {payload_len})"
                )
            bit = (payload[byte_idx] >> bit_idx) & 1
            raw_val = (raw_val << 1) | bit
            
            # Motorola bit stepping: moves from MSB to LSB within byte, then next byte
            if bit_idx == 0:
                current_bit = (byte_idx + 1) * 8 + 7
            else:
                current_bit -= 1

    # Sign extension for signed signals
    if is_signed:
        sign_mask = 1 << (length - 1)
        if raw_val & sign_mask:
            raw_val -= (1 << length)

    return raw_val


class SignalDecoder:
    """
    Decodes signals from raw CANFrame instances using a DBCDatabase.
    """

    def __init__(self, db: Optional[DBCDatabase] = None) -> None:
        self.db = db

    def set_database(self, db: DBCDatabase) -> None:
        """Update active DBC database."""
        self.db = db

    def decode_frame(self, frame: CANFrame) -> Optional[DecodedFrame]:
        """
        Decode all active signals in a CAN frame according to DBC definitions.
        Handles multiplexed signals and payload validation.
        """
        if self.db is None:
            return None

        msg_def = self.db.get_message(frame.can_id, frame.is_extended)
        if msg_def is None:
            # Try without extendedness constraint
            msg_def = self.db.get_message(frame.can_id)
            if msg_def is None:
                return None

        decoded_signals: Dict[str, DecodedSignal] = {}
        errors: List[str] = []

        # Find multiplexer signal if any
        mux_signals = [s for s in msg_def.signals if s.is_multiplexer]
        mux_sig = mux_signals[0] if mux_signals else None
        active_mux_val: Optional[int] = None

        if mux_sig is not None:
            try:
                mux_raw = extract_raw_signal(
                    frame.data,
                    mux_sig.start_bit,
                    mux_sig.length,
                    mux_sig.byte_order,
                    mux_sig.is_signed,
                )
                active_mux_val = mux_raw
                mux_phys = mux_raw * mux_sig.factor + mux_sig.offset
                decoded_signals[mux_sig.name] = DecodedSignal(
                    name=mux_sig.name,
                    message_name=msg_def.name,
                    can_id=frame.can_id,
                    timestamp=frame.timestamp,
                    raw_value=mux_raw,
                    physical_value=mux_phys,
                    unit=mux_sig.unit,
                    minimum=mux_sig.min_val,
                    maximum=mux_sig.max_val,
                    factor=mux_sig.factor,
                    offset=mux_sig.offset,
                    is_extended=frame.is_extended,
                    comment=mux_sig.comment,
                )
            except Exception as e:
                errors.append(f"Multiplexer signal '{mux_sig.name}' extraction failed: {e}")

        # Decode applicable signals
        for sig in msg_def.signals:
            if sig is mux_sig:
                continue

            # Check if this signal is conditional on multiplexer
            if sig.multiplexer_value is not None:
                if active_mux_val is None or sig.multiplexer_value != active_mux_val:
                    continue

            try:
                raw_val = extract_raw_signal(
                    frame.data,
                    sig.start_bit,
                    sig.length,
                    sig.byte_order,
                    sig.is_signed,
                )
                phys_val = raw_val * sig.factor + sig.offset
                if not math.isfinite(phys_val):
                    errors.append(f"Signal '{sig.name}' computed non-finite physical value ({phys_val})")
                    continue

                enum_val = sig.enums.get(int(raw_val)) if sig.enums else None
                if enum_val is None and sig.enums and math.isfinite(phys_val):
                    enum_val = sig.enums.get(int(round(phys_val)))

                decoded_signals[sig.name] = DecodedSignal(
                    name=sig.name,
                    message_name=msg_def.name,
                    can_id=frame.can_id,
                    timestamp=frame.timestamp,
                    raw_value=raw_val,
                    physical_value=phys_val,
                    unit=sig.unit,
                    minimum=sig.min_val,
                    maximum=sig.max_val,
                    factor=sig.factor,
                    offset=sig.offset,
                    is_extended=frame.is_extended,
                    comment=sig.comment,
                    enum_name=enum_val,
                )
            except Exception as e:
                errors.append(f"Signal '{sig.name}' extraction failed: {e}")

        return DecodedFrame(
            frame=frame,
            message_name=msg_def.name,
            signals=decoded_signals,
            errors=errors,
        )
