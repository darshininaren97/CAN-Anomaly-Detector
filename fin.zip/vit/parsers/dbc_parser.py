"""
parsers/dbc_parser.py
Unified DBC Database Parser for automotive CAN Bus definitions.
Parses BO_, SG_, VAL_, CM_, and multiplexing definitions with O(1) message lookup.
"""

from __future__ import annotations
import math
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union


class DBCError(Exception):
    """Base exception for DBC errors."""
    pass


class DBCParseError(DBCError, ValueError):
    """Raised when parsing a DBC file fails due to invalid syntax."""
    pass


@dataclass(frozen=True, slots=True)
class SignalDef:
    """Definition of a CAN signal within a DBC message."""
    name: str
    start_bit: int
    length: int
    byte_order: int  # 1 = Intel (little-endian), 0 = Motorola (big-endian)
    is_signed: bool
    factor: float
    offset: float
    min_val: Optional[float]
    max_val: Optional[float]
    unit: str
    receivers: List[str] = field(default_factory=list)
    enums: Dict[int, str] = field(default_factory=dict)
    comment: str = ""
    is_multiplexer: bool = False
    multiplexer_value: Optional[int] = None
    is_multiplexed_multiplexer: bool = False

    @property
    def has_usable_range(self) -> bool:
        """True if signal defines both minimum and maximum valid values."""
        return self.min_val is not None and self.max_val is not None


@dataclass
class MessageDef:
    """Definition of a CAN message containing multiple signals."""
    id: int
    name: str
    dlc: int
    sender: str
    signals: List[SignalDef] = field(default_factory=list)
    is_extended: bool = False
    comment: str = ""
    cycle_time_ms: Optional[float] = None

    def get_signal(self, name: str) -> Optional[SignalDef]:
        """Lookup signal by name."""
        for sig in self.signals:
            if sig.name == name:
                return sig
        return None


class DBCDatabase:
    """
    In-memory database of DBC message and signal definitions.
    Supports dual-key lookup by (can_id, is_extended) as well as direct integer ID lookup.
    """

    def __init__(self, filename: str = "") -> None:
        self.filename = filename
        self.messages: Dict[Tuple[int, bool], MessageDef] = {}
        self._id_map: Dict[int, List[MessageDef]] = {}

    def add_message(self, msg: MessageDef) -> None:
        """Add message definition to database."""
        key = (msg.id, msg.is_extended)
        self.messages[key] = msg
        if msg.id not in self._id_map:
            self._id_map[msg.id] = []
        # Update or append
        self._id_map[msg.id] = [m for m in self._id_map[msg.id] if m.is_extended != msg.is_extended]
        self._id_map[msg.id].append(msg)

    def get_message(self, can_id: int, is_extended: Optional[bool] = None) -> Optional[MessageDef]:
        """
        Lookup message by CAN ID and optional extended flag.
        """
        if is_extended is not None:
            return self.messages.get((can_id, is_extended))
        matches = self._id_map.get(can_id, [])
        if len(matches) == 1:
            return matches[0]
        if len(matches) > 1:
            # Default to standard if available
            for m in matches:
                if not m.is_extended:
                    return m
            return matches[0]
        return None

    def get_message_by_id(self, can_id: int) -> Optional[MessageDef]:
        """Backward compatibility lookup for can_anomaly_detector_logic."""
        return self.get_message(can_id)

    def __getitem__(self, key: Union[Tuple[int, bool], int]) -> MessageDef:
        if isinstance(key, tuple):
            return self.messages[key]
        msg = self.get_message(key)
        if msg is None:
            raise KeyError(key)
        return msg

    def __contains__(self, key: Union[Tuple[int, bool], int]) -> bool:
        if isinstance(key, tuple):
            return key in self.messages
        return key in self._id_map

    def __len__(self) -> int:
        return len(self.messages)

    def __iter__(self):
        return iter(self.messages.values())


class DBCParser:
    """Parser for CAN DBC files."""

    BO_PATTERN = re.compile(
        r"^BO_\s+(\d+)\s+(\w+)\s*:\s*(\d+)\s+(\w+)"
    )
    SG_PATTERN = re.compile(
        r"^\s*SG_\s+(\w+)\s*([Mm0-9]*)\s*:\s*(\d+)\|(\d+)@([01])([+-])\s*\(([^,]+),([^)]+)\)\s*\[([^|]+)\|([^\]]+)\]\s*\"([^\"]*)\"\s*(.*)"
    )
    VAL_PATTERN = re.compile(
        r"^VAL_\s+(\d+)\s+(\w+)\s+(.*);"
    )
    CM_BO_PATTERN = re.compile(
        r"^CM_\s+BO_\s+(\d+)\s+\"([^\"]*)\";"
    )
    CM_SG_PATTERN = re.compile(
        r"^CM_\s+SG_\s+(\d+)\s+(\w+)\s+\"([^\"]*)\";"
    )
    BA_CYCLE_PATTERN = re.compile(
        r"^BA_\s+\"GenMsgCycleTime\"\s+BO_\s+(\d+)\s+([-+]?[0-9]*\.?[0-9]+);"
    )

    @classmethod
    def parse_file(cls, filepath: Union[str, Path]) -> DBCDatabase:
        """Parse DBC file from filesystem path."""
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"DBC file not found at: {path}")
        if path.is_dir():
            raise ValueError(f"Expected DBC file path, got directory: {path}")

        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            raise DBCParseError(f"Failed reading DBC file '{filepath}': {e}") from e

        return cls.parse_string(content, filename=str(path))

    @classmethod
    def parse_string(cls, text: str, filename: str = "") -> DBCDatabase:
        """Parse DBC definitions from string."""
        db = DBCDatabase(filename=filename)
        current_msg: Optional[MessageDef] = None
        enum_map: Dict[Tuple[int, str], Dict[int, str]] = {}
        comments_sg: Dict[Tuple[int, str], str] = {}
        comments_bo: Dict[int, str] = {}

        lines = text.splitlines()
        for line_num, line in enumerate(lines, 1):
            line_str = line.strip()
            if not line_str:
                continue

            bo_match = cls.BO_PATTERN.match(line_str)
            if bo_match:
                raw_id = int(bo_match.group(1))
                name = bo_match.group(2)
                dlc = int(bo_match.group(3))
                sender = bo_match.group(4)

                # Extended CAN ID detection: Vector DBC sets bit 31 (0x80000000) for extended IDs
                is_extended = bool(raw_id & 0x80000000)
                norm_id = raw_id & 0x1FFFFFFF if is_extended else raw_id

                current_msg = MessageDef(
                    id=norm_id,
                    name=name,
                    dlc=dlc,
                    sender=sender,
                    signals=[],
                    is_extended=is_extended,
                )
                db.add_message(current_msg)
                continue

            sg_match = cls.SG_PATTERN.match(line)
            if sg_match and current_msg is not None:
                sig_name = sg_match.group(1)
                mux_indicator = sg_match.group(2).strip()
                start_bit = int(sg_match.group(3))
                length = int(sg_match.group(4))
                byte_order = int(sg_match.group(5))  # 1 = Intel, 0 = Motorola
                is_signed = sg_match.group(6) == "-"
                factor = float(sg_match.group(7))
                offset = float(sg_match.group(8))

                min_str = sg_match.group(9).strip()
                max_str = sg_match.group(10).strip()
                unit = sg_match.group(11)
                receivers_str = sg_match.group(12).strip()
                receivers = [r.strip() for r in receivers_str.split(",") if r.strip()]

                try:
                    min_val = float(min_str) if min_str else None
                except ValueError:
                    min_val = None

                try:
                    max_val = float(max_str) if max_str else None
                except ValueError:
                    max_val = None

                is_mux = False
                mux_val = None
                is_mux_mux = False

                if mux_indicator == "M":
                    is_mux = True
                elif mux_indicator.startswith("m"):
                    try:
                        if mux_indicator.endswith("M"):
                            is_mux_mux = True
                            mux_val = int(mux_indicator[1:-1])
                        else:
                            mux_val = int(mux_indicator[1:])
                    except ValueError:
                        mux_val = None

                sig_def = SignalDef(
                    name=sig_name,
                    start_bit=start_bit,
                    length=length,
                    byte_order=byte_order,
                    is_signed=is_signed,
                    factor=factor,
                    offset=offset,
                    min_val=min_val,
                    max_val=max_val,
                    unit=unit,
                    receivers=receivers,
                    is_multiplexer=is_mux,
                    multiplexer_value=mux_val,
                    is_multiplexed_multiplexer=is_mux_mux,
                )
                current_msg.signals.append(sig_def)
                continue

            val_match = cls.VAL_PATTERN.match(line_str)
            if val_match:
                msg_id = int(val_match.group(1)) & 0x1FFFFFFF
                sig_name = val_match.group(2)
                raw_entries = val_match.group(3).strip().split()
                # Parse pairs: value "description"
                val_enums: Dict[int, str] = {}
                i = 0
                while i < len(raw_entries) - 1:
                    try:
                        val_num = int(raw_entries[i])
                        val_desc = raw_entries[i + 1].strip('"')
                        val_enums[val_num] = val_desc
                        i += 2
                    except ValueError:
                        i += 1
                enum_map[(msg_id, sig_name)] = val_enums
                continue

            ba_match = cls.BA_CYCLE_PATTERN.match(line_str)
            if ba_match:
                raw_id = int(ba_match.group(1))
                is_ext = bool(raw_id & 0x80000000)
                norm_id = raw_id & 0x1FFFFFFF if is_ext else raw_id
                cycle_time = float(ba_match.group(2))
                target_msg = db.get_message(norm_id, is_ext)
                if target_msg is not None:
                    target_msg.cycle_time_ms = cycle_time
                continue

        # Attach comments and enums
        for msg in db.messages.values():
            if msg.id in comments_bo:
                msg.comment = comments_bo[msg.id]
            for i, sig in enumerate(msg.signals):
                key = (msg.id, sig.name)
                enums = enum_map.get(key, {})
                cm = comments_sg.get(key, "")
                if enums or cm:
                    # Replace signal with enriched signal def
                    enriched = SignalDef(
                        name=sig.name,
                        start_bit=sig.start_bit,
                        length=sig.length,
                        byte_order=sig.byte_order,
                        is_signed=sig.is_signed,
                        factor=sig.factor,
                        offset=sig.offset,
                        min_val=sig.min_val,
                        max_val=sig.max_val,
                        unit=sig.unit,
                        receivers=sig.receivers,
                        enums=enums if enums else sig.enums,
                        comment=cm if cm else sig.comment,
                        is_multiplexer=sig.is_multiplexer,
                        multiplexer_value=sig.multiplexer_value,
                        is_multiplexed_multiplexer=sig.is_multiplexed_multiplexer,
                    )
                    msg.signals[i] = enriched

        return db


def parse_dbc(filepath: Union[str, Path]) -> DBCDatabase:
    """Convenience helper to parse a DBC file."""
    return DBCParser.parse_file(filepath)
