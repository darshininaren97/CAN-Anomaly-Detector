"""
core/dashboard.py
Signal-Timeline Visualization Dashboard Generator for CAN Bus Anomaly Detection.

Generates a single self-contained, offline-viewable HTML file embedding:
  1. Signal timeline charts (one per signal) with anomaly overlays.
  2. CAN-ID message activity swimlanes (rug plot).
  3. Severity / category summary bar charts.

Uses Chart.js (vendored or CDN) — no Python-side graphing dependencies.
Read-only with respect to the pipeline data structures passed in.
"""

from __future__ import annotations

import json
import logging
import os
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from core.models import AnomalyCategory, DecodedFrame, Severity, UnifiedAnomaly

logger = logging.getLogger("can_dashboard")

# ─────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────
MAX_POINTS_PER_SIGNAL = 5000   # Downsample threshold for very large logs
MAX_ACTIVITY_FRAMES   = 10000  # Cap on CAN-ID activity rug-plot points

SEVERITY_COLORS: Dict[str, str] = {
    Severity.CRITICAL.value: "rgba(220,38,38,0.95)",
    Severity.HIGH.value:     "rgba(234,88,12,0.90)",
    Severity.MEDIUM.value:   "rgba(202,138,4,0.85)",
    Severity.LOW.value:      "rgba(100,116,139,0.75)",
}

SEVERITY_BORDER: Dict[str, str] = {
    Severity.CRITICAL.value: "#b91c1c",
    Severity.HIGH.value:     "#c2410c",
    Severity.MEDIUM.value:   "#a16207",
    Severity.LOW.value:      "#475569",
}

CATEGORY_PALETTE = [
    "#3b82f6", "#8b5cf6", "#ec4899", "#14b8a6",
    "#f97316", "#84cc16", "#f43f5e", "#06b6d4",
    "#a855f7", "#22c55e", "#eab308", "#64748b",
]


# ─────────────────────────────────────────────
# Data extraction helpers
# ─────────────────────────────────────────────

def _build_signal_series(
    decoded_frames: Sequence[DecodedFrame],
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Return {signal_name: [{"t": timestamp, "v": physical_value, "unit": str,
                           "msg": message_name, "can_id": int}, ...]}
    sorted by timestamp.  Long series are downsampled to MAX_POINTS_PER_SIGNAL.
    """
    raw: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for df in decoded_frames:
        for sig_name, sig in df.signals.items():
            raw[sig_name].append({
                "t": round(sig.timestamp, 6),
                "v": sig.physical_value,
                "unit": sig.unit or "",
                "msg": sig.message_name,
                "can_id": sig.can_id,
            })

    result: Dict[str, List[Dict[str, Any]]] = {}
    for name, pts in raw.items():
        pts.sort(key=lambda p: p["t"])
        if len(pts) > MAX_POINTS_PER_SIGNAL:
            step = len(pts) / MAX_POINTS_PER_SIGNAL
            pts = [pts[int(i * step)] for i in range(MAX_POINTS_PER_SIGNAL)]
        result[name] = pts

    return result


def _build_anomaly_index(
    anomalies: Sequence[UnifiedAnomaly],
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Return {signal_name: [anomaly_dict, ...]} for anomalies that have a
    resolved signal_name.  Anomalies without a signal_name are placed under
    the key "__lane__" for the CAN-ID activity lane rendering.
    """
    index: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for a in anomalies:
        key = a.signal_name if a.signal_name else "__lane__"
        sev_val = a.severity.value if isinstance(a.severity, Severity) else str(a.severity)
        cat_val = a.category.value if isinstance(a.category, AnomalyCategory) else str(a.category)
        index[key].append({
            "t": round(a.timestamp, 6),
            "sev": sev_val,
            "cat": cat_val,
            "type": a.anomaly_type,
            "reason": a.reason,
            "detector": a.detector,
            "observed": str(a.observed_value) if a.observed_value is not None else "",
            "expected": str(a.expected_value) if a.expected_value is not None else "",
            "can_id_hex": a.can_id_hex or "",
            "msg": a.message_name or "",
            "color": SEVERITY_COLORS.get(sev_val, SEVERITY_COLORS[Severity.LOW.value]),
            "border": SEVERITY_BORDER.get(sev_val, SEVERITY_BORDER[Severity.LOW.value]),
        })
    return index


def _build_activity_lanes(
    decoded_frames: Sequence[DecodedFrame],
) -> Dict[str, List[float]]:
    """
    Return {can_id_hex: [timestamp, ...]} for the swimlane rug plot.
    Capped at MAX_ACTIVITY_FRAMES total entries across all lanes.
    """
    lanes: Dict[str, List[float]] = defaultdict(list)
    for df in decoded_frames:
        f = df.frame
        lanes[f.hex_id].append(round(f.timestamp, 6))

    # Deterministic cap: evenly sample within each lane
    result: Dict[str, List[float]] = {}
    total = sum(len(v) for v in lanes.values())
    cap_ratio = MAX_ACTIVITY_FRAMES / max(total, 1)

    for cid, ts in sorted(lanes.items()):
        ts.sort()
        if cap_ratio < 1.0:
            step = max(1, int(1 / cap_ratio))
            ts = ts[::step]
        result[cid] = ts

    return result


# ─────────────────────────────────────────────
# HTML / JS template
# ─────────────────────────────────────────────

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>CAN Bus Anomaly Dashboard</title>
<style>
  *,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
  :root{{
    --bg:#0f172a;--surface:#1e293b;--surface2:#334155;
    --text:#e2e8f0;--text2:#94a3b8;--accent:#38bdf8;
    --border:#334155;--radius:8px;
    --crit:#dc2626;--high:#ea580c;--med:#ca8a04;--low:#64748b;
  }}
  body{{background:var(--bg);color:var(--text);font-family:system-ui,sans-serif;font-size:14px;line-height:1.5}}
  header{{
    background:var(--surface);border-bottom:1px solid var(--border);
    padding:16px 24px;display:flex;justify-content:space-between;align-items:center;
  }}
  header h1{{font-size:18px;font-weight:700;letter-spacing:-.3px;color:var(--accent)}}
  header .meta{{font-size:12px;color:var(--text2);text-align:right;line-height:1.8}}
  .container{{max-width:1400px;margin:0 auto;padding:24px}}
  .section-title{{
    font-size:12px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;
    color:var(--text2);margin:28px 0 12px;border-bottom:1px solid var(--border);padding-bottom:6px;
  }}
  .summary-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px;margin-bottom:4px}}
  .stat-card{{
    background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);
    padding:14px 18px;display:flex;flex-direction:column;gap:2px;
  }}
  .stat-card .label{{font-size:11px;color:var(--text2);text-transform:uppercase;letter-spacing:.06em}}
  .stat-card .value{{font-size:28px;font-weight:700;line-height:1.1}}
  .stat-card.crit .value{{color:var(--crit)}}
  .stat-card.high .value{{color:var(--high)}}
  .stat-card.med .value{{color:var(--med)}}
  .stat-card.low .value{{color:var(--low)}}
  .charts-grid{{display:grid;grid-template-columns:1fr 1fr;gap:12px}}
  @media(max-width:900px){{.charts-grid{{grid-template-columns:1fr}}}}
  .chart-card{{
    background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);
    padding:16px;position:relative;
  }}
  .chart-card h3{{font-size:13px;font-weight:600;margin-bottom:12px;display:flex;justify-content:space-between;align-items:center}}
  .chart-card h3 .unit{{font-size:11px;color:var(--text2);font-weight:400}}
  .chart-card h3 .badge{{
    font-size:10px;padding:2px 7px;border-radius:20px;
    background:var(--surface2);color:var(--text2);font-weight:500;
  }}
  .chart-wrapper{{position:relative;height:260px}}
  .lane-card{{
    background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:16px;
  }}
  .lane-card h3{{font-size:13px;font-weight:600;margin-bottom:14px}}
  .lane-row{{display:flex;align-items:center;margin-bottom:8px;gap:10px}}
  .lane-label{{min-width:80px;font-size:11px;color:var(--text2);font-family:monospace}}
  .lane-canvas-wrap{{flex:1;height:32px;position:relative}}
  .anomaly-list{{margin-top:4px}}
  .anomaly-item{{
    background:var(--surface2);border-radius:6px;padding:10px 12px;margin-bottom:6px;
    display:grid;grid-template-columns:auto 1fr;gap:6px 12px;align-items:start;
    border-left:3px solid transparent;
  }}
  .anomaly-item.crit{{border-left-color:var(--crit)}}
  .anomaly-item.high{{border-left-color:var(--high)}}
  .anomaly-item.med{{border-left-color:var(--med)}}
  .anomaly-item.low{{border-left-color:var(--low)}}
  .sev-badge{{
    font-size:10px;font-weight:700;padding:2px 6px;border-radius:4px;
    letter-spacing:.04em;white-space:nowrap;
  }}
  .sev-badge.crit{{background:var(--crit);color:#fff}}
  .sev-badge.high{{background:var(--high);color:#fff}}
  .sev-badge.med{{background:var(--med);color:#fff}}
  .sev-badge.low{{background:var(--low);color:#fff}}
  .anomaly-details{{font-size:12px;color:var(--text)}}
  .anomaly-details .time{{color:var(--text2);font-size:11px;font-family:monospace}}
  .anomaly-details .reason{{margin-top:2px;line-height:1.4}}
  .anomaly-details .meta-row{{display:flex;gap:12px;margin-top:4px;color:var(--text2);font-size:11px}}
  .no-data{{
    text-align:center;padding:60px 20px;color:var(--text2);
    background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);
  }}
  .no-data p{{font-size:16px;margin-bottom:6px}}
  .no-data small{{font-size:12px}}
  .downsampled-note{{
    font-size:11px;color:var(--med);background:rgba(202,138,4,.1);
    border:1px solid rgba(202,138,4,.25);border-radius:4px;
    padding:4px 10px;display:inline-block;margin-bottom:8px;
  }}
  .legend-row{{display:flex;gap:16px;margin-bottom:10px;flex-wrap:wrap}}
  .legend-item{{display:flex;align-items:center;gap:5px;font-size:11px;color:var(--text2)}}
  .legend-dot{{width:10px;height:10px;border-radius:50%;flex-shrink:0}}
  canvas{{display:block;width:100%!important}}
  .controls{{display:flex;gap:8px;margin-bottom:16px;flex-wrap:wrap}}
  .btn{{
    font-size:11px;padding:5px 12px;border-radius:5px;border:1px solid var(--border);
    background:var(--surface2);color:var(--text);cursor:pointer;transition:background .15s;
  }}
  .btn:hover{{background:#475569}}
</style>
</head>
<body>
<header>
  <h1>🚗 CAN Bus Anomaly Dashboard</h1>
  <div class="meta" id="header-meta"></div>
</header>
<div class="container">

  <!-- ── SEVERITY SUMMARY ─────────────────── -->
  <div class="section-title">Anomaly Summary</div>
  <div class="summary-grid">
    <div class="stat-card crit"><span class="label">Critical</span><span class="value" id="cnt-crit">–</span></div>
    <div class="stat-card high"><span class="label">High</span><span class="value" id="cnt-high">–</span></div>
    <div class="stat-card med"><span class="label">Medium</span><span class="value" id="cnt-med">–</span></div>
    <div class="stat-card low"><span class="label">Low</span><span class="value" id="cnt-low">–</span></div>
  </div>

  <!-- ── SUMMARY CHARTS ───────────────────── -->
  <div class="charts-grid" style="margin-top:12px">
    <div class="chart-card">
      <h3>Anomalies by Severity</h3>
      <div class="chart-wrapper"><canvas id="chart-sev"></canvas></div>
    </div>
    <div class="chart-card">
      <h3>Anomalies by Category</h3>
      <div class="chart-wrapper"><canvas id="chart-cat"></canvas></div>
    </div>
  </div>

  <!-- ── SIGNAL TIMELINES ─────────────────── -->
  <div class="section-title">Signal Timelines</div>
  <div class="legend-row">
    <span class="legend-item"><span class="legend-dot" style="background:rgba(220,38,38,.9)"></span>Critical anomaly</span>
    <span class="legend-item"><span class="legend-dot" style="background:rgba(234,88,12,.9)"></span>High anomaly</span>
    <span class="legend-item"><span class="legend-dot" style="background:rgba(202,138,4,.85)"></span>Medium anomaly</span>
    <span class="legend-item"><span class="legend-dot" style="background:rgba(100,116,139,.75)"></span>Low anomaly</span>
  </div>
  <div id="signal-charts"></div>

  <!-- ── CAN-ID ACTIVITY LANES ─────────────── -->
  <div class="section-title">CAN-ID Message Activity</div>
  <div class="lane-card" id="activity-lanes">
    <h3>Frame Arrival Times per CAN ID</h3>
    <div id="lane-rows"></div>
  </div>

  <!-- ── ANOMALY LOG TABLE ─────────────────── -->
  <div class="section-title">All Detected Anomalies</div>
  <div class="anomaly-list" id="anomaly-list"></div>

</div>

<!-- ── Vendored Chart.js ───────────────────── -->
{chartjs_script}

<script>
// ── Embedded data payload ───────────────────
const PAYLOAD = {payload_json};

// ── Severity CSS class helper ───────────────
function sevClass(s){{
  if(s==='CRITICAL')return'crit';
  if(s==='HIGH')return'high';
  if(s==='MEDIUM')return'med';
  return'low';
}}

// ── Format value for tooltip ─────────────────
function fmtVal(v){{return(v===undefined||v===null||v==='')?' — ':v}}

// ── Chart.js default theme ───────────────────
Chart.defaults.color='#94a3b8';
Chart.defaults.borderColor='#334155';
Chart.defaults.font={{family:'system-ui,sans-serif',size:11}};

// ─────────────────────────────────────────────
// 1. HEADER META
// ─────────────────────────────────────────────
(function(){{
  const m=PAYLOAD.metadata;
  const el=document.getElementById('header-meta');
  el.innerHTML=Object.entries(m).map(([k,v])=>`<span><b>${{k}}:</b> ${{v}}</span>`).join('<br>');
}})();

// ─────────────────────────────────────────────
// 2. STAT COUNTERS
// ─────────────────────────────────────────────
(function(){{
  const s=PAYLOAD.summary.by_severity||{{}};
  document.getElementById('cnt-crit').textContent=s.critical??0;
  document.getElementById('cnt-high').textContent=s.high??0;
  document.getElementById('cnt-med').textContent=s.medium??0;
  document.getElementById('cnt-low').textContent=s.low??0;
}})();

// ─────────────────────────────────────────────
// 3. SUMMARY CHARTS (bar + doughnut)
// ─────────────────────────────────────────────
(function(){{
  const bs=PAYLOAD.summary.by_severity||{{}};
  const PALETTE={palette_json};

  // Severity bar
  new Chart(document.getElementById('chart-sev'),{{
    type:'bar',
    data:{{
      labels:['Critical','High','Medium','Low'],
      datasets:[{{
        data:[bs.critical??0,bs.high??0,bs.medium??0,bs.low??0],
        backgroundColor:['rgba(220,38,38,.8)','rgba(234,88,12,.8)','rgba(202,138,4,.8)','rgba(100,116,139,.6)'],
        borderColor:['#b91c1c','#c2410c','#a16207','#475569'],
        borderWidth:1,borderRadius:4,
      }}]
    }},
    options:{{
      responsive:true,maintainAspectRatio:false,
      plugins:{{legend:{{display:false}},tooltip:{{callbacks:{{
        label:ctx=>`Count: ${{ctx.parsed.y}}`
      }}}}}},
      scales:{{
        x:{{grid:{{color:'rgba(51,65,85,.5)'}}}},
        y:{{grid:{{color:'rgba(51,65,85,.5)'}},beginAtZero:true,ticks:{{stepSize:1}}}},
      }}
    }}
  }});

  // Category doughnut
  const bc=PAYLOAD.summary.by_category||{{}};
  const catLabels=Object.keys(bc);
  const catData=Object.values(bc);
  new Chart(document.getElementById('chart-cat'),{{
    type:'doughnut',
    data:{{
      labels:catLabels,
      datasets:[{{
        data:catData,
        backgroundColor:PALETTE.slice(0,catLabels.length),
        borderColor:'#1e293b',borderWidth:2,
      }}]
    }},
    options:{{
      responsive:true,maintainAspectRatio:false,
      plugins:{{
        legend:{{position:'right',labels:{{boxWidth:12,padding:10,font:{{size:11}}}}}},
        tooltip:{{callbacks:{{label:ctx=>`${{ctx.label}}: ${{ctx.parsed}}`}}}}
      }}
    }}
  }});
}})();

// ─────────────────────────────────────────────
// 4. SIGNAL TIMELINE CHARTS
// ─────────────────────────────────────────────
(function(){{
  const container=document.getElementById('signal-charts');
  const signals=PAYLOAD.signals;
  const anomIdx=PAYLOAD.anomaly_index;

  if(!signals||Object.keys(signals).length===0){{
    container.innerHTML='<div class="no-data"><p>No decoded signal data available.</p><small>Ensure the DBC file matches the CAN log.</small></div>';
    return;
  }}

  const grid=document.createElement('div');
  grid.className='charts-grid';
  container.appendChild(grid);

  Object.entries(signals).forEach(([sigName,pts])=>{{
    const unit=pts.length?pts[0].unit:'';
    const anomPts=(anomIdx[sigName]||[]);
    const isDownsampled=PAYLOAD.downsampled.includes(sigName);

    const card=document.createElement('div');
    card.className='chart-card';
    card.innerHTML=`
      ${{isDownsampled?'<div class="downsampled-note">⚠ Downsampled to {max_pts} points</div>':''}}
      <h3>${{sigName}} ${{unit?`<span class="unit">(${{unit}})</span>`:''}}
        ${{anomPts.length?`<span class="badge">${{anomPts.length}} anomal${{anomPts.length===1?'y':'ies'}}</span>`:''}}
      </h3>
      <div class="chart-wrapper"><canvas id="sig-${{sigName.replace(/[^a-zA-Z0-9]/g,'_')}}"></canvas></div>
    `;
    grid.appendChild(card);

    const canvasId=`sig-${{sigName.replace(/[^a-zA-Z0-9]/g,'_')}}`;
    const ctx=card.querySelector('canvas').getContext('2d');

    // Build scatter datasets for anomaly markers grouped by severity
    const anomDatasets=[];
    const sevGroups={{}};
    anomPts.forEach(a=>{{
      if(!sevGroups[a.sev])sevGroups[a.sev]=[];
      sevGroups[a.sev].push({{x:a.t,y:null,_a:a}});
    }});
    // Resolve y-value for anomaly markers by nearest signal point
    const tsArr=pts.map(p=>p.t);
    const vArr=pts.map(p=>p.v);
    Object.entries(sevGroups).forEach(([sev,mpts])=>{{
      const filled=mpts.map(m=>{{
        let y=null;
        if(tsArr.length){{
          let best=Infinity,bi=0;
          tsArr.forEach((t,i)=>{{const d=Math.abs(t-m.x);if(d<best){{best=d;bi=i;}}}});
          y=vArr[bi];
        }}
        return{{x:m.x,y,_a:m._a}};
      }});
      anomDatasets.push({{
        type:'scatter',
        label:`${{sev}} anomal${{filled.length===1?'y':'ies'}}`,
        data:filled,
        pointRadius:7,pointHoverRadius:10,
        backgroundColor:SEVERITY_COLORS[sev]||'rgba(100,116,139,.8)',
        borderColor:SEVERITY_BORDER[sev]||'#475569',
        borderWidth:2,
        showLine:false,
        order:0,
      }});
    }});

    new Chart(ctx,{{
      type:'line',
      data:{{
        datasets:[
          {{
            label:sigName,
            data:pts.map(p=>{{return{{x:p.t,y:p.v}}}}),
            borderColor:'#38bdf8',backgroundColor:'rgba(56,189,248,.1)',
            borderWidth:1.5,pointRadius:0,tension:0.1,fill:true,order:1,
          }},
          ...anomDatasets,
        ]
      }},
      options:{{
        responsive:true,maintainAspectRatio:false,
        parsing:false,
        interaction:{{mode:'nearest',intersect:false,axis:'x'}},
        plugins:{{
          legend:{{display:anomPts.length>0,position:'bottom',labels:{{boxWidth:10,padding:8}}}},
          tooltip:{{
            callbacks:{{
              title:items=>{{
                const it=items[0];
                return `t = ${{it.parsed.x.toFixed(4)}} s`;
              }},
              label:ctx=>{{
                if(ctx.dataset.type==='scatter'){{
                  const a=ctx.raw._a;
                  return[
                    ` [${{a.sev}}] ${{a.type}}`,
                    ` Category: ${{a.cat}}`,
                    ` Detector: ${{a.detector}}`,
                    ` Reason: ${{a.reason.substring(0,80)}}${{a.reason.length>80?'…':''}}`,
                    ...(a.observed?[` Observed: ${{a.observed}}`]:[]),
                    ...(a.expected?[` Expected: ${{a.expected}}`]:[]),
                  ];
                }}
                return ` ${{sigName}}: ${{ctx.parsed.y}} ${{unit}}`;
              }},
            }}
          }},
        }},
        scales:{{
          x:{{type:'linear',title:{{display:true,text:'Time (s)',color:'#64748b'}},
              grid:{{color:'rgba(51,65,85,.5)'}}}},
          y:{{title:{{display:!!unit,text:unit,color:'#64748b'}},
              grid:{{color:'rgba(51,65,85,.5)'}}}},
        }},
      }}
    }});
  }});

  // Expose severity color map to global for use in JS template
  window.SEVERITY_COLORS={{}};
  window.SEVERITY_BORDER={{}};
  ['CRITICAL','HIGH','MEDIUM','LOW'].forEach(s=>{{
    window.SEVERITY_COLORS[s]=PAYLOAD.severity_colors[s];
    window.SEVERITY_BORDER[s]=PAYLOAD.severity_border[s];
  }});
}})();

// ─────────────────────────────────────────────
// 5. CAN-ID ACTIVITY SWIMLANES
// ─────────────────────────────────────────────
(function(){{
  const laneData=PAYLOAD.activity_lanes;
  const laneAnoms=PAYLOAD.anomaly_index.__lane__||[];
  const container=document.getElementById('lane-rows');

  if(!laneData||Object.keys(laneData).length===0){{
    container.innerHTML='<p style="color:#64748b;font-size:12px">No frame activity data.</p>';
    return;
  }}

  // Determine global time range
  let tMin=Infinity,tMax=-Infinity;
  Object.values(laneData).forEach(ts=>{{
    if(ts.length){{tMin=Math.min(tMin,ts[0]);tMax=Math.max(tMax,ts[ts.length-1]);}}
  }});
  const tRange=tMax-tMin||1;

  Object.entries(laneData).forEach(([canId,ts])=>{{
    const row=document.createElement('div');
    row.className='lane-row';

    const label=document.createElement('div');
    label.className='lane-label';
    label.textContent=canId;

    const wrap=document.createElement('div');
    wrap.className='lane-canvas-wrap';
    const canvas=document.createElement('canvas');
    wrap.appendChild(canvas);

    row.appendChild(label);
    row.appendChild(wrap);
    container.appendChild(row);

    // Pick lane-level anomalies matching this CAN ID
    const laneAnomsForId=laneAnoms.filter(a=>a.can_id_hex===canId);

    const rugData=ts.map(t=>{{return{{x:t,y:0.5}}}});
    const anomData=laneAnomsForId.map(a=>{{return{{x:a.t,y:0.5,_a:a}}}});

    new Chart(canvas.getContext('2d'),{{
      type:'scatter',
      data:{{
        datasets:[
          {{
            label:'frames',
            data:rugData,
            pointRadius:2,pointHoverRadius:4,
            backgroundColor:'rgba(56,189,248,.45)',
            borderColor:'transparent',showLine:false,
          }},
          {{
            label:'anomalies',
            data:anomData,
            pointRadius:6,pointHoverRadius:9,
            backgroundColor:laneAnomsForId.map(a=>a.color),
            borderColor:laneAnomsForId.map(a=>a.border),
            borderWidth:1.5,showLine:false,
          }},
        ]
      }},
      options:{{
        responsive:true,maintainAspectRatio:false,
        parsing:false,
        plugins:{{
          legend:{{display:false}},
          tooltip:{{
            filter:item=>item.datasetIndex===1,
            callbacks:{{
              title:items=>`t = ${{items[0].parsed.x.toFixed(4)}} s`,
              label:ctx=>{{
                const a=ctx.raw._a;
                return[` [${{a.sev}}] ${{a.type}}`,...(a.reason?[` ${{a.reason.substring(0,60)}}${{a.reason.length>60?'…':''}}`]:[])];
              }},
            }}
          }},
        }},
        scales:{{
          x:{{type:'linear',min:tMin,max:tMax,display:false}},
          y:{{display:false,min:0,max:1}},
        }},
      }}
    }});
  }});
}})();

// ─────────────────────────────────────────────
// 6. ANOMALY LOG LIST
// ─────────────────────────────────────────────
(function(){{
  const anomalies=PAYLOAD.anomalies;
  const list=document.getElementById('anomaly-list');

  if(!anomalies||anomalies.length===0){{
    list.innerHTML='<div class="no-data"><p>✅ No anomalies detected.</p><small>The CAN log appears normal.</small></div>';
    return;
  }}

  anomalies.forEach((a,i)=>{{
    const cls=sevClass(a.severity);
    const obex=((a.observed_value!==null&&a.observed_value!==undefined)?` | Observed: <b>${{a.observed_value}}</b>`:'')+
               ((a.expected_value!==null&&a.expected_value!==undefined)?` | Expected: <b>${{a.expected_value}}</b>`:'');
    const item=document.createElement('div');
    item.className=`anomaly-item ${{cls}}`;
    item.innerHTML=`
      <div><span class="sev-badge ${{cls}}">${{a.severity}}</span></div>
      <div class="anomaly-details">
        <span class="time">[${{(i+1).toString().padStart(3,'0')}}] t=${{a.timestamp.toFixed(6)}} s &nbsp;·&nbsp; ${{a.can_id_hex||''}} ${{a.message_name||''}} ${{a.signal_name?'→ '+a.signal_name:''}}</span>
        <div class="reason"><b>${{a.anomaly_type}}</b> — ${{a.reason}}</div>
        <div class="meta-row">
          <span>📡 ${{a.detector}}</span>
          <span>🗂 ${{a.category}}</span>
          ${{obex}}
        </div>
      </div>`;
    list.appendChild(item);
  }});
}})();
</script>
</body>
</html>
"""


# ─────────────────────────────────────────────
# Public API
# ─────────────────────────────────────────────

def generate_dashboard_html(
    decoded_frames: Sequence[DecodedFrame],
    anomalies: Sequence[UnifiedAnomaly],
    summary: Dict[str, Any],
    metadata: Dict[str, Any],
    output_path: str,
    signals: Optional[List[str]] = None,
) -> None:
    """
    Generate a single self-contained HTML dashboard and write it to output_path.

    Parameters
    ----------
    decoded_frames : sequence of DecodedFrame
        Decoded CAN frames from the pipeline (read-only).
    anomalies : sequence of UnifiedAnomaly
        Detected anomalies sorted by timestamp (read-only).
    summary : dict
        Pipeline summary dict (by_severity / by_category / totals).
    metadata : dict
        Metadata key-value pairs shown in the dashboard header.
    output_path : str
        Destination file path for the generated HTML.
    signals : list[str] | None
        Optional explicit signal name filter; None = include all signals.
    """
    logger.info(f"Generating HTML dashboard → {output_path}")

    # ── Build data structures ──────────────────
    all_signal_series = _build_signal_series(decoded_frames)

    if signals:
        signal_series = {k: v for k, v in all_signal_series.items() if k in signals}
    else:
        signal_series = all_signal_series

    downsampled_signals = [
        name for name, pts in signal_series.items()
        if len(pts) >= MAX_POINTS_PER_SIGNAL
    ]

    anomaly_index = _build_anomaly_index(anomalies)
    activity_lanes = _build_activity_lanes(decoded_frames)

    # Ensure by_severity defaults so the JS always has the keys
    by_severity = {
        "critical": 0, "high": 0, "medium": 0, "low": 0,
        **(summary.get("by_severity") or {}),
    }
    safe_summary = {**summary, "by_severity": by_severity}

    # Anomaly dicts for the log list (read-only)
    anomaly_dicts = [a.to_dict() for a in anomalies]

    payload: Dict[str, Any] = {
        "signals": signal_series,
        "anomaly_index": anomaly_index,
        "activity_lanes": activity_lanes,
        "summary": safe_summary,
        "metadata": {str(k): str(v) for k, v in metadata.items()},
        "downsampled": downsampled_signals,
        "anomalies": anomaly_dicts,
        "severity_colors": SEVERITY_COLORS,
        "severity_border": SEVERITY_BORDER,
    }

    payload_json = json.dumps(payload, ensure_ascii=False, allow_nan=False)

    # ── Determine Chart.js script block ───────
    vendored = Path(__file__).resolve().parent.parent / "dashboard" / "static" / "chart.umd.min.js"
    if vendored.exists():
        logger.debug(f"Using vendored Chart.js from {vendored}")
        js_source = vendored.read_text(encoding="utf-8")
        chartjs_script = f"<script>\n{js_source}\n</script>"
    else:
        logger.warning("Vendored chart.umd.min.js not found — falling back to CDN.")
        chartjs_script = (
            '<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>'
        )

    # ── Render and write HTML ─────────────────
    html = _HTML_TEMPLATE.format(
        chartjs_script=chartjs_script,
        payload_json=payload_json,
        palette_json=json.dumps(CATEGORY_PALETTE),
        max_pts=MAX_POINTS_PER_SIGNAL,
    )

    out = Path(output_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")

    logger.info(
        f"Dashboard written: {out} "
        f"({out.stat().st_size // 1024} KB, "
        f"{len(signal_series)} signal(s), "
        f"{len(anomaly_dicts)} anomal{'y' if len(anomaly_dicts)==1 else 'ies'})"
    )
