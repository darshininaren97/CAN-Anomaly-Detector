"""
core/aggregator.py
Anomaly Aggregator for CAN Bus Anomaly Detection Integration Layer.
Collects, validates, deduplicates, sorts, and summarizes anomalies across detectors.
"""

from __future__ import annotations
from collections import defaultdict
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple
from core.models import UnifiedAnomaly, Severity, AnomalyCategory


class AnomalyAggregator:
    """
    Collects anomalies from all detector modules, performs explicit and safe
    deduplication, sorts chronologically, and calculates summary metrics.
    """

    def __init__(self) -> None:
        self._anomalies: List[UnifiedAnomaly] = []
        self._seen_signatures: Set[Tuple[Any, ...]] = set()

    def clear(self) -> None:
        """Clear all collected anomalies."""
        self._anomalies.clear()
        self._seen_signatures.clear()

    @staticmethod
    def _make_dedup_key(anomaly: UnifiedAnomaly) -> Tuple[Any, ...]:
        """
        Explicit deduplication signature.
        Rule: Two findings are only considered duplicates if they come from the SAME detector
        and share the exact same anomaly type/rule ID, timestamp (rounded to 6 decimals),
        CAN ID, and primary signal.
        Distinct anomaly categories or different detectors are NEVER merged.
        """
        ts = round(anomaly.timestamp, 6)
        sig = anomaly.signal_name or (",".join(sorted(anomaly.signals)) if anomaly.signals else "")
        return (
            anomaly.detector,
            anomaly.anomaly_type,
            anomaly.rule_id or "",
            ts,
            anomaly.can_id,
            anomaly.is_extended,
            sig,
        )

    def add(self, anomaly: UnifiedAnomaly) -> bool:
        """
        Add a single anomaly. Returns True if added, False if duplicate.
        """
        key = self._make_dedup_key(anomaly)
        if key in self._seen_signatures:
            return False
        self._seen_signatures.add(key)
        self._anomalies.append(anomaly)
        return True

    def extend(self, anomalies: Iterable[UnifiedAnomaly]) -> int:
        """
        Add multiple anomalies. Returns count of newly added anomalies.
        """
        added = 0
        for a in anomalies:
            if self.add(a):
                added += 1
        return added

    # Safety-critical signal priority rankings
    POWERTRAIN_SAFETY_SIGNALS = {
        "Engine_RPM",
        "Vehicle_Speed",
        "Wheel_Speed_FL",
        "Wheel_Speed_FR",
        "Brake_Status",
        "Gear_Position",
        "Engine_Status",
        "ABS_Active",
        "Steering_Angle",
    }

    @classmethod
    def get_signal_priority(cls, anomaly: UnifiedAnomaly) -> int:
        """
        Returns numeric priority:
        0: Critical Powertrain & Safety signals
        1: Chassis & Transmission signals
        2: Gateway / General CAN signals
        3: Non-critical Body / Comfort sensor noise
        """
        sigs = set(anomaly.signals) if anomaly.signals else set()
        if anomaly.signal_name:
            sigs.add(anomaly.signal_name)

        if sigs & cls.POWERTRAIN_SAFETY_SIGNALS:
            return 0
        if anomaly.can_id in (0x0C9, 0x1A0, 0x1B0):
            return 0
        if anomaly.can_id in (0x200, 0x400):
            return 1
        if anomaly.can_id in (0x280, 0x300, 0x380):
            return 2
        return 3

    def get_anomalies(self, sort_by_timestamp: bool = True) -> List[UnifiedAnomaly]:
        """
        Return the list of anomalies, sorted by timestamp then severity and signal priority.
        """
        if not sort_by_timestamp:
            return list(self._anomalies)

        sev_rank = {
            Severity.CRITICAL: 0,
            Severity.HIGH: 1,
            Severity.MEDIUM: 2,
            Severity.LOW: 3,
        }

        return sorted(
            self._anomalies,
            key=lambda a: (
                a.timestamp,
                sev_rank.get(a.severity, 4),
                self.get_signal_priority(a),
                a.can_id if a.can_id is not None else -1,
            )
        )

    def calculate_summary(self) -> Dict[str, Any]:
        """
        Calculate breakdown by category, severity, and detector.
        """
        anomalies = self._anomalies
        category_counts: Dict[str, int] = defaultdict(int)
        severity_counts: Dict[str, int] = defaultdict(int)
        detector_counts: Dict[str, int] = defaultdict(int)

        for a in anomalies:
            cat_str = a.category.value if isinstance(a.category, AnomalyCategory) else str(a.category)
            sev_str = a.severity.value if isinstance(a.severity, Severity) else str(a.severity)
            category_counts[cat_str] += 1
            severity_counts[sev_str] += 1
            detector_counts[a.detector] += 1

        return {
            "total_anomalies": len(anomalies),
            "by_severity": {
                "critical": severity_counts[Severity.CRITICAL.value],
                "high": severity_counts[Severity.HIGH.value],
                "medium": severity_counts[Severity.MEDIUM.value],
                "low": severity_counts[Severity.LOW.value],
            },
            "by_category": dict(category_counts),
            "by_detector": dict(detector_counts),
        }
