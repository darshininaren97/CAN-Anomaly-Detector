"""
core/models.py
Canonical Data Models for CAN Bus Anomaly Detection Integration Layer.
Provides standardized representations for CAN frames, decoded signals,
and unified anomalies while maintaining lossless fidelity with underlying detectors.
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union
import json


class Severity(str, Enum):
    """Standardized anomaly severity classification."""
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    CRITICAL = "CRITICAL"


class AnomalyCategory(str, Enum):
    """Categorization of detected anomalies across all modules."""
    RANGE = "RANGE"
    CONTRADICTORY_SIGNAL = "CONTRADICTORY_SIGNAL"
    SIGNAL_CORRELATION = "SIGNAL_CORRELATION"
    TIMING_DEVIATION = "TIMING_DEVIATION"
    TIMING_FLOODING = "TIMING_FLOODING"
    DUPLICATE_BURST = "DUPLICATE_BURST"
    TIMING_TIMEOUT = "TIMING_TIMEOUT"
    MESSAGE_TIMEOUT = "MESSAGE_TIMEOUT"
    SIGNAL_TIMEOUT = "SIGNAL_TIMEOUT"
    ECU_BEHAVIOR_DEVIATION = "ECU_BEHAVIOR_DEVIATION"
    FRAME_FORMAT = "FRAME_FORMAT"
    DATA_CORRUPTION = "DATA_CORRUPTION"
    CRC_MISMATCH = "CRC_MISMATCH"
    DECODING_ERROR = "DECODING_ERROR"
    UNKNOWN_MESSAGE = "UNKNOWN_MESSAGE"
    OTHER = "OTHER"


@dataclass(frozen=True, slots=True)
class CANFrame:
    """
    Standard immutable CAN frame representation.
    """
    timestamp: float
    can_id: int
    dlc: int
    data: bytes
    channel: int = 1
    direction: str = "Rx"
    frame_type: str = "d"
    is_extended: bool = False
    raw_line: str = ""
    line_number: Optional[int] = None
    ecu: Optional[str] = None

    @property
    def hex_id(self) -> str:
        """Formatted hexadecimal representation of CAN ID."""
        width = 8 if self.is_extended else 3
        return f"0x{self.can_id:0{width}X}"

    @property
    def data_hex(self) -> str:
        """Uppercase hex string of payload bytes."""
        return self.data.hex().upper()

    @property
    def is_remote(self) -> bool:
        """True if remote transmission request (RTR)."""
        return self.frame_type.lower() == "r"

    def to_dict(self) -> Dict[str, Any]:
        """Convert frame to dictionary representation."""
        return {
            "timestamp": self.timestamp,
            "can_id": self.can_id,
            "hex_id": self.hex_id,
            "dlc": self.dlc,
            "data": self.data_hex,
            "channel": self.channel,
            "direction": self.direction,
            "frame_type": self.frame_type,
            "is_extended": self.is_extended,
            "ecu": self.ecu,
            "line_number": self.line_number,
        }


@dataclass(frozen=True, slots=True)
class DecodedSignal:
    """
    Standard representation of a decoded signal value from a CAN frame.
    """
    name: str
    message_name: str
    can_id: int
    timestamp: float
    raw_value: Union[int, float]
    physical_value: Union[int, float]
    unit: str = ""
    minimum: Optional[float] = None
    maximum: Optional[float] = None
    factor: float = 1.0
    offset: float = 0.0
    is_extended: bool = False
    comment: str = ""
    enum_name: Optional[str] = None

    @property
    def has_usable_range(self) -> bool:
        """True if signal has both minimum and maximum defined in DBC."""
        return self.minimum is not None and self.maximum is not None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "message_name": self.message_name,
            "can_id": self.can_id,
            "timestamp": self.timestamp,
            "raw_value": self.raw_value,
            "physical_value": self.physical_value,
            "unit": self.unit,
            "minimum": self.minimum,
            "maximum": self.maximum,
            "factor": self.factor,
            "offset": self.offset,
            "is_extended": self.is_extended,
        }


@dataclass
class DecodedFrame:
    """
    Represents a CAN frame together with all of its successfully decoded signals.
    """
    frame: CANFrame
    message_name: str
    signals: Dict[str, DecodedSignal] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)


@dataclass
class UnifiedAnomaly:
    """
    Standardized Anomaly model across all detectors.
    Preserves original detector metadata, raw values, and specific diagnostics.
    """
    timestamp: float
    anomaly_type: str
    category: AnomalyCategory
    severity: Severity
    detector: str
    reason: str
    can_id: Optional[int] = None
    can_id_hex: Optional[str] = None
    message_name: Optional[str] = None
    signal_name: Optional[str] = None
    signals: List[str] = field(default_factory=list)
    observed_value: Optional[Any] = None
    expected_value: Optional[Any] = None
    expected_range: Optional[Tuple[Optional[float], Optional[float]]] = None
    unit: Optional[str] = None
    is_extended: bool = False
    ecu: Optional[str] = None
    rule_id: Optional[str] = None
    context: Dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.can_id is not None and not self.can_id_hex:
            width = 8 if self.is_extended else 3
            self.can_id_hex = f"0x{self.can_id:0{width}X}"
        if self.signal_name and self.signal_name not in self.signals:
            self.signals.append(self.signal_name)
        elif not self.signal_name and len(self.signals) == 1:
            self.signal_name = self.signals[0]

    def to_dict(self) -> Dict[str, Any]:
        """Convert anomaly object to dictionary for JSON serialization."""
        d: Dict[str, Any] = {
            "timestamp": round(self.timestamp, 6),
            "anomaly_type": self.anomaly_type,
            "category": self.category.value if isinstance(self.category, AnomalyCategory) else str(self.category),
            "severity": self.severity.value if isinstance(self.severity, Severity) else str(self.severity),
            "detector": self.detector,
            "can_id": self.can_id,
            "can_id_hex": self.can_id_hex,
            "message_name": self.message_name,
            "signal_name": self.signal_name,
            "signals": self.signals,
            "observed_value": self.observed_value,
            "expected_value": self.expected_value,
            "expected_range": list(self.expected_range) if self.expected_range is not None else None,
            "unit": self.unit,
            "is_extended": self.is_extended,
            "ecu": self.ecu,
            "rule_id": self.rule_id,
            "reason": self.reason,
        }
        if self.context:
            d["context"] = self.context
        return d

    def to_json(self, indent: int = 2) -> str:
        """Convert anomaly object to JSON string."""
        return json.dumps(self.to_dict(), indent=indent)
