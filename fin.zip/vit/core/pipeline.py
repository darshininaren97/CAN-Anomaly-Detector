"""
core/pipeline.py
Unified CAN Bus Anomaly Detection Pipeline Orchestrator.
Coordinates DBC parsing, CAN log ingestion, signal decoding, multi-detector execution,
result aggregation, and formatted reporting with strict fault isolation.
"""

from __future__ import annotations
import logging
import os
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

from core.aggregator import AnomalyAggregator
from core.models import CANFrame, DecodedFrame, UnifiedAnomaly
from core.reporter import UnifiedReporter
from detectors.base import BaseAnomalyDetector
from detectors.registry import DetectorRegistry
from parsers.dbc_parser import DBCDatabase, DBCParser
from parsers.log_parser import CANLogParser
from parsers.signal_decoder import SignalDecoder

from parsers.exporter import export_parsed_can_csv

logger = logging.getLogger("can_pipeline")


@dataclass
class PipelineConfig:
    """Configuration options for the unified anomaly detection pipeline."""
    dbc_path: str
    log_path: str
    detectors: str = "all"
    output_path: Optional[str] = None
    output_format: str = "text"  # 'text', 'json', 'csv'
    export_parsed_csv_path: Optional[str] = None
    integrity_config_path: Optional[str] = None
    dashboard_path: Optional[str] = None
    verbose: bool = False
    stop_on_dbc_error: bool = True


@dataclass
class PipelineResult:
    """Execution results and diagnostics from running the pipeline."""
    success: bool
    total_frames: int
    decoded_frames: int
    unknown_messages: int
    parsing_warnings: int
    malformed_lines: int
    anomalies: List[UnifiedAnomaly]
    summary: Dict[str, Any]
    detector_errors: Dict[str, str] = field(default_factory=dict)
    execution_time_seconds: float = 0.0
    report_text: Optional[str] = None


class UnifiedAnomalyPipeline:
    """
    Main orchestration engine integrating DBC parsing, log streaming,
    signal decoding, modular anomaly detectors, aggregation, and reporting.
    """

    def __init__(self, config: PipelineConfig) -> None:
        self.config = config
        self.aggregator = AnomalyAggregator()
        self.detectors: List[BaseAnomalyDetector] = DetectorRegistry.create_detectors(config.detectors)

    def run(self) -> PipelineResult:
        """Execute the end-to-end CAN anomaly detection pipeline."""
        start_time = time.perf_counter()
        self.aggregator.clear()
        detector_errors: Dict[str, str] = {}

        # 1. Parse DBC Database
        logger.info(f"Loading DBC definition from: {self.config.dbc_path}")
        if not os.path.exists(self.config.dbc_path):
            raise FileNotFoundError(f"DBC file not found: {self.config.dbc_path}")

        try:
            db = DBCParser.parse_file(self.config.dbc_path)
            logger.info(f"Successfully loaded DBC with {len(db.messages)} message definitions.")
        except Exception as e:
            logger.error(f"DBC parsing error: {e}")
            if self.config.stop_on_dbc_error:
                raise
            db = DBCDatabase(filename=self.config.dbc_path)

        # 2. Parse CAN Log & Decode Frames
        logger.info(f"Ingesting CAN log from: {self.config.log_path}")
        if not os.path.exists(self.config.log_path):
            raise FileNotFoundError(f"CAN log file not found: {self.config.log_path}")

        decoder = SignalDecoder(db)
        raw_frames: List[CANFrame] = []
        decoded_frames: List[DecodedFrame] = []
        unknown_count = 0
        warning_count = 0
        error_count = 0

        for item in CANLogParser.parse_file(self.config.log_path):
            if isinstance(item, tuple):
                level, msg = item
                if level == "error":
                    error_count += 1
                    logger.warning(f"Log parser error: {msg}")
                else:
                    warning_count += 1
                    if self.config.verbose:
                        logger.debug(f"Log parser warning: {msg}")
                continue

            frame: CANFrame = item
            raw_frames.append(frame)

            # Attempt signal decoding
            df = decoder.decode_frame(frame)
            if df is not None:
                decoded_frames.append(df)
            else:
                unknown_count += 1
                if self.config.verbose:
                    logger.debug(f"Frame CAN ID {frame.hex_id} not mapped in DBC.")

        logger.info(f"Ingested {len(raw_frames)} frames ({len(decoded_frames)} matched DBC definitions).")

        # Optional: Export human-readable parsed CAN data CSV
        if self.config.export_parsed_csv_path:
            try:
                logger.info(f"Exporting human-readable parsed CAN data CSV to: {self.config.export_parsed_csv_path}")
                export_parsed_can_csv(
                    dbc_path=self.config.dbc_path,
                    log_path=self.config.log_path,
                    output_csv_path=self.config.export_parsed_csv_path,
                )
            except Exception as e:
                logger.error(f"Error exporting parsed data CSV: {e}")

        # 3. Execute Enabled Anomaly Detectors with Error Isolation
        for detector in self.detectors:
            if not detector.is_enabled:
                continue

            logger.info(f"Running detector: {detector.name}")
            try:
                detected = detector.analyze(
                    frames=raw_frames,
                    decoded_frames=decoded_frames,
                    db=db,
                    context={"config": self.config},
                )
                self.aggregator.extend(detected)
                logger.info(f"Detector '{detector.name}' completed with {len(detected)} findings.")
            except Exception as e:
                logger.error(f"Error executing detector '{detector.name}': {e}", exc_info=self.config.verbose)
                detector_errors[detector.name] = str(e)

        # 4. Aggregation and Summary Calculation
        all_anomalies = self.aggregator.get_anomalies(sort_by_timestamp=True)
        summary = self.aggregator.calculate_summary()
        summary["total_frames_processed"] = len(raw_frames)
        summary["total_frames_decoded"] = len(decoded_frames)
        summary["unknown_can_messages"] = unknown_count
        summary["malformed_log_lines"] = error_count
        summary["parser_warnings"] = warning_count
        if detector_errors:
            summary["detector_errors"] = detector_errors

        elapsed = round(time.perf_counter() - start_time, 4)
        summary["execution_time_seconds"] = elapsed

        # 5. Formatted Output Generation
        metadata = {
            "DBC File": self.config.dbc_path,
            "CAN Log File": self.config.log_path,
            "Active Detectors": ", ".join(d.name for d in self.detectors if d.is_enabled),
            "Total Frames Processed": len(raw_frames),
            "Execution Time": f"{elapsed:.4f} s",
        }

        report_text = UnifiedReporter.generate_text_report(all_anomalies, summary, metadata)

        # Export if output path specified
        if self.config.output_path:
            fmt = self.config.output_format.lower()
            logger.info(f"Writing {fmt.upper()} report to: {self.config.output_path}")
            if fmt == "json":
                UnifiedReporter.write_json_report(
                    all_anomalies, summary, self.config.output_path, metadata=metadata
                )
            elif fmt == "csv":
                UnifiedReporter.write_csv_report(all_anomalies, self.config.output_path)
            else:
                UnifiedReporter.write_text_report(
                    all_anomalies, summary, self.config.output_path, metadata=metadata
                )

        # Optional dashboard generation (fully additive — no-op if not configured)
        if self.config.dashboard_path:
            try:
                from core.dashboard import generate_dashboard_html
                generate_dashboard_html(
                    decoded_frames=decoded_frames,
                    anomalies=all_anomalies,
                    summary=summary,
                    metadata=metadata,
                    output_path=self.config.dashboard_path,
                )
            except Exception as e:
                logger.error(f"Dashboard generation failed: {e}", exc_info=self.config.verbose)

        return PipelineResult(
            success=True,
            total_frames=len(raw_frames),
            decoded_frames=len(decoded_frames),
            unknown_messages=unknown_count,
            parsing_warnings=warning_count,
            malformed_lines=error_count,
            anomalies=all_anomalies,
            summary=summary,
            detector_errors=detector_errors,
            execution_time_seconds=elapsed,
            report_text=report_text,
        )
