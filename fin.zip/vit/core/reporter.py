"""
core/reporter.py
Unified Report Generator for CAN Bus Anomaly Detection Integration Layer.
Supports Human-Readable Text / Console, JSON, and CSV export formats.
"""

from __future__ import annotations
import csv
import json
import os
import sys
from typing import Any, Dict, List, Optional, Union
from core.models import UnifiedAnomaly, Severity, AnomalyCategory


def clean_number(val: Any) -> str:
    """Format floating numbers cleanly without extraneous trailing zeros."""
    if val is None:
        return "N/A"
    if isinstance(val, bool):
        return str(val)
    if isinstance(val, int):
        return str(val)
    if isinstance(val, float):
        if val == int(val):
            return str(int(val))
        s = f"{val:.6f}"
        while s.endswith("0"):
            s = s[:-1]
        if s.endswith("."):
            s = s[:-1]
        return s
    return str(val)


class UnifiedReporter:
    """Multi-format report generator for unified CAN anomalies."""

    @staticmethod
    def format_anomaly_text(anomaly: UnifiedAnomaly, index: Optional[int] = None) -> str:
        """Format a single unified anomaly into a clean text block."""
        idx_prefix = f"[{index}] " if index is not None else ""
        header = f"{idx_prefix}[{anomaly.anomaly_type.upper()}] (Category: {anomaly.category.value}, Severity: {anomaly.severity.value})"
        lines = [header]

        lines.append(f"  Timestamp:        {anomaly.timestamp:.6f} s")
        if anomaly.can_id_hex:
            lines.append(f"  CAN ID:           {anomaly.can_id_hex} (Decimal: {anomaly.can_id}, Extended: {'Yes' if anomaly.is_extended else 'No'})")
        if anomaly.message_name:
            lines.append(f"  Message Name:     {anomaly.message_name}")
        if anomaly.signal_name:
            lines.append(f"  Signal Name:      {anomaly.signal_name}")
        elif anomaly.signals:
            lines.append(f"  Signals Involved: {', '.join(anomaly.signals)}")

        if anomaly.observed_value is not None:
            unit_str = f" {anomaly.unit}" if anomaly.unit else ""
            lines.append(f"  Observed Value:   {clean_number(anomaly.observed_value)}{unit_str}")

        if anomaly.expected_range is not None:
            min_v, max_v = anomaly.expected_range
            unit_str = f" {anomaly.unit}" if anomaly.unit else ""
            lines.append(f"  Expected Range:   [{clean_number(min_v)} to {clean_number(max_v)}]{unit_str}")
        elif anomaly.expected_value is not None:
            unit_str = f" {anomaly.unit}" if anomaly.unit else ""
            lines.append(f"  Expected Value:   {clean_number(anomaly.expected_value)}{unit_str}")

        if anomaly.rule_id:
            lines.append(f"  Rule ID:          {anomaly.rule_id}")
        if anomaly.ecu:
            lines.append(f"  Source ECU:       {anomaly.ecu}")
        lines.append(f"  Detector:         {anomaly.detector}")
        lines.append(f"  Reason:           {anomaly.reason}")

        if anomaly.context:
            ctx_items = [f"{k}={clean_number(v)}" for k, v in anomaly.context.items()]
            lines.append(f"  Context:          {', '.join(ctx_items)}")

        return "\n".join(lines)

    @classmethod
    def generate_text_report(
        cls,
        anomalies: List[UnifiedAnomaly],
        summary: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """Generate complete human-readable report."""
        lines = [
            "=" * 72,
            " CAN BUS UNIFIED ANOMALY DETECTION REPORT",
            "=" * 72,
            "",
        ]

        if metadata:
            lines.append("METADATA:")
            for k, v in metadata.items():
                lines.append(f"  {k:<22}: {v}")
            lines.append("")

        lines.append("SUMMARY:")
        lines.append(f"  Total Anomalies Detected : {summary.get('total_anomalies', len(anomalies))}")
        
        by_sev = summary.get("by_severity", {})
        lines.append("  By Severity:")
        for s in ["critical", "high", "medium", "low"]:
            lines.append(f"    - {s.upper():<10} : {by_sev.get(s, 0)}")

        by_cat = summary.get("by_category", {})
        if by_cat:
            lines.append("  By Category:")
            for c, cnt in sorted(by_cat.items()):
                lines.append(f"    - {c:<24} : {cnt}")

        by_det = summary.get("by_detector", {})
        if by_det:
            lines.append("  By Detector Module:")
            for d, cnt in sorted(by_det.items()):
                lines.append(f"    - {d:<24} : {cnt}")

        lines.append("")
        lines.append("-" * 72)
        lines.append("DETECTION DETAILS:")
        lines.append("-" * 72)

        if not anomalies:
            lines.append("  [OK] No anomalies detected. CAN bus traffic conforms to definitions.")
        else:
            for idx, anom in enumerate(anomalies, 1):
                lines.append(cls.format_anomaly_text(anom, index=idx))
                lines.append("")

        lines.append("=" * 72)
        return "\n".join(lines)

    @classmethod
    def write_text_report(
        cls,
        anomalies: List[UnifiedAnomaly],
        summary: Dict[str, Any],
        filepath: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Write human-readable report to text file."""
        text = cls.generate_text_report(anomalies, summary, metadata)
        parent_dir = os.path.dirname(filepath)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(text)

    @classmethod
    def generate_json_dict(
        cls,
        anomalies: List[UnifiedAnomaly],
        summary: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Generate structured dictionary suitable for JSON serialization."""
        return {
            "metadata": metadata or {},
            "summary": summary,
            "anomalies": [a.to_dict() for a in anomalies],
        }

    @classmethod
    def write_json_report(
        cls,
        anomalies: List[UnifiedAnomaly],
        summary: Dict[str, Any],
        filepath: str,
        metadata: Optional[Dict[str, Any]] = None,
        indent: int = 2,
    ) -> None:
        """Write structured report to JSON file."""
        data = cls.generate_json_dict(anomalies, summary, metadata)
        parent_dir = os.path.dirname(filepath)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=indent)

    @classmethod
    def write_csv_report(
        cls,
        anomalies: List[UnifiedAnomaly],
        filepath: str,
    ) -> None:
        """Write anomalies to tabular CSV file."""
        parent_dir = os.path.dirname(filepath)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)

        fieldnames = [
            "timestamp",
            "anomaly_type",
            "category",
            "severity",
            "detector",
            "can_id_hex",
            "can_id_dec",
            "is_extended",
            "message_name",
            "signal_name",
            "signals",
            "observed_value",
            "expected_value",
            "expected_range_min",
            "expected_range_max",
            "unit",
            "ecu",
            "rule_id",
            "reason",
        ]

        with open(filepath, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for a in anomalies:
                min_val = a.expected_range[0] if a.expected_range is not None else ""
                max_val = a.expected_range[1] if a.expected_range is not None else ""
                writer.writerow({
                    "timestamp": f"{a.timestamp:.6f}",
                    "anomaly_type": a.anomaly_type,
                    "category": a.category.value if isinstance(a.category, AnomalyCategory) else str(a.category),
                    "severity": a.severity.value if isinstance(a.severity, Severity) else str(a.severity),
                    "detector": a.detector,
                    "can_id_hex": a.can_id_hex or "",
                    "can_id_dec": a.can_id if a.can_id is not None else "",
                    "is_extended": "true" if a.is_extended else "false",
                    "message_name": a.message_name or "",
                    "signal_name": a.signal_name or "",
                    "signals": ";".join(a.signals),
                    "observed_value": clean_number(a.observed_value) if a.observed_value is not None else "",
                    "expected_value": clean_number(a.expected_value) if a.expected_value is not None else "",
                    "expected_range_min": clean_number(min_val) if min_val != "" else "",
                    "expected_range_max": clean_number(max_val) if max_val != "" else "",
                    "unit": a.unit or "",
                    "ecu": a.ecu or "",
                    "rule_id": a.rule_id or "",
                    "reason": a.reason,
                })
