"""
CAN Message and Signal Timing Monitor.
Tracks inter-frame arrival intervals against DBC cycle-time specifications,
detects missing messages and communication timeouts using configurable multipliers,
and prevents false positives on initial arrival, end-of-log, or short intervals.
"""

from typing import Dict, List, Optional, Set, Tuple
from models import (
    CANFrame,
    DBCMessage,
    TimingDefinition,
    Anomaly,
    AnomalyType,
    ProcessingStatus
)
from dbc_parser import DBCParser


class TimingMonitor:
    """Monitors CAN message arrival timing and detects timeouts."""

    def __init__(
        self,
        dbc_messages: Dict[int, DBCMessage],
        timeout_multiplier: float = 1.5,
        external_timing: Optional[Dict[int, float]] = None,
        dbc_parser: Optional[DBCParser] = None,
        min_timeout_ms: float = 0.0,
    ):
        """
        Initialize TimingMonitor.

        :param dbc_messages: Dictionary of CAN ID -> DBCMessage definitions.
        :param timeout_multiplier: Multiplier applied to expected cycle time to determine timeout threshold (default 1.5).
        :param external_timing: Optional dictionary of CAN ID -> expected_period_ms supplementing DBC.
        :param dbc_parser: Optional DBCParser instance for multiplexer decoding.
        :param min_timeout_ms: Minimum threshold floor in milliseconds (default 0.0).
        """
        self.dbc_messages = dbc_messages
        self.timeout_multiplier = timeout_multiplier
        self.min_timeout_ms = min_timeout_ms
        self.dbc_parser = dbc_parser or DBCParser()
        self.timing_definitions: Dict[int, TimingDefinition] = {}
        self.last_timestamps: Dict[int, float] = {}
        self.first_timestamps: Dict[int, float] = {}
        self.frame_counts: Dict[int, int] = {}

        # Build timing definitions dynamically from DBC and optional external config
        self._build_timing_definitions(external_timing or {})

    def _build_timing_definitions(self, external_timing: Dict[int, float]) -> None:
        """Dynamically construct timing definitions without hard-coding."""
        for can_id, msg in self.dbc_messages.items():
            expected_period = None

            # 1. External configuration takes precedence if explicitly provided
            if can_id in external_timing:
                expected_period = external_timing[can_id]
            # 2. Dynamic DBC GenMsgCycleTime
            elif msg.cycle_time_ms is not None and msg.cycle_time_ms > 0:
                expected_period = msg.cycle_time_ms

            if expected_period is not None and expected_period > 0:
                self.timing_definitions[can_id] = TimingDefinition.create(
                    can_id=can_id,
                    message_name=msg.name,
                    expected_period_ms=expected_period,
                    multiplier=self.timeout_multiplier
                )

    def process_frame(self, frame: CANFrame) -> Tuple[ProcessingStatus, Optional[Anomaly]]:
        """
        Process a single CAN frame for timing analysis.

        Returns:
            Tuple of (ProcessingStatus, Optional[Anomaly])
        """
        can_id = frame.can_id
        timestamp = frame.timestamp

        # Check if CAN ID is known in DBC
        if can_id not in self.dbc_messages:
            return ProcessingStatus.UNKNOWN_MESSAGE, None

        msg = self.dbc_messages[can_id]

        # Check if message has an expected cycle time
        if can_id not in self.timing_definitions:
            # Update last timestamp for book-keeping without evaluating timeout
            self.last_timestamps[can_id] = timestamp
            self.frame_counts[can_id] = self.frame_counts.get(can_id, 0) + 1
            return ProcessingStatus.NOT_CHECKED, None

        timing_def = self.timing_definitions[can_id]
        self.frame_counts[can_id] = self.frame_counts.get(can_id, 0) + 1

        # First observation of this message establishes baseline (no timeout)
        if can_id not in self.last_timestamps:
            self.last_timestamps[can_id] = timestamp
            self.first_timestamps[can_id] = timestamp
            return ProcessingStatus.VALID, None

        prev_timestamp = self.last_timestamps[can_id]
        actual_interval_s = timestamp - prev_timestamp
        actual_interval_ms = actual_interval_s * 1000.0

        # Update last seen timestamp
        self.last_timestamps[can_id] = timestamp

        # Detect Timeout
        effective_threshold_ms = max(timing_def.timeout_threshold_ms, getattr(self, "min_timeout_ms", 0.0))
        if actual_interval_ms > effective_threshold_ms:
            # Determine active signals carried by this message
            active_signals = self.dbc_parser.get_active_signals(msg, frame.payload)

            reason_msg = (
                f"Expected {msg.name} ({frame.can_id_hex}) message was not received within "
                f"configured timeout window of {effective_threshold_ms:.1f} ms "
                f"(expected {timing_def.expected_period_ms:.1f} ms, multiplier {self.timeout_multiplier}x). "
                f"Actual gap was {actual_interval_ms:.1f} ms."
            )

            anomaly = Anomaly(
                timestamp=timestamp,
                anomaly_type=AnomalyType.MESSAGE_TIMEOUT,
                can_id=can_id,
                can_id_hex=frame.can_id_hex,
                message_name=msg.name,
                reason=reason_msg,
                affected_signals=active_signals,
                details={
                    "previous_timestamp": round(prev_timestamp, 6),
                    "current_timestamp": round(timestamp, 6),
                    "expected_period_ms": round(timing_def.expected_period_ms, 2),
                    "allowed_gap_ms": round(timing_def.timeout_threshold_ms, 2),
                    "actual_gap_ms": round(actual_interval_ms, 2),
                    "actual_gap_s": round(actual_interval_s, 6),
                    "timeout_multiplier": self.timeout_multiplier
                },
                line_number=frame.line_number
            )
            return ProcessingStatus.VALID, anomaly

        # Note: If actual_interval_ms < expected_period_ms, this is a fast arrival.
        # Per specification: Message flooding is NOT an anomaly in this module.
        return ProcessingStatus.VALID, None

    def check_end_of_log_timeouts(self, final_timestamp: float) -> List[Anomaly]:
        """
        Optional evaluation if an explicit monitoring end time is enforced.
        By default (Section 10), timeouts are NOT assumed after the final frame
        unless an explicit observation window boundary is passed.
        """
        # Kept for explicit window boundary checks if required
        return []
