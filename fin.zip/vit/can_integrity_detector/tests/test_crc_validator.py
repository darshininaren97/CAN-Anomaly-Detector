"""
Unit tests for Application-Layer CRC Validator.
Tests parametric CRC calculations (AUTOSAR, SAE J1850, Checksum),
missing definition handling (NOT_CHECKED), mismatch detection, and boundary cases.
"""

import unittest
from models import CANFrame, CRCDefinition, AnomalyType, ProcessingStatus
from crc_validator import CRCValidator


class TestCRCValidator(unittest.TestCase):

    def test_missing_definition_returns_not_checked(self):
        # Validator with no definition for 0x1A0
        validator = CRCValidator({})
        frame = CANFrame(
            timestamp=1.0,
            channel=1,
            can_id=0x1A0,
            direction="Rx",
            frame_type="d",
            dlc=8,
            payload=bytes.fromhex("0102030405060708")
        )
        status, anomaly, reason = validator.validate_frame(frame)
        self.assertEqual(status, ProcessingStatus.NOT_CHECKED)
        self.assertIsNone(anomaly)
        self.assertIn("unavailable", reason)

    def test_crc8_autosar_calculation(self):
        # Test vector: [0x10, 0x20, 0x30, 0x40] -> compute CRC-8 AUTOSAR
        data = bytes([0x10, 0x20, 0x30, 0x40])
        crc = CRCValidator.calculate_crc(
            data=data,
            width=8,
            polynomial=0x2F,
            init_val=0xFF,
            xor_out=0xFF,
            reflect_in=False,
            reflect_out=False
        )
        self.assertIsInstance(crc, int)
        self.assertTrue(0 <= crc <= 0xFF)

    def test_crc8_autosar_valid_frame(self):
        # Calculate expected CRC for 7 data bytes
        data_bytes = bytes([0x10, 0x00, 0x28, 0x33, 0x00, 0x00, 0x00])
        expected_crc = CRCValidator.calculate_crc(
            data=data_bytes,
            width=8,
            polynomial=0x2F,
            init_val=0xFF,
            xor_out=0xFF,
            reflect_in=False,
            reflect_out=False
        )

        crc_defs = {
            0x0C9: CRCDefinition(
                can_id=0x0C9,
                message_name="EngineData",
                algorithm="CRC8_AUTOSAR",
                start_bit=56, # byte 7
                bit_length=8,
                covered_bytes=[0, 1, 2, 3, 4, 5, 6]
            )
        }
        validator = CRCValidator(crc_defs)

        payload_valid = data_bytes + bytes([expected_crc])
        frame_valid = CANFrame(1.0, 1, 0x0C9, "Rx", "d", 8, payload_valid)

        status, anomaly, _ = validator.validate_frame(frame_valid)
        self.assertEqual(status, ProcessingStatus.VALID)
        self.assertIsNone(anomaly)

    def test_crc8_autosar_mismatch(self):
        crc_defs = {
            0x0C9: CRCDefinition(
                can_id=0x0C9,
                message_name="EngineData",
                algorithm="CRC8_AUTOSAR",
                start_bit=56,
                bit_length=8,
                covered_bytes=[0, 1, 2, 3, 4, 5, 6]
            )
        }
        validator = CRCValidator(crc_defs)

        # Corrupted CRC byte (0x00 instead of calculated)
        payload_corrupt = bytes([0x10, 0x00, 0x28, 0x33, 0x00, 0x00, 0x00, 0x00])
        frame_corrupt = CANFrame(1.0, 1, 0x0C9, "Rx", "d", 8, payload_corrupt)

        status, anomaly, _ = validator.validate_frame(frame_corrupt)
        self.assertEqual(status, ProcessingStatus.VALID)
        self.assertIsNotNone(anomaly)
        self.assertEqual(anomaly.anomaly_type, AnomalyType.CRC_MISMATCH)
        self.assertEqual(anomaly.can_id, 0x0C9)
        self.assertIn("CRC mismatch", anomaly.reason)

    def test_checksum_xor8(self):
        data_bytes = bytes([0x12, 0x34, 0x56])
        calc_xor = 0x12 ^ 0x34 ^ 0x56

        crc_defs = {
            0x300: CRCDefinition(
                can_id=0x300,
                message_name="TestMsg",
                algorithm="CHECKSUM_XOR8",
                start_bit=24,
                bit_length=8,
                covered_bytes=[0, 1, 2]
            )
        }
        validator = CRCValidator(crc_defs)

        # Valid frame
        frame_valid = CANFrame(1.0, 1, 0x300, "Rx", "d", 4, data_bytes + bytes([calc_xor]))
        status_v, anom_v, _ = validator.validate_frame(frame_valid)
        self.assertIsNone(anom_v)

        # Invalid frame
        frame_inv = CANFrame(1.0, 1, 0x300, "Rx", "d", 4, data_bytes + bytes([calc_xor ^ 0xFF]))
        status_i, anom_i, _ = validator.validate_frame(frame_inv)
        self.assertIsNotNone(anom_i)
        self.assertEqual(anom_i.anomaly_type, AnomalyType.CRC_MISMATCH)

    def test_short_payload_insufficient_data(self):
        crc_defs = {
            0x0C9: CRCDefinition(
                can_id=0x0C9,
                message_name="EngineData",
                algorithm="CRC8_AUTOSAR",
                start_bit=56,
                bit_length=8,
                covered_bytes=[0, 1, 2, 3, 4, 5, 6]
            )
        }
        validator = CRCValidator(crc_defs)

        # Payload only 3 bytes long
        frame = CANFrame(1.0, 1, 0x0C9, "Rx", "d", 3, bytes([0x01, 0x02, 0x03]))
        status, anomaly, reason = validator.validate_frame(frame)
        self.assertEqual(status, ProcessingStatus.INSUFFICIENT_DATA)
        self.assertIsNone(anomaly) # Not a CRC mismatch


if __name__ == "__main__":
    unittest.main()
