"""
Unit tests for Payload Integrity Validator.
Tests deterministic corruption detection: DLC vs byte length mismatch,
insufficient payload vs DBC size, DLC=0 frames, type safety for None payload,
and case/enum-insensitive frame_type matching.
"""

import unittest
from models import CANFrame, DBCMessage, AnomalyType, ProcessingStatus, FrameType
from integrity_validator import IntegrityValidator


class TestIntegrityValidator(unittest.TestCase):

    def setUp(self):
        self.dbc_messages = {
            0x0C9: DBCMessage(
                can_id=0x0C9,
                name="EngineData",
                dlc=8,
                sender="Engine_ECU"
            ),
            0x200: DBCMessage(
                can_id=0x200,
                name="FuelData",
                dlc=4,
                sender="Engine_ECU"
            )
        }
        self.validator = IntegrityValidator(self.dbc_messages)

    def test_valid_payload(self):
        frame = CANFrame(
            timestamp=1.0,
            channel=1,
            can_id=0x0C9,
            direction="Rx",
            frame_type="d",
            dlc=8,
            payload=bytes.fromhex("1000283300000000")
        )
        status, anomaly = self.validator.validate_frame(frame)
        self.assertEqual(status, ProcessingStatus.VALID)
        self.assertIsNone(anomaly)

    def test_dlc_mismatch_with_actual_bytes(self):
        # Frame claims DLC=8, but only 4 bytes provided
        frame = CANFrame(
            timestamp=2.0,
            channel=1,
            can_id=0x0C9,
            direction="Rx",
            frame_type="d",
            dlc=8,
            payload=bytes.fromhex("10002833")
        )
        status, anomaly = self.validator.validate_frame(frame)
        self.assertEqual(status, ProcessingStatus.INVALID_FRAME)
        self.assertIsNotNone(anomaly)
        self.assertEqual(anomaly.anomaly_type, AnomalyType.DATA_CORRUPTION)
        self.assertIn("mismatch", anomaly.reason.lower())

    def test_insufficient_payload_for_dbc_definition(self):
        # DBC defines DLC=8 for 0x0C9, but frame received with DLC=4 and 4 bytes
        frame = CANFrame(
            timestamp=3.0,
            channel=1,
            can_id=0x0C9,
            direction="Rx",
            frame_type="d",
            dlc=4,
            payload=bytes.fromhex("10002833")
        )
        status, anomaly = self.validator.validate_frame(frame)
        self.assertEqual(status, ProcessingStatus.INSUFFICIENT_DATA)
        self.assertIsNotNone(anomaly)
        self.assertEqual(anomaly.anomaly_type, AnomalyType.DATA_CORRUPTION)
        self.assertIn("Insufficient payload length", anomaly.reason)

    def test_dlc_zero_known_message(self):
        # Known message 0x0C9 expecting 8 bytes received with DLC=0
        frame = CANFrame(
            timestamp=6.7,
            channel=1,
            can_id=0x0C9,
            direction="Rx",
            frame_type="d",
            dlc=0,
            payload=b""
        )
        status, anomaly = self.validator.validate_frame(frame)
        self.assertEqual(status, ProcessingStatus.INSUFFICIENT_DATA)
        self.assertIsNotNone(anomaly)
        self.assertEqual(anomaly.anomaly_type, AnomalyType.DATA_CORRUPTION)

    def test_dlc_zero_unknown_message_with_enum_and_string_frametype(self):
        # Unknown message with DLC=0 using FrameType Enum
        frame_enum = CANFrame(
            timestamp=7.0,
            channel=1,
            can_id=0x999,
            direction="Rx",
            frame_type=FrameType.DATA,
            dlc=0,
            payload=b""
        )
        status, anomaly = self.validator.validate_frame(frame_enum)
        self.assertEqual(status, ProcessingStatus.INVALID_FRAME)
        self.assertIsNotNone(anomaly)
        self.assertEqual(anomaly.anomaly_type, AnomalyType.DATA_CORRUPTION)

        # Unknown message with DLC=0 using uppercase string "DATA"
        frame_str = CANFrame(
            timestamp=7.1,
            channel=1,
            can_id=0x999,
            direction="Rx",
            frame_type="DATA",
            dlc=0,
            payload=b""
        )
        status2, anomaly2 = self.validator.validate_frame(frame_str)
        self.assertEqual(status2, ProcessingStatus.INVALID_FRAME)
        self.assertIsNotNone(anomaly2)

    def test_payload_none_type_safety(self):
        # Initialized with None payload
        frame = CANFrame(
            timestamp=8.0,
            channel=1,
            can_id=0x0C9,
            direction="Rx",
            frame_type="d",
            dlc=8,
            payload=None  # type: ignore
        )
        # Should safely coerce payload to b"" and not crash with TypeError
        status, anomaly = self.validator.validate_frame(frame)
        self.assertEqual(status, ProcessingStatus.INVALID_FRAME)
        self.assertIsNotNone(anomaly)

    def test_large_signal_value_is_not_data_corruption(self):
        # An extreme payload (e.g. 0xFFFF raw RPM = 16383 RPM, exceeding 8000 max)
        # is a RANGE anomaly, NOT data corruption.
        frame = CANFrame(
            timestamp=4.023105,
            channel=1,
            can_id=0x0C9,
            direction="Rx",
            frame_type="d",
            dlc=8,
            payload=bytes.fromhex("FFFF0000AABBCCDD")
        )
        status, anomaly = self.validator.validate_frame(frame)
        self.assertEqual(status, ProcessingStatus.VALID)
        self.assertIsNone(anomaly)


if __name__ == "__main__":
    unittest.main()
