"""
Unit tests for DBC Parser.
Tests message parsing, signal decoding (Intel/Motorola), multiplexing,
cycle time attributes, and ID normalization.
"""

import unittest
from dbc_parser import DBCParser
from models import DBCMessage, DBCSignal


class TestDBCParser(unittest.TestCase):

    def setUp(self):
        self.parser = DBCParser()

    def test_normalize_can_id(self):
        # Standard 11-bit CAN ID
        norm_id, is_ext = DBCParser.normalize_can_id(0x0C9)
        self.assertEqual(norm_id, 201)
        self.assertFalse(is_ext)

        # Extended 29-bit CAN ID with MSB set in Vector DBC (0x80000000 mask)
        raw_ext = 0x800001A0
        norm_id, is_ext = DBCParser.normalize_can_id(raw_ext)
        self.assertEqual(norm_id, 0x1A0)
        self.assertTrue(is_ext)

    def test_parse_synthetic_dbc(self):
        dbc_content = """
VERSION "1.0"
BU_: NodeA NodeB

BO_ 201 EngineMsg: 8 NodeA
 SG_ Speed : 0|16@1+ (0.01,0) [0|300] "km/h" NodeB
 SG_ Temp : 16|8@1- (1,-40) [-40|150] "degC" NodeB

BO_ 300 MuxMsg: 8 NodeA
 SG_ MuxSelector M : 0|8@1+ (1,0) [0|255] "" NodeB
 SG_ Mode0_Sig m0 : 8|16@1+ (0.1,0) [0|100] "V" NodeB
 SG_ Mode1_Sig m1 : 8|16@1+ (1,0) [0|1000] "mA" NodeB

BA_DEF_ BO_ "GenMsgCycleTime" INT 0 10000;
BA_DEF_DEF_ "GenMsgCycleTime" 50;
BA_ "GenMsgCycleTime" BO_ 201 100;
"""
        messages = self.parser.parse_string(dbc_content)
        self.assertEqual(len(messages), 2)
        self.assertIn(201, messages)
        self.assertIn(300, messages)

        # Verify EngineMsg
        msg1 = messages[201]
        self.assertEqual(msg1.name, "EngineMsg")
        self.assertEqual(msg1.dlc, 8)
        self.assertEqual(msg1.sender, "NodeA")
        self.assertEqual(msg1.cycle_time_ms, 100)
        self.assertEqual(len(msg1.signals), 2)

        # Verify default cycle time applied to MuxMsg
        msg2 = messages[300]
        self.assertEqual(msg2.cycle_time_ms, 50)
        self.assertEqual(len(msg2.signals), 3)

    def test_signal_decoding_intel(self):
        sig = DBCSignal(
            name="Speed",
            start_bit=0,
            length=16,
            byte_order=1, # Intel
            is_signed=False,
            factor=0.01,
            offset=0.0,
            min_val=0.0,
            max_val=300.0,
            unit="km/h"
        )
        # Payload 100.00 km/h -> raw = 10000 = 0x2710 -> bytes: [0x10, 0x27]
        payload = bytes([0x10, 0x27, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00])
        val = DBCParser.decode_signal(payload, sig)
        self.assertIsNotNone(val)
        self.assertAlmostEqual(val, 100.0, places=2)

    def test_signal_decoding_signed(self):
        sig = DBCSignal(
            name="Temp",
            start_bit=16,
            length=8,
            byte_order=1,
            is_signed=True,
            factor=1.0,
            offset=0.0,
            min_val=-128.0,
            max_val=127.0,
            unit="degC"
        )
        # Byte at index 2 = 0xFE = -2 signed
        payload = bytes([0x00, 0x00, 0xFE, 0x00, 0x00, 0x00, 0x00, 0x00])
        val = DBCParser.decode_signal(payload, sig)
        self.assertEqual(val, -2.0)

    def test_multiplexed_signal_filtering(self):
        dbc_content = """
BO_ 300 MuxMsg: 8 NodeA
 SG_ MuxSelector M : 0|8@1+ (1,0) [0|255] "" NodeB
 SG_ Mode0_Sig m0 : 8|16@1+ (0.1,0) [0|100] "V" NodeB
 SG_ Mode1_Sig m1 : 8|16@1+ (1,0) [0|1000] "mA" NodeB
"""
        messages = self.parser.parse_string(dbc_content)
        msg = messages[300]

        # Payload with MuxSelector = 0
        payload_m0 = bytes([0x00, 0x10, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00])
        active_m0 = self.parser.get_active_signals(msg, payload_m0)
        self.assertIn("MuxSelector", active_m0)
        self.assertIn("Mode0_Sig", active_m0)
        self.assertNotIn("Mode1_Sig", active_m0)

        # Payload with MuxSelector = 1
        payload_m1 = bytes([0x01, 0x10, 0x20, 0x00, 0x00, 0x00, 0x00, 0x00])
        active_m1 = self.parser.get_active_signals(msg, payload_m1)
        self.assertIn("MuxSelector", active_m1)
        self.assertIn("Mode1_Sig", active_m1)
        self.assertNotIn("Mode0_Sig", active_m1)


if __name__ == "__main__":
    unittest.main()
