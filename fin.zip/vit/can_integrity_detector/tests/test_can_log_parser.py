"""
Unit tests for Vector ASC CAN Log Parser.
Tests line parsing, header/comment handling, hex ID parsing,
malformed payload recovery, and streaming generation.
"""

import unittest
import tempfile
import os
from can_log_parser import ASCLogParser, ParseError


class TestASCLogParser(unittest.TestCase):

    def setUp(self):
        self.parser = ASCLogParser()

    def test_parse_standard_line(self):
        line = "   4.023105 1  0C9  Rx  d 8  FF FF 00 00 AA BB CC DD"
        frame, err = self.parser.parse_line(line, 1)
        self.assertIsNone(err)
        self.assertIsNotNone(frame)
        self.assertAlmostEqual(frame.timestamp, 4.023105)
        self.assertEqual(frame.channel, 1)
        self.assertEqual(frame.can_id, 0x0C9)
        self.assertEqual(frame.can_id_hex, "0xC9")
        self.assertEqual(frame.direction, "Rx")
        self.assertEqual(frame.frame_type, "d")
        self.assertEqual(frame.dlc, 8)
        self.assertEqual(frame.payload, bytes.fromhex("FFFF0000AABBCCDD"))

    def test_parse_dlc_zero(self):
        line = "   6.700000 1  0C9  Rx  d 0"
        frame, err = self.parser.parse_line(line, 10)
        self.assertIsNone(err)
        self.assertIsNotNone(frame)
        self.assertEqual(frame.dlc, 0)
        self.assertEqual(frame.payload, b"")

    def test_ignore_headers_and_comments(self):
        headers = [
            "date Thu Apr 15 00:00:00 2025",
            "base hex timestamps absolute",
            "internal events logged",
            "// This is a comment",
            "/* block comment */",
            "; semi-colon comment",
            "*** start of measurement ***",
            "   ",
            ""
        ]
        for idx, h in enumerate(headers, 1):
            frame, err = self.parser.parse_line(h, idx)
            self.assertIsNone(frame)
            self.assertIsNone(err)

    def test_parse_extended_id(self):
        line = "  1.234567 1  18DAF110x  Tx  d 8  02 01 0D 00 00 00 00 00"
        frame, err = self.parser.parse_line(line, 5)
        self.assertIsNone(err)
        self.assertIsNotNone(frame)
        self.assertEqual(frame.can_id, 0x18DAF110)
        self.assertTrue(frame.is_extended)
        self.assertEqual(frame.direction, "Tx")

    def test_malformed_hex_payload(self):
        line = "  2.000000 1  1A0  Rx  d 8  00 00 ZZ 00 00 00 00 00"
        frame, err = self.parser.parse_line(line, 7)
        self.assertIsNone(frame)
        self.assertIsNotNone(err)
        self.assertIn("Malformed hexadecimal", err.error_message)

    def test_streaming_parser(self):
        content = """date Thu Apr 15 00:00:00 2025
base hex timestamps absolute
// Header comment
0.000000 1  1A0  Rx  d 8  00 00 00 00 00 00 00 00
0.100000 1  1A0  Rx  d 8  10 00 00 00 00 00 00 00
// Mid comment
0.200000 1  1A0  Rx  d 8  20 00 00 00 00 00 00 00
"""
        with tempfile.NamedTemporaryFile("w", delete=False, encoding="utf-8") as f:
            f.write(content)
            temp_path = f.name

        try:
            frames, errors = self.parser.parse_all(temp_path)
            self.assertEqual(len(errors), 0)
            self.assertEqual(len(frames), 3)
            self.assertAlmostEqual(frames[0].timestamp, 0.0)
            self.assertAlmostEqual(frames[1].timestamp, 0.1)
            self.assertAlmostEqual(frames[2].timestamp, 0.2)
        finally:
            os.remove(temp_path)


if __name__ == "__main__":
    unittest.main()
