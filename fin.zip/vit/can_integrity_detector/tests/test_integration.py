"""
Integration tests for CAN Communication Integrity Detector.
Validates end-to-end execution on sample DBC and ASC log files,
verifies absence of false positives for out-of-scope anomalies (range, flooding, logic),
and verifies that replacing the DBC and log with a new custom pair works seamlessly.
"""

import unittest
import tempfile
import os
import json
from main import run_analysis
from reporter import AnomalyReporter
from models import AnomalyType


class TestIntegration(unittest.TestCase):

    def setUp(self):
        self.dbc_path = os.path.join(os.path.dirname(__file__), "..", "CAN.dbc")
        self.log_path = os.path.join(os.path.dirname(__file__), "..", "CAN.log.txt")

    def test_run_analysis_sample_files(self):
        anomalies, summary = run_analysis(
            dbc_path=self.dbc_path,
            log_path=self.log_path,
            timeout_multiplier=1.5
        )

        # 1. Summary checks
        self.assertGreater(summary.frames_analyzed, 0)
        self.assertEqual(summary.messages_monitored, 8)
        self.assertEqual(summary.timing_not_available, 0)

        # 2. Check CRC behavior: DBC does not specify application CRC, so CRC must be NOT_CHECKED
        self.assertEqual(summary.crc_mismatches, 0)
        self.assertGreater(summary.crc_not_checked, 0)

        # 3. Data corruption check: Must catch DLC=0 corrupted frame at t=6.7s
        self.assertGreaterEqual(summary.data_corruptions, 1)
        dlc_zero_anomalies = [
            a for a in anomalies
            if a.anomaly_type == AnomalyType.DATA_CORRUPTION and a.timestamp == 6.7
        ]
        self.assertEqual(len(dlc_zero_anomalies), 1)

        # 4. Out-of-scope anomaly checks (False Positive Prevention)
        # Verify that out-of-range RPM at t=4.023105s is NOT flagged as DATA_CORRUPTION
        corruptions_at_range_time = [
            a for a in anomalies
            if a.anomaly_type == AnomalyType.DATA_CORRUPTION and abs(a.timestamp - 4.023105) < 0.0001
        ]
        self.assertEqual(len(corruptions_at_range_time), 0)

        # Verify that 1ms bursts on VehicleSpeed (0x1A0) (t=2.011s to 2.100s) are NOT flagged as timeouts
        timeouts_during_burst = [
            a for a in anomalies
            if a.anomaly_type == AnomalyType.MESSAGE_TIMEOUT
            and a.can_id == 0x1A0
            and 2.011 <= a.timestamp <= 2.100
        ]
        self.assertEqual(len(timeouts_during_burst), 0)

    def test_json_export(self):
        anomalies, summary = run_analysis(
            dbc_path=self.dbc_path,
            log_path=self.log_path
        )
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".json") as f:
            temp_json = f.name

        try:
            AnomalyReporter.export_json(anomalies, summary, temp_json)
            with open(temp_json, "r", encoding="utf-8") as f:
                loaded = json.load(f)
            self.assertIn("summary", loaded)
            self.assertIn("anomalies", loaded)
            self.assertEqual(loaded["summary"]["frames_analyzed"], summary.frames_analyzed)
        finally:
            if os.path.exists(temp_json):
                os.remove(temp_json)

    def test_generic_behavior_with_different_pair(self):
        """
        Verify that an entirely new synthetic DBC and CAN log pair functions
        flawlessly without code modifications.
        """
        new_dbc = """
VERSION ""
BU_: SensorECU ActuatorECU

BO_ 100 SensorData: 8 SensorECU
 SG_ Temperature : 0|16@1+ (0.1,0) [0|100] "C" ActuatorECU
 SG_ Pressure    : 16|16@1+ (1,0)   [0|1000] "kPa" ActuatorECU

BA_DEF_ BO_ "GenMsgCycleTime" INT 0 10000;
BA_ "GenMsgCycleTime" BO_ 100 200;
"""
        new_log = """date Thu Apr 15 00:00:00 2025
base hex timestamps absolute
// Normal arrival at t=1.0 and t=1.2 (gap=200ms, within 300ms allowed)
1.000000 1  064  Rx  d 8  00 01 00 02 00 00 00 00
1.200000 1  064  Rx  d 8  00 01 00 02 00 00 00 00

// Missing message gap at t=2.0 (gap=800ms > 300ms)
2.000000 1  064  Rx  d 8  00 01 00 02 00 00 00 00

// Malformed DLC mismatch
2.200000 1  064  Rx  d 8  00 01 00 02
"""
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".dbc", encoding="utf-8") as f_dbc:
            f_dbc.write(new_dbc)
            dbc_file = f_dbc.name

        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".asc", encoding="utf-8") as f_log:
            f_log.write(new_log)
            log_file = f_log.name

        try:
            anomalies, summary = run_analysis(dbc_path=dbc_file, log_path=log_file, timeout_multiplier=1.5)
            self.assertEqual(summary.frames_analyzed, 4)
            self.assertEqual(summary.messages_monitored, 1)
            self.assertEqual(summary.message_timeouts, 1) # Gap at t=2.0
            self.assertEqual(summary.data_corruptions, 1) # DLC mismatch at t=2.2

            timeout_anom = [a for a in anomalies if a.anomaly_type == AnomalyType.MESSAGE_TIMEOUT][0]
            self.assertEqual(timeout_anom.can_id, 100)
            self.assertEqual(timeout_anom.message_name, "SensorData")
            self.assertAlmostEqual(timeout_anom.details["actual_gap_ms"], 800.0)

        finally:
            if os.path.exists(dbc_file):
                os.remove(dbc_file)
            if os.path.exists(log_file):
                os.remove(log_file)


if __name__ == "__main__":
    unittest.main()
