"""
Unit tests for Timing Monitor.
Tests missing message detection, timeout thresholds, first-message baseline,
end-of-log handling, multiplexed signals, and ensuring flooding is ignored.
"""

import unittest
from models import CANFrame, DBCMessage, DBCSignal, AnomalyType, ProcessingStatus
from timing_monitor import TimingMonitor


class TestTimingMonitor(unittest.TestCase):

    def setUp(self):
        # Create synthetic DBC definitions
        self.dbc_messages = {
            0x1A0: DBCMessage(
                can_id=0x1A0,
                name="VehicleSpeed",
                dlc=8,
                sender="ABS_ECU",
                cycle_time_ms=100.0, # 100ms
                signals={
                    "Speed": DBCSignal("Speed", 0, 16, 1, False, 0.01, 0, 0, 300, "km/h"),
                    "Brake": DBCSignal("Brake", 16, 1, 1, False, 1.0, 0, 0, 1, "")
                }
            ),
            0x200: DBCMessage(
                can_id=0x200,
                name="SpontaneousMsg",
                dlc=4,
                sender="DiagECU",
                cycle_time_ms=None # No cycle time
            )
        }
        self.monitor = TimingMonitor(self.dbc_messages, timeout_multiplier=1.5)

    def _create_frame(self, can_id: int, timestamp: float) -> CANFrame:
        return CANFrame(
            timestamp=timestamp,
            channel=1,
            can_id=can_id,
            direction="Rx",
            frame_type="d",
            dlc=8,
            payload=bytes([0] * 8)
        )

    def test_first_message_no_timeout(self):
        # First observation establishes baseline
        frame = self._create_frame(0x1A0, 1.0)
        status, anomaly = self.monitor.process_frame(frame)
        self.assertEqual(status, ProcessingStatus.VALID)
        self.assertIsNone(anomaly)

    def test_normal_periodic_arrival(self):
        # 100ms interval (within 150ms timeout threshold)
        self.monitor.process_frame(self._create_frame(0x1A0, 1.0))
        status, anomaly = self.monitor.process_frame(self._create_frame(0x1A0, 1.100))
        self.assertEqual(status, ProcessingStatus.VALID)
        self.assertIsNone(anomaly)

    def test_late_message_timeout(self):
        # Interval is 200ms (> 150ms timeout threshold for 100ms cycle time @ 1.5x)
        self.monitor.process_frame(self._create_frame(0x1A0, 1.0))
        status, anomaly = self.monitor.process_frame(self._create_frame(0x1A0, 1.200))
        self.assertEqual(status, ProcessingStatus.VALID)
        self.assertIsNotNone(anomaly)
        self.assertEqual(anomaly.anomaly_type, AnomalyType.MESSAGE_TIMEOUT)
        self.assertEqual(anomaly.can_id, 0x1A0)
        self.assertEqual(anomaly.message_name, "VehicleSpeed")
        self.assertAlmostEqual(anomaly.details["actual_gap_ms"], 200.0)
        self.assertAlmostEqual(anomaly.details["allowed_gap_ms"], 150.0)
        self.assertIn("Speed", anomaly.affected_signals)

    def test_rapid_burst_flooding_ignored(self):
        # Interval is 10ms (< 100ms cycle time).
        # Per specification: Message flooding is NOT an anomaly in this module.
        self.monitor.process_frame(self._create_frame(0x1A0, 1.0))
        status, anomaly = self.monitor.process_frame(self._create_frame(0x1A0, 1.010))
        self.assertEqual(status, ProcessingStatus.VALID)
        self.assertIsNone(anomaly)

    def test_message_without_cycle_time_not_checked(self):
        # Message 0x200 has no cycle time defined
        frame1 = self._create_frame(0x200, 1.0)
        status1, anomaly1 = self.monitor.process_frame(frame1)
        self.assertEqual(status1, ProcessingStatus.NOT_CHECKED)
        self.assertIsNone(anomaly1)

        # Huge gap of 10 seconds for unmonitored message -> still NOT_CHECKED
        frame2 = self._create_frame(0x200, 11.0)
        status2, anomaly2 = self.monitor.process_frame(frame2)
        self.assertEqual(status2, ProcessingStatus.NOT_CHECKED)
        self.assertIsNone(anomaly2)

    def test_unknown_can_id(self):
        # 0x999 is not in DBC
        frame = self._create_frame(0x999, 1.0)
        status, anomaly = self.monitor.process_frame(frame)
        self.assertEqual(status, ProcessingStatus.UNKNOWN_MESSAGE)
        self.assertIsNone(anomaly)


if __name__ == "__main__":
    unittest.main()
