"""
Vector ASC CAN Log Parser.
Streaming parser for Vector ASCII (.asc) CAN log files.
Handles headers, comments, whitespace, standard/extended identifiers,
and provides robust error recovery without crashing on malformed lines.
"""

import re
from typing import Generator, Optional, Tuple, List, Union
from models import CANFrame


class ParseError:
    """Represents a non-fatal parsing error in an ASC log line."""
    def __init__(self, line_number: int, raw_line: str, error_message: str):
        self.line_number = line_number
        self.raw_line = raw_line
        self.error_message = error_message

    def __repr__(self) -> str:
        return f"ParseError(line={self.line_number}, msg='{self.error_message}', raw='{self.raw_line}')"


class ASCLogParser:
    """Streaming parser for Vector ASC CAN logs."""

    # Common ASC headers and metadata markers to ignore
    IGNORED_PREFIXES = (
        "date",
        "base",
        "internal",
        "version",
        "begin",
        "end",
        "//",
        ";",
        "***",
        "/*",
        "start",
        "stop"
    )

    @staticmethod
    def parse_can_id_string(id_str: str) -> Tuple[int, bool]:
        """
        Parse a CAN ID string into an integer and determine if extended.
        Handles:
          - Standard hex: '0C9', '1A0', '0x1A0'
          - Extended format with 'x' suffix: '18DAF110x'
          - Hex standard string
        """
        cleaned = id_str.strip()
        is_extended = False

        if cleaned.endswith("x") or cleaned.endswith("X"):
            is_extended = True
            cleaned = cleaned[:-1]

        if cleaned.startswith("0x") or cleaned.startswith("0X"):
            val = int(cleaned, 16)
        else:
            # ASC files by default represent CAN IDs in hexadecimal
            val = int(cleaned, 16)

        return val, is_extended

    def parse_line(self, line: str, line_number: int) -> Tuple[Optional[CANFrame], Optional[ParseError]]:
        """
        Parse a single line from an ASC log file.
        Returns (CANFrame, None) on success,
                (None, None) for comments/headers/blank lines,
                (None, ParseError) for malformed lines.
        """
        stripped = line.strip()
        if not stripped:
            return None, None

        # Check for header/comment lines
        lower_line = stripped.lower()
        if any(lower_line.startswith(prefix) for prefix in self.IGNORED_PREFIXES):
            return None, None

        # Tokenize by whitespace
        tokens = stripped.split()
        if len(tokens) < 4:
            # Not a CAN frame line (could be metadata or unexpected text)
            return None, None

        # Expected format:
        # <timestamp> <channel> <can_id> <direction: Rx|Tx> [<frame_type: d|r>] <dlc> [<b0> <b1> ...]
        # Examples:
        # 0.000000 1 0C9 Rx d 8 10 00 28 33 00 00 00 00
        # 6.700000 1 0C9 Rx d 0
        # 4.023105 1 0C9 Rx d 8 FF FF 00 00 AA BB CC DD

        # Step 1: Parse timestamp
        try:
            timestamp = float(tokens[0])
        except ValueError:
            # If the first token isn't a timestamp, ignore or error
            return None, ParseError(line_number, line, f"Invalid timestamp: '{tokens[0]}'")

        # Step 2: Parse channel
        try:
            channel = int(tokens[1])
        except ValueError:
            return None, ParseError(line_number, line, f"Invalid channel number: '{tokens[1]}'")

        # Step 3: Parse CAN ID
        try:
            can_id, is_extended = self.parse_can_id_string(tokens[2])
        except ValueError:
            return None, ParseError(line_number, line, f"Invalid CAN identifier: '{tokens[2]}'")

        # Step 4: Parse direction and frame_type
        # Standard ASC has direction at token 3 ('Rx' or 'Tx')
        curr_idx = 3
        direction = "Rx"
        if curr_idx < len(tokens) and tokens[curr_idx] in ("Rx", "Tx", "rx", "tx", "RX", "TX"):
            direction = tokens[curr_idx].capitalize()
            curr_idx += 1

        frame_type = "d"
        if curr_idx < len(tokens) and tokens[curr_idx] in ("d", "r", "D", "R"):
            frame_type = tokens[curr_idx].lower()
            curr_idx += 1

        # Step 5: Parse DLC
        if curr_idx >= len(tokens):
            return None, ParseError(line_number, line, "Missing DLC in CAN frame line")

        try:
            dlc = int(tokens[curr_idx])
            curr_idx += 1
        except ValueError:
            return None, ParseError(line_number, line, f"Invalid DLC value: '{tokens[curr_idx]}'")

        # Step 6: Parse Payload Bytes
        payload_tokens = tokens[curr_idx:]
        payload_bytes = bytearray()
        for b_token in payload_tokens:
            # If inline comment is encountered (e.g. //), stop parsing payload
            if b_token.startswith("//") or b_token.startswith(";"):
                break
            try:
                b_val = int(b_token, 16)
                if 0 <= b_val <= 255:
                    payload_bytes.append(b_val)
                else:
                    return None, ParseError(
                        line_number, line, f"Payload byte out of 0x00-0xFF range: '{b_token}'"
                    )
            except ValueError:
                return None, ParseError(
                    line_number, line, f"Malformed hexadecimal payload byte: '{b_token}'"
                )

        frame = CANFrame(
            timestamp=timestamp,
            channel=channel,
            can_id=can_id,
            direction=direction,
            frame_type=frame_type,
            dlc=dlc,
            payload=bytes(payload_bytes),
            raw_line=stripped,
            line_number=line_number,
            is_extended=is_extended
        )

        return frame, None

    def stream_frames(self, filepath: str) -> Generator[Tuple[Optional[CANFrame], Optional[ParseError]], None, None]:
        """
        Streaming generator that reads an ASC log file line-by-line and yields
        (CANFrame, None) or (None, ParseError).
        """
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            for line_idx, line in enumerate(f, start=1):
                frame, error = self.parse_line(line, line_idx)
                if frame is not None or error is not None:
                    yield frame, error

    def parse_all(self, filepath: str) -> Tuple[List[CANFrame], List[ParseError]]:
        """Parse the entire ASC log into lists of frames and parse errors."""
        frames: List[CANFrame] = []
        errors: List[ParseError] = []
        for frame, error in self.stream_frames(filepath):
            if frame is not None:
                frames.append(frame)
            if error is not None:
                errors.append(error)
        return frames, errors
