"""
Application-Layer CRC and Checksum Validator.
Implements a fully configurable, deterministic CRC and checksum computation engine
supporting standard automotive algorithms (AUTOSAR, SAE J1850, CCITT, Sum/XOR)
as well as custom polynomials, reflections, seeds, and message ID/counter contributions.
Strictly reports NOT_CHECKED when CRC definitions are not provided.
"""

from typing import Dict, List, Optional, Tuple, Any
from models import (
    CANFrame,
    CRCDefinition,
    Anomaly,
    AnomalyType,
    ProcessingStatus
)


class CRCValidator:
    """Validator for application-layer CRCs and checksums carried inside CAN payloads."""

    def __init__(self, crc_definitions: Optional[Dict[int, CRCDefinition]] = None):
        """
        :param crc_definitions: Dictionary of CAN ID -> CRCDefinition.
                               If a CAN ID is not in this dict, CRC is classified as NOT_CHECKED.
        """
        self.crc_definitions: Dict[int, CRCDefinition] = crc_definitions or {}

    @staticmethod
    def reflect_bits(val: int, width: int) -> int:
        """Reflect (reverse) bits of an integer value of given bit width."""
        res = 0
        for i in range(width):
            if (val >> i) & 1:
                res |= 1 << (width - 1 - i)
        return res

    @classmethod
    def calculate_crc(
        cls,
        data: bytes,
        width: int,
        polynomial: int,
        init_val: int,
        xor_out: int,
        reflect_in: bool = False,
        reflect_out: bool = False
    ) -> int:
        """
        Generic, bitwise CRC calculation for any bit width (8, 16, 32).
        """
        mask = (1 << width) - 1
        reg = init_val & mask

        for byte in data:
            if reflect_in:
                byte = cls.reflect_bits(byte, 8)

            reg ^= (byte << (width - 8))
            for _ in range(8):
                if reg & (1 << (width - 1)):
                    reg = ((reg << 1) ^ polynomial) & mask
                else:
                    reg = (reg << 1) & mask

        if reflect_out:
            reg = cls.reflect_bits(reg, width)

        return (reg ^ xor_out) & mask

    @classmethod
    def calculate_checksum(cls, data: bytes, algorithm: str) -> int:
        """Calculate standard additive or XOR checksums."""
        algo_upper = algorithm.upper()
        if "XOR" in algo_upper:
            res = 0
            for b in data:
                res ^= b
            return res & 0xFF
        elif "SUM" in algo_upper or "ADD" in algo_upper:
            res = sum(data)
            if "2S" in algo_upper or "TWOS" in algo_upper:
                # Two's complement sum
                return ((-res) & 0xFF)
            return res & 0xFF
        else:
            return sum(data) & 0xFF

    def validate_frame(self, frame: CANFrame) -> Tuple[ProcessingStatus, Optional[Anomaly], str]:
        """
        Validate application-layer CRC for a frame.

        Returns:
            Tuple of (ProcessingStatus, Optional[Anomaly], status_explanation)
        """
        can_id = frame.can_id

        # 1. Check if CRC definition exists for this CAN ID
        if can_id not in self.crc_definitions:
            return (
                ProcessingStatus.NOT_CHECKED,
                None,
                "CRC/checksum definition or required CRC metadata is unavailable."
            )

        crc_def = self.crc_definitions[can_id]
        payload = frame.payload

        if not payload:
            return (
                ProcessingStatus.INSUFFICIENT_DATA,
                None,
                "Payload is empty; cannot compute CRC."
            )

        # 2. Identify covered bytes
        if crc_def.covered_bytes is not None:
            # Check indices within bounds
            for idx in crc_def.covered_bytes:
                if idx >= len(payload):
                    return (
                        ProcessingStatus.INSUFFICIENT_DATA,
                        None,
                        f"Payload length ({len(payload)}) insufficient for covered byte index {idx}."
                    )
            calc_data = bytes(payload[i] for i in crc_def.covered_bytes)
        else:
            # Default: cover all bytes except the last byte (where CRC resides)
            crc_byte_pos = crc_def.start_bit // 8
            if crc_byte_pos >= len(payload):
                return (
                    ProcessingStatus.INSUFFICIENT_DATA,
                    None,
                    f"Payload too short to extract CRC at byte index {crc_byte_pos}."
                )
            calc_data = bytes(b for i, b in enumerate(payload) if i != crc_byte_pos)

        # Prepend CAN ID or Counter bytes if configured in definition
        extra_data = bytearray()
        if crc_def.include_can_id:
            can_id_bytes = (crc_def.can_id_in_crc or can_id).to_bytes(2, byteorder="big")
            extra_data.extend(can_id_bytes)

        full_data_to_hash = bytes(extra_data) + calc_data

        # 3. Compute expected CRC / checksum
        algo_name = crc_def.algorithm.upper()
        if algo_name in ("CHECKSUM_SUM8", "CHECKSUM_XOR8", "CHECKSUM_2S_SUM8", "SUM8", "XOR8"):
            calculated_crc = self.calculate_checksum(full_data_to_hash, algo_name)
        elif algo_name == "CRC8_AUTOSAR":
            calculated_crc = self.calculate_crc(
                data=full_data_to_hash,
                width=8,
                polynomial=0x2F,
                init_val=0xFF,
                xor_out=0xFF,
                reflect_in=False,
                reflect_out=False
            )
        elif algo_name == "CRC8_SAE_J1850":
            calculated_crc = self.calculate_crc(
                data=full_data_to_hash,
                width=8,
                polynomial=0x1D,
                init_val=0xFF,
                xor_out=0xFF,
                reflect_in=False,
                reflect_out=False
            )
        elif algo_name == "CRC16_CCITT":
            calculated_crc = self.calculate_crc(
                data=full_data_to_hash,
                width=16,
                polynomial=0x1021,
                init_val=crc_def.init_value,
                xor_out=crc_def.xor_out,
                reflect_in=crc_def.reflect_in,
                reflect_out=crc_def.reflect_out
            )
        else:
            # Custom / parameterized CRC
            calculated_crc = self.calculate_crc(
                data=full_data_to_hash,
                width=crc_def.bit_length,
                polynomial=crc_def.polynomial,
                init_val=crc_def.init_value,
                xor_out=crc_def.xor_out,
                reflect_in=crc_def.reflect_in,
                reflect_out=crc_def.reflect_out
            )

        # 4. Extract received CRC from payload
        crc_byte_pos = crc_def.start_bit // 8
        if crc_def.bit_length == 8:
            if crc_byte_pos >= len(payload):
                return ProcessingStatus.INSUFFICIENT_DATA, None, "Payload too short for CRC."
            received_crc = payload[crc_byte_pos]
        elif crc_def.bit_length == 16:
            if crc_byte_pos + 1 >= len(payload):
                return ProcessingStatus.INSUFFICIENT_DATA, None, "Payload too short for 16-bit CRC."
            received_crc = int.from_bytes(payload[crc_byte_pos:crc_byte_pos + 2], byteorder="big")
        elif crc_def.bit_length == 32:
            if crc_byte_pos + 3 >= len(payload):
                return ProcessingStatus.INSUFFICIENT_DATA, None, "Payload too short for 32-bit CRC."
            received_crc = int.from_bytes(payload[crc_byte_pos:crc_byte_pos + 4], byteorder="big")
        else:
            received_crc = payload[crc_byte_pos]

        # 5. Compare received vs calculated
        if received_crc != calculated_crc:
            hex_format = f"0x{{:0{crc_def.bit_length // 4}X}}"
            reason = (
                f"CRC mismatch for {crc_def.message_name} ({frame.can_id_hex}): "
                f"Received CRC={hex_format.format(received_crc)}, "
                f"Calculated CRC={hex_format.format(calculated_crc)} using {crc_def.algorithm}."
            )
            anomaly = Anomaly(
                timestamp=frame.timestamp,
                anomaly_type=AnomalyType.CRC_MISMATCH,
                can_id=can_id,
                can_id_hex=frame.can_id_hex,
                message_name=crc_def.message_name,
                reason=reason,
                details={
                    "received_crc": hex_format.format(received_crc),
                    "calculated_crc": hex_format.format(calculated_crc),
                    "algorithm": crc_def.algorithm,
                    "covered_bytes": crc_def.covered_bytes or [i for i in range(len(payload)) if i != crc_byte_pos],
                    "raw_payload_hex": payload.hex().upper()
                },
                line_number=frame.line_number
            )
            return ProcessingStatus.VALID, anomaly, "CRC mismatch detected."

        return ProcessingStatus.VALID, None, "CRC valid."
