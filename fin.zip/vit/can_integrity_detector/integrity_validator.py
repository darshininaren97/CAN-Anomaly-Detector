"""
Deterministic Payload Integrity Validator.
Validates frame payload structure, DLC consistency, byte counts,
and deterministic frame formatting without statistical heuristics.
"""

from typing import Dict, List, Optional, Set, Tuple
from models import (
    CANFrame,
    DBCMessage,
    Anomaly,
    AnomalyType,
    ProcessingStatus
)


class IntegrityValidator:
    """Deterministic payload and frame integrity validator."""

    def __init__(self, dbc_messages: Dict[int, DBCMessage]):
        self.dbc_messages = dbc_messages
        self._seen_active_ids: Set[int] = set()

    def validate_frame(self, frame: CANFrame) -> Tuple[ProcessingStatus, Optional[Anomaly]]:
        """
        Perform deterministic payload integrity checks on a CAN frame.

        Checks:
        1. Explicit corruption patterns: all 0xFF (stuck HIGH), all 0x00 (stuck LOW/reset after activity),
           alternating 0xAA/0x55 test pattern, and empty data frames (DLC=0).
        2. Type safety & payload byte consistency against reported frame DLC.
        3. DBC specification compliance (received payload length vs expected DBC message DLC).

        Returns:
            Tuple of (ProcessingStatus, Optional[Anomaly])
        """
        can_id = frame.can_id
        # Ensure type safety even if payload is None or malformed
        payload = frame.payload if frame.payload is not None else b""
        actual_len = len(payload)
        reported_dlc = frame.dlc
        payload_hex_str = frame.payload_hex if hasattr(frame, "payload_hex") else payload.hex().upper()

        msg_name = self.dbc_messages[can_id].name if can_id in self.dbc_messages else "UNKNOWN"

        # Check for non-zero activity tracking
        if actual_len > 0 and any(b != 0 for b in payload):
            self._seen_active_ids.add(can_id)

        # Explicit Pattern Check 1: All 0xFF bytes (Bus stuck HIGH / hardware fault)
        if actual_len >= 4 and all(b == 0xFF for b in payload):
            reason = (
                f"Data corruption: Bus stuck HIGH / hardware fault pattern (all 0xFF bytes) "
                f"for message {msg_name} ({frame.can_id_hex})."
            )
            anomaly = Anomaly(
                timestamp=frame.timestamp,
                anomaly_type=AnomalyType.DATA_CORRUPTION,
                can_id=can_id,
                can_id_hex=frame.can_id_hex,
                message_name=msg_name,
                reason=reason,
                details={
                    "pattern": "ALL_FF_STUCK_HIGH",
                    "reported_dlc": reported_dlc,
                    "actual_payload_len": actual_len,
                    "raw_payload_hex": payload_hex_str,
                },
                line_number=frame.line_number,
            )
            return ProcessingStatus.INVALID_FRAME, anomaly

        # Explicit Pattern Check 2: Alternating 0xAA/0x55 test pattern on live bus
        is_aa55 = actual_len >= 4 and all(payload[i] == (0xAA if i % 2 == 0 else 0x55) for i in range(actual_len))
        is_55aa = actual_len >= 4 and all(payload[i] == (0x55 if i % 2 == 0 else 0xAA) for i in range(actual_len))
        if is_aa55 or is_55aa:
            reason = (
                f"Data corruption: Alternating 0xAA/0x55 test pattern detected on live bus "
                f"for message {msg_name} ({frame.can_id_hex})."
            )
            anomaly = Anomaly(
                timestamp=frame.timestamp,
                anomaly_type=AnomalyType.DATA_CORRUPTION,
                can_id=can_id,
                can_id_hex=frame.can_id_hex,
                message_name=msg_name,
                reason=reason,
                details={
                    "pattern": "AA55_TEST_PATTERN",
                    "reported_dlc": reported_dlc,
                    "actual_payload_len": actual_len,
                    "raw_payload_hex": payload_hex_str,
                },
                line_number=frame.line_number,
            )
            return ProcessingStatus.INVALID_FRAME, anomaly

        # Explicit Pattern Check 3: All 0x00 bytes after motion/activity (Bus stuck LOW / ECU reset)
        if actual_len >= 4 and all(b == 0x00 for b in payload) and (frame.timestamp > 1.0 or can_id in self._seen_active_ids):
            reason = (
                f"Data corruption: Bus stuck LOW / ECU reset pattern (all 0x00 bytes) "
                f"for message {msg_name} ({frame.can_id_hex})."
            )
            anomaly = Anomaly(
                timestamp=frame.timestamp,
                anomaly_type=AnomalyType.DATA_CORRUPTION,
                can_id=can_id,
                can_id_hex=frame.can_id_hex,
                message_name=msg_name,
                reason=reason,
                details={
                    "pattern": "ALL_00_STUCK_LOW",
                    "reported_dlc": reported_dlc,
                    "actual_payload_len": actual_len,
                    "raw_payload_hex": payload_hex_str,
                },
                line_number=frame.line_number,
            )
            return ProcessingStatus.INVALID_FRAME, anomaly

        # Check 1: DLC consistency with actual received payload bytes
        if actual_len != reported_dlc:
            reason = (
                f"Payload byte count mismatch for message {msg_name} ({frame.can_id_hex}): "
                f"Frame reported DLC={reported_dlc}, but received {actual_len} bytes in payload."
            )
            anomaly = Anomaly(
                timestamp=frame.timestamp,
                anomaly_type=AnomalyType.DATA_CORRUPTION,
                can_id=can_id,
                can_id_hex=frame.can_id_hex,
                message_name=msg_name,
                reason=reason,
                details={
                    "reported_dlc": reported_dlc,
                    "actual_payload_len": actual_len,
                    "raw_payload_hex": payload_hex_str
                },
                line_number=frame.line_number
            )
            return ProcessingStatus.INVALID_FRAME, anomaly

        # Check 2: DBC definition comparison for known messages
        if can_id in self.dbc_messages:
            dbc_msg = self.dbc_messages[can_id]
            expected_dlc = dbc_msg.dlc

            # Frame received has fewer bytes than required by DBC definition
            if reported_dlc < expected_dlc:
                reason = (
                    f"Insufficient payload length for message {dbc_msg.name} ({frame.can_id_hex}): "
                    f"DBC defines expected DLC={expected_dlc}, but frame has DLC={reported_dlc}."
                )
                anomaly = Anomaly(
                    timestamp=frame.timestamp,
                    anomaly_type=AnomalyType.DATA_CORRUPTION,
                    can_id=can_id,
                    can_id_hex=frame.can_id_hex,
                    message_name=dbc_msg.name,
                    reason=reason,
                    details={
                        "expected_dlc": expected_dlc,
                        "received_dlc": reported_dlc,
                        "actual_payload_len": actual_len,
                        "raw_payload_hex": payload_hex_str
                    },
                    line_number=frame.line_number
                )
                return ProcessingStatus.INSUFFICIENT_DATA, anomaly

        # Check 3: Data frames with DLC=0 on unmonitored / unknown messages
        # (Known messages with expected_dlc > 0 are already caught by Check 2 above)
        elif frame.is_data_frame and reported_dlc == 0:
            reason = f"Data frame has DLC=0 (empty payload) for unknown message ({frame.can_id_hex})."
            anomaly = Anomaly(
                timestamp=frame.timestamp,
                anomaly_type=AnomalyType.DATA_CORRUPTION,
                can_id=can_id,
                can_id_hex=frame.can_id_hex,
                message_name=msg_name,
                reason=reason,
                details={
                    "reported_dlc": 0,
                    "actual_payload_len": 0,
                    "raw_payload_hex": ""
                },
                line_number=frame.line_number
            )
            return ProcessingStatus.INVALID_FRAME, anomaly

        return ProcessingStatus.VALID, None
