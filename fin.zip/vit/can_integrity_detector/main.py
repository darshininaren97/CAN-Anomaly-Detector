"""
Main CLI Application for CAN Communication Integrity Anomaly Detector.

Monitors CAN bus communication for:
  1. Missing Message / Signal Timeout
  2. Data Corruption / Payload Integrity
  3. CRC / Checksum Mismatch

Usage:
  python main.py --dbc CAN.dbc --log CAN.log.txt
  python main.py --dbc CAN.dbc --log CAN.log.txt --output results.json --timeout-multiplier 1.5
"""

import sys
import os
import argparse
import json
from typing import Dict, List, Optional, Any, Tuple, Set

from models import (
    CANFrame,
    DBCMessage,
    CRCDefinition,
    Anomaly,
    AnomalyType,
    ProcessingStatus,
    AnalysisSummary
)
from dbc_parser import DBCParser
from can_log_parser import ASCLogParser, ParseError
from timing_monitor import TimingMonitor
from integrity_validator import IntegrityValidator
from crc_validator import CRCValidator
from reporter import AnomalyReporter


def load_external_config(config_path: str) -> Tuple[Dict[int, float], Dict[int, CRCDefinition]]:
    """
    Load optional external timing and CRC configuration JSON.
    Format:
    {
      "timing": {
        "0x1A0": 100,
        "432": 10
      },
      "crc": {
        "0x0C9": {
          "message_name": "EngineData",
          "algorithm": "CRC8_AUTOSAR",
          "start_bit": 56,
          "bit_length": 8,
          "covered_bytes": [0, 1, 2, 3, 4, 5, 6]
        }
      }
    }
    """
    external_timing: Dict[int, float] = {}
    crc_definitions: Dict[int, CRCDefinition] = {}

    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Configuration file not found: {config_path}")

    with open(config_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Parse timing overrides
    timing_data = data.get("timing", {})
    for id_key, period in timing_data.items():
        can_id = int(id_key, 16) if str(id_key).startswith("0x") or str(id_key).startswith("0X") else int(id_key)
        external_timing[can_id] = float(period)

    # Parse CRC definitions
    crc_data = data.get("crc", {})
    for id_key, c_conf in crc_data.items():
        can_id = int(id_key, 16) if str(id_key).startswith("0x") or str(id_key).startswith("0X") else int(id_key)
        crc_def = CRCDefinition(
            can_id=can_id,
            message_name=c_conf.get("message_name", f"Msg_0x{can_id:X}"),
            crc_signal_name=c_conf.get("crc_signal_name"),
            start_bit=int(c_conf.get("start_bit", 0)),
            bit_length=int(c_conf.get("bit_length", 8)),
            algorithm=c_conf.get("algorithm", "CRC8"),
            polynomial=int(c_conf.get("polynomial", 0x1D)),
            init_value=int(c_conf.get("init_value", 0xFF)),
            xor_out=int(c_conf.get("xor_out", 0xFF)),
            reflect_in=bool(c_conf.get("reflect_in", False)),
            reflect_out=bool(c_conf.get("reflect_out", False)),
            covered_bytes=c_conf.get("covered_bytes"),
            include_can_id=bool(c_conf.get("include_can_id", False)),
            can_id_in_crc=c_conf.get("can_id_in_crc"),
            include_counter=bool(c_conf.get("include_counter", False)),
            counter_signal_name=c_conf.get("counter_signal_name")
        )
        crc_definitions[can_id] = crc_def

    return external_timing, crc_definitions


def run_analysis(
    dbc_path: str,
    log_path: str,
    config_path: Optional[str] = None,
    timeout_multiplier: float = 1.5,
    verbose: bool = False
) -> Tuple[List[Anomaly], AnalysisSummary]:
    """
    Run communication integrity analysis on the given DBC and CAN log file.
    """
    if not os.path.exists(dbc_path):
        raise FileNotFoundError(f"DBC file not found: {dbc_path}")
    if not os.path.exists(log_path):
        raise FileNotFoundError(f"CAN log file not found: {log_path}")

    # Step 1: Parse DBC
    dbc_parser = DBCParser()
    dbc_messages = dbc_parser.parse_file(dbc_path)

    # Step 2: Load optional external configuration
    external_timing: Dict[int, float] = {}
    crc_definitions: Dict[int, CRCDefinition] = {}
    if config_path:
        external_timing, crc_definitions = load_external_config(config_path)

    # Step 3: Initialize Analyzers
    timing_monitor = TimingMonitor(
        dbc_messages=dbc_messages,
        timeout_multiplier=timeout_multiplier,
        external_timing=external_timing,
        dbc_parser=dbc_parser
    )
    integrity_validator = IntegrityValidator(dbc_messages=dbc_messages)
    crc_validator = CRCValidator(crc_definitions=crc_definitions)
    log_parser = ASCLogParser()

    summary = AnalysisSummary()
    summary.messages_monitored = len(timing_monitor.timing_definitions)
    summary.timing_not_available = len(dbc_messages) - len(timing_monitor.timing_definitions)

    anomalies: List[Anomaly] = []
    seen_unknown_ids = set()

    # Step 4: Stream CAN log line-by-line
    for frame, parse_err in log_parser.stream_frames(log_path):
        if parse_err is not None:
            summary.invalid_frames += 1
            summary.data_corruptions += 1
            anomaly = Anomaly(
                timestamp=0.0,
                anomaly_type=AnomalyType.DATA_CORRUPTION,
                can_id=0,
                can_id_hex="0x000",
                message_name="PARSING_ERROR",
                reason=f"Log parser encountered malformed line: {parse_err.error_message}",
                details={"raw_line": parse_err.raw_line},
                line_number=parse_err.line_number
            )
            anomalies.append(anomaly)
            continue

        if frame is None:
            continue

        summary.frames_analyzed += 1

        # Check A: Deterministic Payload & Frame Integrity
        status_integ, integ_anomaly = integrity_validator.validate_frame(frame)
        if integ_anomaly is not None:
            anomalies.append(integ_anomaly)
            summary.data_corruptions += 1
            if status_integ in (ProcessingStatus.INVALID_FRAME, ProcessingStatus.INSUFFICIENT_DATA):
                summary.invalid_frames += 1

        # Check B: Application-Layer CRC / Checksum Validation
        status_crc, crc_anomaly, crc_reason = crc_validator.validate_frame(frame)
        if status_crc == ProcessingStatus.NOT_CHECKED:
            summary.crc_not_checked += 1
        elif crc_anomaly is not None:
            anomalies.append(crc_anomaly)
            summary.crc_mismatches += 1

        # Check C: Message & Signal Arrival Timing
        status_time, time_anomaly = timing_monitor.process_frame(frame)
        if status_time == ProcessingStatus.UNKNOWN_MESSAGE:
            if frame.can_id not in seen_unknown_ids:
                seen_unknown_ids.add(frame.can_id)
                summary.unknown_messages += 1
        elif status_time == ProcessingStatus.NOT_CHECKED:
            pass  # Timing not monitored for this message
        elif time_anomaly is not None:
            anomalies.append(time_anomaly)
            summary.message_timeouts += 1

        if verbose and (summary.frames_analyzed % 1000 == 0):
            print(f"Processed {summary.frames_analyzed} frames...", file=sys.stderr)

    return anomalies, summary


def main():
    parser = argparse.ArgumentParser(
        description="Deterministic CAN Bus Communication Integrity Detector (Timeouts, Corruptions, CRC Mismatches)."
    )
    parser.add_argument("--dbc", required=True, help="Path to CAN DBC file")
    parser.add_argument("--log", required=True, help="Path to Vector ASC CAN log file")
    parser.add_argument("--config", default=None, help="Optional path to external timing/CRC JSON config")
    parser.add_argument("--timeout-multiplier", type=float, default=1.5, help="Multiplier for message timeout (default: 1.5)")
    parser.add_argument("--output", default=None, help="Path to write output JSON report")
    parser.add_argument("--format", choices=["text", "json", "both"], default="text", help="Output format (default: text)")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose execution")

    args = parser.parse_args()

    try:
        anomalies, summary = run_analysis(
            dbc_path=args.dbc,
            log_path=args.log,
            config_path=args.config,
            timeout_multiplier=args.timeout_multiplier,
            verbose=args.verbose
        )

        console_report = AnomalyReporter.format_console_report(anomalies, summary)

        if args.format in ("text", "both"):
            print(console_report)

        if args.format in ("json", "both") and not args.output:
            print(json.dumps(AnomalyReporter.to_dict(anomalies, summary), indent=2))

        if args.output:
            AnomalyReporter.export_json(anomalies, summary, args.output)
            if args.verbose or args.format != "json":
                print(f"\n[INFO] Structured report saved to {args.output}")

    except Exception as e:
        print(f"[ERROR] Execution failed: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
