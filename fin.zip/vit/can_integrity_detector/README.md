# CAN Communication Integrity Anomaly Detector

A deterministic, production-grade Python program specialized exclusively in:
1. **Missing Message / Signal Timeout Detection**
2. **Data Corruption / Payload Integrity Validation**
3. **Application-Layer CRC / Checksum Validation**

---

## Table of Contents
1. [Project Purpose](#1-project-purpose)
2. [Missing Message Detection](#2-missing-message-detection)
3. [Signal Communication Timeout](#3-signal-communication-timeout)
4. [Data Corruption Detection](#4-data-corruption-detection)
5. [CRC / Checksum Validation](#5-crc--checksum-validation)
6. [CAN Physical-Layer CRC vs Application-Level CRC](#6-can-physical-layer-crc-vs-application-level-crc)
7. [DBC Cycle-Time Information](#7-dbc-cycle-time-information)
8. [Vector ASC Format Support](#8-vector-asc-format-support)
9. [Timeout Calculation & Multipliers](#9-timeout-calculation--multipliers)
10. [Error & Anomaly Categories](#10-error--anomaly-categories)
11. [`NOT_CHECKED` Deterministic Behavior](#11-not_checked-deterministic-behavior)
12. [Installation](#12-installation)
13. [CLI & Programmatic Usage](#13-cli--programmatic-usage)
14. [Software Architecture](#14-software-architecture)
15. [Testing & Verification](#15-testing--verification)
16. [Known Limitations](#16-known-limitations)

---

## 1. Project Purpose

In automotive electronic control systems, verifying message arrival timing, payload consistency, and end-to-end data integrity is critical for safety. 

This program processes standard **CAN DBC database files** and **Vector ASCII (.asc) CAN log files** to detect deterministic communication integrity faults without relying on statistical, machine-learning, or heuristic models.

### Strict Scope Boundary
This module strictly evaluates only communication integrity. It intentionally does **not** implement:
- Signal range checks (e.g. out-of-range RPM)
- Cross-signal logical contradictions (e.g. speed > 0 while engine is OFF)
- Signal correlation anomalies
- Bus-load or payload entropy heuristics
- Message flooding detection (rapid arrivals are treated as on-time)
- Replay attack detection

---

## 2. Missing Message Detection

Periodic CAN messages have an expected transmission period defined by the DBC (via `GenMsgCycleTime`) or an explicit configuration.

The detector tracks the arrival timestamps of every monitored CAN ID:
$$\Delta t_{\text{actual}} = t_{\text{current}} - t_{\text{previous}}$$

If $\Delta t_{\text{actual}} > \Delta t_{\text{timeout}}$, a `MESSAGE_TIMEOUT` anomaly is recorded with complete timing metrics and reason explanation.

### First-Message and End-of-Log Rules
- **First Message Baseline**: The first observed frame of any CAN ID establishes the baseline timestamp. No timeout is reported before the first observation.
- **End-of-Log Safety**: The detector does not fabricate a timeout after the last recorded frame in the log file unless an explicit observation window boundary is passed.

---

## 3. Signal Communication Timeout

Signals do not have independent physical clocks on a CAN bus; they are carried inside parent CAN frames.

When a parent CAN message suffers a communication timeout, the detector identifies all active DBC signals carried by that message:
- For static messages: lists all defined signals.
- For multiplexed messages: dynamically evaluates the multiplexor signal to identify only the active multiplexed signals.

---

## 4. Data Corruption Detection

Data corruption detection is strictly deterministic. A payload is flagged as `DATA_CORRUPTION` only when concrete structural evidence exists:
1. **DLC vs Payload Count Mismatch**: The frame header claims DLC=$N$, but fewer or more than $N$ payload bytes were received.
2. **Insufficient DBC Payload**: The frame received contains fewer bytes than required by the DBC message definition.
3. **Empty Data Frame**: A data frame (`d`) is received with DLC=0.
4. **Malformed Hexadecimal**: Unparseable or invalid hex characters in the raw log line.

> **Note**: Extreme signal values (such as raw 0xFFFF) that conform to the frame's structural DLC are **not** data corruption; they belong to signal range checking modules.

---

## 5. CRC / Checksum Validation

The program includes a parametric CRC and Checksum engine supporting:
- Standard automotive algorithms: `CRC8_AUTOSAR` (poly 0x2F), `CRC8_SAE_J1850` (poly 0x1D), `CRC16_CCITT` (poly 0x1021), `CHECKSUM_SUM8`, `CHECKSUM_XOR8`.
- Arbitrary polynomials, bit widths (8, 16, 32), initial values, final XORs, and input/output reflection.
- Configurable covered byte slices (e.g. payload bytes 0–6 for a byte 7 CRC).
- Optional CAN ID and message counter contribution.

When a CRC definition exists, the engine computes the expected value. If $\text{CRC}_{\text{received}} \neq \text{CRC}_{\text{calculated}}$, a `CRC_MISMATCH` anomaly is reported.

---

## 6. CAN Physical-Layer CRC vs Application-Level CRC

> [!IMPORTANT]
> **Critical Architectural Fact**: A standard Vector ASC CAN log records the CAN frame payload bytes delivered by the CAN controller / transceiver. The hardware physical-layer 15-bit/17-bit CRC field is stripped and validated by the physical CAN silicon controller before logging and is **not** present in ASC payload bytes.
>
> Therefore, this program **never fabricates** a physical CAN CRC check. It evaluates **application-layer CRCs / checksums** embedded within payload bytes when specified, and marks all other messages as `NOT_CHECKED`.

---

## 7. DBC Cycle-Time Information

The DBC parser dynamically extracts cycle times without hard-coding:
```dbc
BA_DEF_ BO_ "GenMsgCycleTime" INT 0 10000;
BA_DEF_DEF_ "GenMsgCycleTime" 100;
BA_ "GenMsgCycleTime" BO_ 201 100;
BA_ "GenMsgCycleTime" BO_ 416 10;
```
If a message lacks an explicit `BA_` assignment, the default attribute `BA_DEF_DEF_` is applied. If no cycle time is defined, timing analysis is classified as `NOT_CHECKED`.

---

## 8. Vector ASC Format Support

The parser handles standard Vector ASC files in streaming fashion:
```
4.023105 1  0C9  Rx  d 8  FF FF 00 00 AA BB CC DD
```
Supported features:
- Standard 11-bit hex IDs (`0C9`, `1A0`) and extended 29-bit IDs (`18DAF110x`).
- Direction (`Rx`, `Tx`) and frame types (`d` data, `r` remote).
- Tolerant skipping of headers (`date`, `base`, `begin`), comments (`//`, `/*`), and blank lines.
- Non-fatal error isolation: bad lines do not crash parser execution.

---

## 9. Timeout Calculation & Multipliers

For a message with nominal period $T_{\text{nominal}}$:
$$\text{Allowed Interval} = T_{\text{nominal}} \times \text{Multiplier}$$

- Default multiplier: `1.5`
- Configurable via `--timeout-multiplier <float>` (e.g. `2.0` or `3.0`).

---

## 10. Error & Anomaly Categories

### Anomaly Types (Reported Anomaly Output)
- `MESSAGE_TIMEOUT`: Expected frame arrived later than allowed threshold.
- `SIGNAL_TIMEOUT`: Specific signal's carrier message timed out.
- `DATA_CORRUPTION`: Structural DLC mismatch, insufficient payload, or malformed hex.
- `CRC_MISMATCH`: Calculated application CRC does not match received CRC.

### Processing Statuses
- `VALID`: Frame verified successfully.
- `UNKNOWN_MESSAGE`: CAN ID not defined in DBC.
- `INVALID_FRAME`: Malformed line or DLC mismatch.
- `INSUFFICIENT_DATA`: Truncated payload for DBC or CRC computation.
- `NOT_CHECKED`: Timing or CRC definition not defined for this message.
- `NOT_APPLICABLE`: Inactive multiplexed signal state.

---

## 11. `NOT_CHECKED` Deterministic Behavior

If a message lacks a cycle-time definition in the DBC/config:
$$\text{Timing Status} \rightarrow \text{NOT\_CHECKED}$$

If a message lacks an explicit CRC algorithm specification:
$$\text{CRC Status} \rightarrow \text{NOT\_CHECKED}$$

The detector never guesses or fabricates checksums or intervals.

---

## 12. Installation

Requires Python 3.10+ (standard library only, no third-party package dependencies required).

```bash
# Clone or navigate to the project directory
cd can_integrity_detector
```

---

## 13. CLI & Programmatic Usage

### Command-Line Interface
```bash
# Basic run with DBC and ASC log
python main.py --dbc CAN.dbc --log CAN.log.txt

# Run with custom timeout multiplier and JSON output export
python main.py --dbc CAN.dbc --log CAN.log.txt --timeout-multiplier 2.0 --output results.json

# Run with optional external configuration (custom timing & CRC rules)
python main.py --dbc CAN.dbc --log CAN.log.txt --config sample_config.json
```

### Optional External Configuration Format (`config.json`)
```json
{
  "timing": {
    "0x1A0": 100,
    "0x1B0": 100
  },
  "crc": {
    "0x0C9": {
      "message_name": "EngineData",
      "algorithm": "CRC8_AUTOSAR",
      "start_bit": 56,
      "bit_length": 8,
      "covered_bytes": [0, 1, 2, 3, 4, 5, 6]
    }
  }
}
```

---

## 14. Software Architecture

```
can_integrity_detector/
├── main.py                  # CLI Driver & Pipeline Coordinator
├── models.py                # Typed Dataclasses (CANFrame, DBCMessage, Anomaly, Summary)
├── dbc_parser.py            # DBC Database Parser & Signal Multiplex Decoder
├── can_log_parser.py        # Streaming Vector ASC Log Parser
├── timing_monitor.py        # Message/Signal Arrival & Timeout Tracker
├── integrity_validator.py   # Deterministic Payload Integrity Validator
├── crc_validator.py         # Parametric CRC & Checksum Engine
├── reporter.py              # Console Report & JSON Serializer
├── sample_config.json       # Optional External Configuration Example
└── tests/
    ├── test_dbc_parser.py
    ├── test_can_log_parser.py
    ├── test_timing_monitor.py
    ├── test_integrity_validator.py
    ├── test_crc_validator.py
    └── test_integration.py
```

---

## 15. Testing & Verification

Run the full automated test suite:
```bash
python -m unittest discover -s tests -p "test_*.py" -v
```

All 31 test cases cover:
- Intel & Motorola signal decoding and multiplexing
- Vector ASC header/comment parsing and malformed hex recovery
- Arrival gaps, timeout thresholds, first-message baseline, and burst immunity
- DLC mismatches, insufficient payloads, and false-positive prevention on range anomalies
- CRC-8 AUTOSAR, SAE J1850, CRC-16, XOR/SUM checksums, and `NOT_CHECKED` handling
- End-to-end integration and generic replacement with new DBC/log pairs

---

## 16. Known Limitations

1. **Physical Layer CAN CRC**: Physical CAN bus bitstream CRC is not logged by Vector ASC format; only payload-embedded application CRCs can be validated.
2. **Acyclic / Spontaneous Messages**: Messages without a defined `GenMsgCycleTime` or external timing definition are categorized as `NOT_CHECKED` for timing.
