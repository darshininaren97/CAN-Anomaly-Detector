"""
Data models for CAN communication integrity analysis.
Contains typed data structures for CAN frames, DBC definitions,
timing/CRC configuration, and structured anomalies.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any, Set, Union


class FrameType(str, Enum):
    """CAN frame types."""
    DATA = "d"
    REMOTE = "r"
    ERROR = "ErrorFrame"


class AnomalyType(str, Enum):
    """The supported anomaly categories in this detector."""
    MESSAGE_TIMEOUT = "MESSAGE_TIMEOUT"
    SIGNAL_TIMEOUT = "SIGNAL_TIMEOUT"
    DATA_CORRUPTION = "DATA_CORRUPTION"
    CRC_MISMATCH = "CRC_MISMATCH"


class ProcessingStatus(str, Enum):
    """Processing and validation statuses."""
    VALID = "VALID"
    UNKNOWN_MESSAGE = "UNKNOWN_MESSAGE"
    INVALID_FRAME = "INVALID_FRAME"
    INSUFFICIENT_DATA = "INSUFFICIENT_DATA"
    NOT_CHECKED = "NOT_CHECKED"
    NOT_APPLICABLE = "NOT_APPLICABLE"


@dataclass
class CANFrame:
    """Represents a single parsed CAN frame from a Vector ASC log."""
    timestamp: float          # Timestamp in seconds (float)
    channel: int              # CAN channel index (e.g. 1)
    can_id: int               # Normalized integer CAN ID (e.g. 0x0C9 -> 201)
    direction: str            # 'Rx' or 'Tx'
    frame_type: Union[FrameType, str] # 'd' (data) or 'r' (remote frame) or FrameType
    dlc: int                  # Data Length Code reported in frame
    payload: bytes = b""      # Raw payload bytes (safe default: empty bytes)
    raw_line: str = ""        # Original log line for traceability
    line_number: int = 0      # Line number in the ASC log file
    is_extended: bool = False # True if 29-bit extended CAN ID

    def __post_init__(self):
        """Ensure type safety for payload and frame_type."""
        if self.payload is None:
            self.payload = b""
        elif isinstance(self.payload, (bytearray, list, tuple)):
            self.payload = bytes(self.payload)

    @property
    def can_id_hex(self) -> str:
        """Hexadecimal representation of CAN ID."""
        return f"0x{self.can_id:X}"

    @property
    def payload_hex(self) -> str:
        """Safe hexadecimal representation of payload."""
        if self.payload:
            return self.payload.hex().upper()
        return ""

    @property
    def is_data_frame(self) -> bool:
        """Check if this is a standard data frame."""
        if isinstance(self.frame_type, FrameType):
            return self.frame_type == FrameType.DATA
        ft = str(self.frame_type).strip().lower()
        return ft in ("d", "data", "frametype.data")


@dataclass
class DBCSignal:
    """Represents a signal definition parsed from a DBC file."""
    name: str
    start_bit: int
    length: int
    byte_order: int           # 0 = Motorola / Big Endian, 1 = Intel / Little Endian
    is_signed: bool           # True if signed ('-'), False if unsigned ('+')
    factor: float
    offset: float
    min_val: float
    max_val: float
    unit: str
    receivers: List[str] = field(default_factory=list)
    comment: str = ""
    is_multiplexer: bool = False          # 'M' marker in DBC
    multiplexer_value: Optional[int] = None # 'm<val>' marker in DBC


@dataclass
class DBCMessage:
    """Represents a message definition parsed from a DBC file."""
    can_id: int               # Normalized integer CAN ID
    name: str
    dlc: int                  # Expected size in bytes
    sender: str
    signals: Dict[str, DBCSignal] = field(default_factory=dict)
    cycle_time_ms: Optional[float] = None # Parsed from GenMsgCycleTime or BA_
    send_type: Optional[str] = None       # e.g. "Cyclic", "Spontaneous"
    comment: str = ""
    attributes: Dict[str, Any] = field(default_factory=dict)
    is_extended: bool = False

    @property
    def can_id_hex(self) -> str:
        return f"0x{self.can_id:X}"


@dataclass
class TimingDefinition:
    """Timing expectations for a monitored CAN message."""
    can_id: int
    message_name: str
    expected_period_ms: float
    timeout_multiplier: float
    timeout_threshold_ms: float

    @classmethod
    def create(cls, can_id: int, message_name: str, expected_period_ms: float, multiplier: float = 1.5):
        return cls(
            can_id=can_id,
            message_name=message_name,
            expected_period_ms=expected_period_ms,
            timeout_multiplier=multiplier,
            timeout_threshold_ms=expected_period_ms * multiplier
        )


@dataclass
class CRCDefinition:
    """Explicit CRC/checksum specification for a CAN message."""
    can_id: int
    message_name: str
    crc_signal_name: Optional[str] = None
    start_bit: int = 0
    bit_length: int = 8
    algorithm: str = "CRC8"            # e.g., "CRC8", "CRC8_AUTOSAR", "CRC8_SAE_J1850", "CRC16_CCITT", "CHECKSUM_SUM8", "CHECKSUM_XOR8"
    polynomial: int = 0x1D
    init_value: int = 0xFF
    xor_out: int = 0xFF
    reflect_in: bool = False
    reflect_out: bool = False
    covered_bytes: Optional[List[int]] = None # indices of payload bytes covered (e.g. [0, 1, 2, 3, 4, 5, 6])
    include_can_id: bool = False
    can_id_in_crc: Optional[int] = None
    include_counter: bool = False
    counter_signal_name: Optional[str] = None


@dataclass
class Anomaly:
    """Structured representation of a detected anomaly."""
    timestamp: float
    anomaly_type: AnomalyType
    can_id: int
    can_id_hex: str
    message_name: str
    reason: str
    signal_name: Optional[str] = None
    affected_signals: List[str] = field(default_factory=list)
    details: Dict[str, Any] = field(default_factory=dict)
    line_number: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert anomaly to serializable dictionary."""
        data: Dict[str, Any] = {
            "timestamp": self.timestamp,
            "anomaly_type": self.anomaly_type.value,
            "can_id": self.can_id_hex,
            "can_id_dec": self.can_id,
            "message": self.message_name,
            "reason": self.reason
        }
        if self.signal_name:
            data["signal"] = self.signal_name
        if self.affected_signals:
            data["affected_signals"] = self.affected_signals
        if self.line_number is not None:
            data["line_number"] = self.line_number
        data.update(self.details)
        return data


@dataclass
class AnalysisSummary:
    """Summary metrics of communication integrity analysis."""
    frames_analyzed: int = 0
    messages_monitored: int = 0
    timing_not_available: int = 0
    message_timeouts: int = 0
    signal_timeouts: int = 0
    data_corruptions: int = 0
    crc_mismatches: int = 0
    crc_not_checked: int = 0
    invalid_frames: int = 0
    unknown_messages: int = 0

    def to_dict(self) -> Dict[str, int]:
        return {
            "frames_analyzed": self.frames_analyzed,
            "messages_monitored": self.messages_monitored,
            "timing_not_available": self.timing_not_available,
            "message_timeouts": self.message_timeouts,
            "signal_timeouts": self.signal_timeouts,
            "data_corruptions": self.data_corruptions,
            "crc_mismatches": self.crc_mismatches,
            "crc_not_checked": self.crc_not_checked,
            "invalid_frames": self.invalid_frames,
            "unknown_messages": self.unknown_messages
        }
