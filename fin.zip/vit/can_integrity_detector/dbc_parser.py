"""
DBC File Parser.
Dynamically parses CAN database files (.dbc) to extract message definitions,
signals, multiplexing specifications, comments, and timing attributes
such as GenMsgCycleTime and GenMsgSendType.
"""

import re
from typing import Dict, List, Optional, Tuple, Any
from models import DBCMessage, DBCSignal


class DBCParser:
    """Production-grade DBC file parser."""

    # Regex patterns for DBC sections
    RE_MESSAGE = re.compile(
        r"^BO_\s+(\d+)\s+([a-zA-Z0-9_]+)\s*:\s*(\d+)\s+([a-zA-Z0-9_]+)"
    )
    RE_SIGNAL = re.compile(
        r"^\s*SG_\s+([a-zA-Z0-9_]+)(?:\s+(M|m\d+))?\s*:\s*(\d+)\|(\d+)@([01])([+-])\s*\(([-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?),([-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?)\)\s*\[([-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?)\|([-+]?[0-9]*\.?[0-9]+(?:[eE][-+]?[0-9]+)?)]\s*\"(.*)\"\s+(.*)"
    )
    RE_ATTR_DEF_DEF = re.compile(
        r"^BA_DEF_DEF_\s+\"([a-zA-Z0-9_]+)\"\s+(?:\"([^\"]*)\"|([-+]?[0-9]*\.?[0-9]+));"
    )
    RE_ATTR_VAL_MSG = re.compile(
        r"^BA_\s+\"([a-zA-Z0-9_]+)\"\s+BO_\s+(\d+)\s+(?:\"([^\"]*)\"|([-+]?[0-9]*\.?[0-9]+));"
    )
    RE_ATTR_VAL_SIG = re.compile(
        r"^BA_\s+\"([a-zA-Z0-9_]+)\"\s+SG_\s+(\d+)\s+([a-zA-Z0-9_]+)\s+(?:\"([^\"]*)\"|([-+]?[0-9]*\.?[0-9]+));"
    )
    RE_COMMENT_MSG = re.compile(
        r"^CM_\s+BO_\s+(\d+)\s+\"([^\"]*)\";"
    )
    RE_COMMENT_SIG = re.compile(
        r"^CM_\s+SG_\s+(\d+)\s+([a-zA-Z0-9_]+)\s+\"([^\"]*)\";"
    )

    def __init__(self):
        self.messages: Dict[int, DBCMessage] = {}
        self.attribute_defaults: Dict[str, Any] = {}
        self.version: str = ""
        self.nodes: List[str] = []

    @staticmethod
    def normalize_can_id(raw_id: int) -> Tuple[int, bool]:
        """
        Normalize CAN ID and determine if it is standard (11-bit) or extended (29-bit).
        In Vector DBC format, bit 31 (0x80000000) indicates an extended CAN identifier.
        """
        is_extended = bool(raw_id & 0x80000000)
        normalized_id = raw_id & 0x1FFFFFFF if is_extended else raw_id
        return normalized_id, is_extended

    def parse_file(self, filepath: str) -> Dict[int, DBCMessage]:
        """Parse a DBC file from the given file path."""
        with open(filepath, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        return self.parse_string(content)

    def parse_string(self, content: str) -> Dict[int, DBCMessage]:
        """Parse DBC content from a string."""
        self.messages = {}
        self.attribute_defaults = {}
        current_msg: Optional[DBCMessage] = None

        lines = content.splitlines()
        for line_idx, line in enumerate(lines):
            line_str = line.strip()
            if not line_str:
                continue

            # Parse VERSION
            if line_str.startswith("VERSION"):
                match = re.search(r'VERSION\s+"([^"]*)"', line_str)
                if match:
                    self.version = match.group(1)
                continue

            # Parse BU_ (ECU nodes)
            if line_str.startswith("BU_:"):
                nodes_part = line_str[4:].strip()
                if nodes_part:
                    self.nodes = nodes_part.split()
                continue

            # Parse BO_ (Message definition)
            msg_match = self.RE_MESSAGE.match(line_str)
            if msg_match:
                raw_id = int(msg_match.group(1))
                norm_id, is_ext = self.normalize_can_id(raw_id)
                name = msg_match.group(2)
                dlc = int(msg_match.group(3))
                sender = msg_match.group(4)

                current_msg = DBCMessage(
                    can_id=norm_id,
                    name=name,
                    dlc=dlc,
                    sender=sender,
                    signals={},
                    is_extended=is_ext
                )
                self.messages[norm_id] = current_msg
                continue

            # Parse SG_ (Signal definition inside message)
            sig_match = self.RE_SIGNAL.match(line)
            if sig_match and current_msg is not None:
                name = sig_match.group(1)
                mux_spec = sig_match.group(2)  # 'M', 'm0', 'm1', or None
                start_bit = int(sig_match.group(3))
                length = int(sig_match.group(4))
                byte_order = int(sig_match.group(5))
                is_signed = sig_match.group(6) == "-"
                factor = float(sig_match.group(7))
                offset = float(sig_match.group(8))
                min_val = float(sig_match.group(9))
                max_val = float(sig_match.group(10))
                unit = sig_match.group(11)
                receivers = [r.strip() for r in sig_match.group(12).split(",") if r.strip()]

                is_multiplexer = False
                multiplexer_value = None
                if mux_spec:
                    if mux_spec == "M":
                        is_multiplexer = True
                    elif mux_spec.startswith("m"):
                        try:
                            multiplexer_value = int(mux_spec[1:])
                        except ValueError:
                            pass

                signal = DBCSignal(
                    name=name,
                    start_bit=start_bit,
                    length=length,
                    byte_order=byte_order,
                    is_signed=is_signed,
                    factor=factor,
                    offset=offset,
                    min_val=min_val,
                    max_val=max_val,
                    unit=unit,
                    receivers=receivers,
                    is_multiplexer=is_multiplexer,
                    multiplexer_value=multiplexer_value
                )
                current_msg.signals[name] = signal
                continue

            # Parse BA_DEF_DEF_ (Attribute defaults)
            attr_def_match = self.RE_ATTR_DEF_DEF.match(line_str)
            if attr_def_match:
                attr_name = attr_def_match.group(1)
                str_val = attr_def_match.group(2)
                num_val = attr_def_match.group(3)
                if num_val is not None:
                    try:
                        val = float(num_val) if "." in num_val else int(num_val)
                    except ValueError:
                        val = num_val
                else:
                    val = str_val
                self.attribute_defaults[attr_name] = val
                continue

            # Parse BA_ on BO_ (Message attribute assignments)
            attr_msg_match = self.RE_ATTR_VAL_MSG.match(line_str)
            if attr_msg_match:
                attr_name = attr_msg_match.group(1)
                raw_id = int(attr_msg_match.group(2))
                norm_id, _ = self.normalize_can_id(raw_id)
                str_val = attr_msg_match.group(3)
                num_val = attr_msg_match.group(4)
                if num_val is not None:
                    try:
                        val = float(num_val) if "." in num_val else int(num_val)
                    except ValueError:
                        val = num_val
                else:
                    val = str_val

                if norm_id in self.messages:
                    self.messages[norm_id].attributes[attr_name] = val
                    if attr_name == "GenMsgCycleTime":
                        try:
                            self.messages[norm_id].cycle_time_ms = float(val)
                        except (ValueError, TypeError):
                            pass
                    elif attr_name == "GenMsgSendType":
                        self.messages[norm_id].send_type = str(val)
                continue

            # Parse CM_ BO_ (Message comments)
            cm_msg_match = self.RE_COMMENT_MSG.match(line_str)
            if cm_msg_match:
                raw_id = int(cm_msg_match.group(1))
                norm_id, _ = self.normalize_can_id(raw_id)
                if norm_id in self.messages:
                    self.messages[norm_id].comment = cm_msg_match.group(2)
                continue

            # Parse CM_ SG_ (Signal comments)
            cm_sig_match = self.RE_COMMENT_SIG.match(line_str)
            if cm_sig_match:
                raw_id = int(cm_sig_match.group(1))
                norm_id, _ = self.normalize_can_id(raw_id)
                sig_name = cm_sig_match.group(2)
                if norm_id in self.messages and sig_name in self.messages[norm_id].signals:
                    self.messages[norm_id].signals[sig_name].comment = cm_sig_match.group(3)
                continue

        # Apply default attributes to messages where not explicitly assigned
        default_cycle_time = self.attribute_defaults.get("GenMsgCycleTime")
        default_send_type = self.attribute_defaults.get("GenMsgSendType")

        for msg in self.messages.values():
            if msg.cycle_time_ms is None and default_cycle_time is not None:
                # If send_type is cyclic or default is defined, apply default
                msg_send_type = msg.send_type or default_send_type
                if msg_send_type is None or "cyclic" in str(msg_send_type).lower():
                    try:
                        msg.cycle_time_ms = float(default_cycle_time)
                    except (ValueError, TypeError):
                        pass

            if msg.send_type is None and default_send_type is not None:
                msg.send_type = str(default_send_type)

        return self.messages

    @staticmethod
    def decode_signal(payload: bytes, signal: DBCSignal) -> Optional[float]:
        """
        Extract and decode a raw signal value from payload bytes based on
        start bit, length, endianness, signedness, factor, and offset.
        """
        if not payload:
            return None

        # Build bitstream representation
        total_bits = len(payload) * 8
        raw_val = 0

        if signal.byte_order == 1:
            # Intel / Little Endian
            if signal.start_bit + signal.length > total_bits:
                return None
            for i in range(signal.length):
                bit_pos = signal.start_bit + i
                byte_idx = bit_pos // 8
                bit_idx = bit_pos % 8
                if byte_idx < len(payload):
                    bit = (payload[byte_idx] >> bit_idx) & 1
                    raw_val |= (bit << i)
        else:
            # Motorola / Big Endian (Standard Vector DBC convention)
            # start_bit is the MSB or start position in Vector standard
            curr_byte = signal.start_bit // 8
            curr_bit = signal.start_bit % 8
            for i in range(signal.length):
                if curr_byte >= len(payload):
                    return None
                bit = (payload[curr_byte] >> curr_bit) & 1
                raw_val = (raw_val << 1) | bit
                if curr_bit == 0:
                    curr_byte += 1
                    curr_bit = 7
                else:
                    curr_bit -= 1

        # Handle two's complement signed conversion
        if signal.is_signed:
            msb_mask = 1 << (signal.length - 1)
            if raw_val & msb_mask:
                raw_val -= (1 << signal.length)

        # Apply scaling factor and offset
        physical_val = (raw_val * signal.factor) + signal.offset
        return physical_val

    def get_active_signals(self, msg: DBCMessage, payload: bytes) -> List[str]:
        """
        Returns the list of active signal names in the message given the payload.
        Handles multiplexed signals dynamically by decoding the multiplexor signal.
        """
        if not msg.signals:
            return []

        # Find multiplexor if any
        mux_signal = None
        for sig in msg.signals.values():
            if sig.is_multiplexer:
                mux_signal = sig
                break

        active: List[str] = []
        if mux_signal is None:
            # No multiplexing: all signals active
            return list(msg.signals.keys())

        # Decode multiplexor value
        mux_val = self.decode_signal(payload, mux_signal)
        mux_int = int(mux_val) if mux_val is not None else None

        for sig_name, sig in msg.signals.items():
            if sig.is_multiplexer:
                active.append(sig_name)
            elif sig.multiplexer_value is None:
                active.append(sig_name)
            elif mux_int is not None and sig.multiplexer_value == mux_int:
                active.append(sig_name)

        return active
