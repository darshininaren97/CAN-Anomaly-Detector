"""
Report Generator for CAN Communication Integrity Analysis.
Produces clean human-readable console reports, structured JSON files,
and detailed summary metrics.
"""

import json
from typing import List, Dict, Any, Optional
from models import Anomaly, AnomalyType, AnalysisSummary


class AnomalyReporter:
    """Formats and exports communication integrity detection results."""

    @staticmethod
    def format_console_report(anomalies: List[Anomaly], summary: AnalysisSummary) -> str:
        """Format detection results into a clean, human-readable terminal report."""
        lines = []
        lines.append("=" * 60)
        lines.append("CAN COMMUNICATION INTEGRITY REPORT")
        lines.append("=" * 60)

        if not anomalies:
            lines.append("\nNo integrity anomalies detected. All monitored messages arrived on schedule.")
        else:
            for idx, anomaly in enumerate(anomalies, start=1):
                lines.append("")
                lines.append(f"[{idx}] {anomaly.anomaly_type.value}")
                lines.append("-" * 60)
                lines.append(f"Timestamp:          {anomaly.timestamp:0.6f} s")
                lines.append(f"CAN ID:             {anomaly.can_id_hex} (dec: {anomaly.can_id})")
                lines.append(f"Message:            {anomaly.message_name}")

                if anomaly.signal_name:
                    lines.append(f"Signal:             {anomaly.signal_name}")
                elif anomaly.affected_signals:
                    sig_list = ", ".join(anomaly.affected_signals[:5])
                    if len(anomaly.affected_signals) > 5:
                        sig_list += f" (+{len(anomaly.affected_signals)-5} more)"
                    lines.append(f"Affected Signals:   {sig_list}")

                if anomaly.anomaly_type in (AnomalyType.MESSAGE_TIMEOUT, AnomalyType.SIGNAL_TIMEOUT):
                    exp = anomaly.details.get("expected_period_ms", "N/A")
                    allowed = anomaly.details.get("allowed_gap_ms", "N/A")
                    actual = anomaly.details.get("actual_gap_ms", "N/A")
                    prev_t = anomaly.details.get("previous_timestamp", "N/A")

                    lines.append("")
                    lines.append(f"Expected Period:    {exp} ms")
                    lines.append(f"Allowed Gap:        {allowed} ms")
                    lines.append(f"Actual Gap:         {actual} ms")
                    lines.append(f"Previous Frame:     {prev_t} s")
                    lines.append(f"Status:             TIMEOUT")

                elif anomaly.anomaly_type == AnomalyType.CRC_MISMATCH:
                    rec_crc = anomaly.details.get("received_crc", "N/A")
                    calc_crc = anomaly.details.get("calculated_crc", "N/A")
                    algo = anomaly.details.get("algorithm", "N/A")

                    lines.append("")
                    lines.append(f"Received CRC:       {rec_crc}")
                    lines.append(f"Calculated CRC:     {calc_crc}")
                    lines.append(f"Algorithm:          {algo}")
                    lines.append(f"Status:             CRC MISMATCH")

                elif anomaly.anomaly_type == AnomalyType.DATA_CORRUPTION:
                    rep_dlc = anomaly.details.get("reported_dlc", "N/A")
                    act_len = anomaly.details.get("actual_payload_len", "N/A")
                    raw_hex = anomaly.details.get("raw_payload_hex", "N/A")

                    lines.append("")
                    lines.append(f"Reported DLC:       {rep_dlc}")
                    lines.append(f"Payload Bytes:      {act_len}")
                    if raw_hex:
                        lines.append(f"Payload Hex:        {raw_hex}")
                    lines.append(f"Status:             DATA CORRUPTION")

                lines.append("")
                lines.append("Reason:")
                lines.append(anomaly.reason)
                lines.append("-" * 60)

        # Summary Section
        lines.append("")
        lines.append("=" * 60)
        lines.append("CAN COMMUNICATION SUMMARY")
        lines.append("=" * 60)
        lines.append(f"Frames analyzed:             {summary.frames_analyzed:,}")
        lines.append(f"Messages monitored:          {summary.messages_monitored:,}")
        lines.append(f"Timing not available:        {summary.timing_not_available:,}")
        lines.append("")
        lines.append(f"Message timeouts:            {summary.message_timeouts:,}")
        lines.append(f"Signal communication timeouts:{summary.signal_timeouts:,}")
        lines.append(f"Data corruption:             {summary.data_corruptions:,}")
        lines.append(f"CRC mismatches:              {summary.crc_mismatches:,}")
        lines.append(f"CRC not checked:             {summary.crc_not_checked:,}")
        lines.append(f"Invalid frames:              {summary.invalid_frames:,}")
        lines.append(f"Unknown messages:            {summary.unknown_messages:,}")
        lines.append("=" * 60)

        return "\n".join(lines)

    @staticmethod
    def export_json(anomalies: List[Anomaly], summary: AnalysisSummary, output_path: str) -> None:
        """Export analysis results and anomalies into a structured JSON file."""
        data = {
            "summary": summary.to_dict(),
            "anomalies": [a.to_dict() for a in anomalies]
        }
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    @staticmethod
    def to_dict(anomalies: List[Anomaly], summary: AnalysisSummary) -> Dict[str, Any]:
        """Convert anomalies and summary into a dictionary."""
        return {
            "summary": summary.to_dict(),
            "anomalies": [a.to_dict() for a in anomalies]
        }
