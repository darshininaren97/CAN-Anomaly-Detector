"""
detectors/integrity_detector.py
CAN Communication Integrity Anomaly Detector Adapter.
Integrates missing message / signal timeouts, deterministic data corruption / DLC mismatch,
and application-layer CRC / checksum validation from can_integrity_detector.
"""

from __future__ import annotations
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

# Ensure can_integrity_detector package is accessible and its local imports resolve
_INTEGRITY_DIR = str(Path(__file__).resolve().parent.parent / "can_integrity_detector")
_saved_sys_path = list(sys.path)
try:
    if _INTEGRITY_DIR not in sys.path:
        sys.path.insert(0, _INTEGRITY_DIR)
    else:
        sys.path.remove(_INTEGRITY_DIR)
        sys.path.insert(0, _INTEGRITY_DIR)

    from can_integrity_detector.models import (
        CANFrame as IntegrityCANFrame,
        DBCMessage as IntegrityDBCMessage,
        Anomaly as IntegrityAnomaly,
        AnomalyType as IntegrityAnomalyType,
        CRCDefinition as IntegrityCRCDefinition,
    )
    from can_integrity_detector.dbc_parser import DBCParser as IntegrityDBCParser
    from can_integrity_detector.integrity_validator import IntegrityValidator
    from can_integrity_detector.timing_monitor import TimingMonitor
    from can_integrity_detector.crc_validator import CRCValidator
    from can_integrity_detector.main import load_external_config
finally:
    sys.path = _saved_sys_path

from core.models import CANFrame, DecodedFrame, UnifiedAnomaly, Severity, AnomalyCategory
from detectors.base import BaseAnomalyDetector
from parsers.dbc_parser import DBCDatabase


class IntegrityAnomalyDetector(BaseAnomalyDetector):
    """
    Adapter for can_integrity_detector evaluating:
    1. Data Corruption & Payload Count Mismatches
    2. Message & Signal Cycle-Time Timeouts (via DBC GenMsgCycleTime or config)
    3. Application-Layer CRC / Checksum Mismatches
    """

    def __init__(
        self,
        is_enabled: bool = True,
        timeout_multiplier: float = 1.5,
        config_path: Optional[str] = None,
    ) -> None:
        super().__init__(
            name="CAN Integrity Detector",
            description="Detects data corruption, message/signal timeouts, and application CRC mismatches",
            is_enabled=is_enabled,
        )
        self.timeout_multiplier = timeout_multiplier
        self.config_path = config_path
        self.external_timing: Dict[int, float] = {}
        self.crc_definitions: Dict[int, IntegrityCRCDefinition] = {}

        if config_path and Path(config_path).exists():
            try:
                self.external_timing, self.crc_definitions = load_external_config(config_path)
            except Exception:
                pass

    def reset(self) -> None:
        pass

    def analyze(
        self,
        frames: Sequence[CANFrame],
        decoded_frames: Sequence[DecodedFrame],
        db: Optional[DBCDatabase] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[UnifiedAnomaly]:
        if not self.is_enabled or not frames:
            return []

        # Load DBC messages with cycle time attributes using can_integrity_detector parser
        dbc_messages: Dict[int, IntegrityDBCMessage] = {}
        dbc_parser_instance = IntegrityDBCParser()
        dbc_file = None
        if context and "config" in context and hasattr(context["config"], "dbc_path"):
            dbc_file = context["config"].dbc_path

        if dbc_file:
            dbc_p = Path(dbc_file)
            if not dbc_p.exists():
                raise FileNotFoundError(f"DBC file not found: {dbc_file}")
            dbc_messages = dbc_parser_instance.parse_file(str(dbc_p))

        # Check for config path in context
        if context and "config" in context and hasattr(context["config"], "integrity_config_path"):
            cfg = getattr(context["config"], "integrity_config_path")
            if cfg:
                cfg_p = Path(cfg)
                if not cfg_p.exists():
                    raise FileNotFoundError(f"Integrity config file not found: {cfg}")
                self.external_timing, self.crc_definitions = load_external_config(str(cfg_p))

        # Instantiate validators
        integrity_validator = IntegrityValidator(dbc_messages)
        timing_monitor = TimingMonitor(
            dbc_messages=dbc_messages,
            timeout_multiplier=self.timeout_multiplier,
            external_timing=self.external_timing,
            dbc_parser=dbc_parser_instance,
            min_timeout_ms=4000.0,
        )
        crc_validator = CRCValidator(self.crc_definitions)

        anomalies: List[UnifiedAnomaly] = []

        for f in frames:
            # Convert canonical CANFrame to can_integrity_detector.models.CANFrame
            iframe = IntegrityCANFrame(
                timestamp=f.timestamp,
                channel=f.channel,
                can_id=f.can_id,
                direction=f.direction,
                frame_type=f.frame_type,
                dlc=f.dlc,
                payload=f.data,
                raw_line=f.raw_line,
                line_number=f.line_number or 0,
                is_extended=f.is_extended,
            )

            # 1. Payload Data Corruption Check
            _, i_anom = integrity_validator.validate_frame(iframe)
            if i_anom is not None:
                anomalies.append(self._map_anomaly(i_anom, f))

            # 2. Timing / Missing Message Check
            _, t_anom = timing_monitor.process_frame(iframe)
            if t_anom is not None:
                anomalies.append(self._map_anomaly(t_anom, f))

            # 3. Application-Layer CRC Check
            _, c_anom, _ = crc_validator.validate_frame(iframe)
            if c_anom is not None:
                anomalies.append(self._map_anomaly(c_anom, f))

        return anomalies

    def _map_anomaly(self, anom: IntegrityAnomaly, frame: CANFrame) -> UnifiedAnomaly:
        """Translate can_integrity_detector.models.Anomaly to UnifiedAnomaly."""
        type_str = anom.anomaly_type.value if hasattr(anom.anomaly_type, "value") else str(anom.anomaly_type)

        # Map category & severity
        if type_str == IntegrityAnomalyType.DATA_CORRUPTION.value:
            cat = AnomalyCategory.DATA_CORRUPTION
            sev = Severity.HIGH
        elif type_str == IntegrityAnomalyType.MESSAGE_TIMEOUT.value:
            cat = AnomalyCategory.MESSAGE_TIMEOUT
            sev = Severity.HIGH
        elif type_str == IntegrityAnomalyType.SIGNAL_TIMEOUT.value:
            cat = AnomalyCategory.SIGNAL_TIMEOUT
            sev = Severity.HIGH
        elif type_str == IntegrityAnomalyType.CRC_MISMATCH.value:
            cat = AnomalyCategory.CRC_MISMATCH
            sev = Severity.CRITICAL
        else:
            cat = AnomalyCategory.OTHER
            sev = Severity.HIGH

        return UnifiedAnomaly(
            timestamp=anom.timestamp,
            anomaly_type=type_str,
            category=cat,
            severity=sev,
            detector=self.name,
            can_id=anom.can_id,
            can_id_hex=anom.can_id_hex or frame.hex_id,
            message_name=anom.message_name,
            is_extended=frame.is_extended,
            reason=anom.reason,
            context=dict(anom.details) if hasattr(anom, "details") and anom.details else {},
        )
