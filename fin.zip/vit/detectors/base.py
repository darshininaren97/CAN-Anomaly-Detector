"""
detectors/base.py
Base abstract interface for modular CAN Bus anomaly detectors.
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional, Sequence
from core.models import CANFrame, DecodedFrame, UnifiedAnomaly
from parsers.dbc_parser import DBCDatabase


class BaseAnomalyDetector(ABC):
    """
    Standard interface for all CAN Bus anomaly detection modules.
    Ensures detectors can be configured, executed, and reset uniformly.
    """

    def __init__(self, name: str, description: str, is_enabled: bool = True) -> None:
        self.name = name
        self.description = description
        self.is_enabled = is_enabled

    @abstractmethod
    def reset(self) -> None:
        """Reset internal state, caches, and history."""
        pass

    @abstractmethod
    def analyze(
        self,
        frames: Sequence[CANFrame],
        decoded_frames: Sequence[DecodedFrame],
        db: Optional[DBCDatabase] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[UnifiedAnomaly]:
        """
        Execute anomaly detection across the provided frame and signal stream.
        
        :param frames: Sequence of parsed raw CAN frames
        :param decoded_frames: Sequence of decoded frames with signals
        :param db: Optional parsed DBC database
        :param context: Optional execution context / parameters
        :return: List of detected UnifiedAnomaly instances
        """
        pass
