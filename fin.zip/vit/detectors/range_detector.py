"""
detectors/range_detector.py
Range Anomaly Detector Adapter.
Integrates the DBC range validation logic from can_range_anomaly_detector_outofrange.
"""

from __future__ import annotations
import math
from typing import Any, Dict, List, Optional, Sequence
from core.models import CANFrame, DecodedFrame, UnifiedAnomaly, Severity, AnomalyCategory
from detectors.base import BaseAnomalyDetector
from parsers.dbc_parser import DBCDatabase


class RangeAnomalyDetector(BaseAnomalyDetector):
    """
    Evaluates decoded signal values against DBC-defined physical range bounds (minimum / maximum).
    Uses calibrated tolerance margins to account for floating-point DBC decoding variances and operational noise.
    """

    def __init__(self, is_enabled: bool = True, tolerance: float = 1e-4) -> None:
        super().__init__(
            name="Range Detector",
            description="Detects signal values outside DBC-defined min/max ranges",
            is_enabled=is_enabled,
        )
        self.tolerance = tolerance

    def reset(self) -> None:
        pass

    def analyze(
        self,
        frames: Sequence[CANFrame],
        decoded_frames: Sequence[DecodedFrame],
        db: Optional[DBCDatabase] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[UnifiedAnomaly]:
        if not self.is_enabled:
            return []

        anomalies: List[UnifiedAnomaly] = []

        for df in decoded_frames:
            frame = df.frame
            for sig_name, sig in df.signals.items():
                if not sig.has_usable_range:
                    continue

                min_val = sig.minimum
                max_val = sig.maximum
                assert min_val is not None and max_val is not None

                phys_val = sig.physical_value
                if not math.isfinite(phys_val):
                    continue

                # Calibrate tolerance to account for floating point decoding variances and noise
                tol = max(self.tolerance, abs(sig.factor) * 1e-3)
                is_under = phys_val < (min_val - tol)
                is_over = phys_val > (max_val + tol)

                if is_under or is_over:
                    reason = (
                        f"Signal '{sig.name}' value {phys_val} is below minimum ({min_val})"
                        if is_under
                        else f"Signal '{sig.name}' value {phys_val} exceeds maximum ({max_val})"
                    )

                    # Context-aware severity scoring based on deviation ratio and safety criticality
                    span = max_val - min_val
                    dev = (min_val - phys_val) if is_under else (phys_val - max_val)
                    if span > 0:
                        ratio = dev / span
                        if ratio >= 0.50 or (sig.name == "Engine_RPM" and ratio >= 0.20):
                            severity = Severity.CRITICAL
                        elif ratio >= 0.20:
                            severity = Severity.HIGH
                        elif ratio >= 0.05:
                            severity = Severity.MEDIUM
                        else:
                            severity = Severity.LOW
                    else:
                        severity = Severity.MEDIUM

                    anomaly = UnifiedAnomaly(
                        timestamp=frame.timestamp,
                        anomaly_type="RANGE_ANOMALY",
                        category=AnomalyCategory.RANGE,
                        severity=severity,
                        detector=self.name,
                        can_id=frame.can_id,
                        can_id_hex=frame.hex_id,
                        message_name=df.message_name,
                        signal_name=sig.name,
                        signals=[sig.name],
                        observed_value=phys_val,
                        expected_range=(min_val, max_val),
                        unit=sig.unit,
                        is_extended=frame.is_extended,
                        reason=reason,
                        context={
                            "raw_value": sig.raw_value,
                            "physical_value": phys_val,
                            "minimum": min_val,
                            "maximum": max_val,
                            "factor": sig.factor,
                            "offset": sig.offset,
                            "violation": "BELOW_MINIMUM" if is_under else "EXCEEDS_MAXIMUM",
                        },
                    )
                    anomalies.append(anomaly)

        return anomalies
