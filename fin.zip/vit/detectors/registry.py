"""
detectors/registry.py
Detector Registry and Factory for CAN Bus anomaly detection.
Enables pluggable detector discovery, filtering, and execution management.
"""

from __future__ import annotations
from typing import Callable, Dict, List, Optional, Sequence
from detectors.base import BaseAnomalyDetector
from detectors.range_detector import RangeAnomalyDetector
from detectors.logic_detector import LogicAnomalyDetector
from detectors.timing_detector import TimingAnomalyDetector
from detectors.frame_detector import FrameAnomalyDetector
from detectors.integrity_detector import IntegrityAnomalyDetector


class DetectorRegistry:
    """Registry managing available anomaly detection modules."""

    _factories: Dict[str, Callable[[], BaseAnomalyDetector]] = {
        "range": lambda: RangeAnomalyDetector(),
        "logic": lambda: LogicAnomalyDetector(),
        "timing": lambda: TimingAnomalyDetector(),
        "frame": lambda: FrameAnomalyDetector(),
        "integrity": lambda: IntegrityAnomalyDetector(),
    }

    @classmethod
    def register(cls, key: str, factory: Callable[[], BaseAnomalyDetector]) -> None:
        """Register a new detector factory."""
        cls._factories[key.lower()] = factory

    @classmethod
    def get_available_keys(cls) -> List[str]:
        """Return list of registered detector keys."""
        return list(cls._factories.keys())

    @classmethod
    def create_detectors(cls, selection: str = "all") -> List[BaseAnomalyDetector]:
        """
        Create detector instances based on comma-separated selection string or 'all'.
        
        Examples:
            'all' -> RangeAnomalyDetector, LogicAnomalyDetector, TimingAnomalyDetector, FrameAnomalyDetector
            'range,logic' -> RangeAnomalyDetector, LogicAnomalyDetector
        """
        clean_sel = selection.strip().lower()
        if clean_sel in ["all", "*", ""]:
            keys_to_build = list(cls._factories.keys())
        else:
            requested = [k.strip() for k in clean_sel.split(",") if k.strip()]
            keys_to_build = []
            for r in requested:
                if r in cls._factories:
                    keys_to_build.append(r)
                else:
                    valid = ", ".join(cls._factories.keys())
                    raise ValueError(f"Unknown detector key '{r}'. Available detectors: {valid}")

        return [cls._factories[k]() for k in keys_to_build]
