"""
detectors/timing_detector.py
Timing, Temporal, and Behavioral Anomaly Detector Adapter.
Integrates TimingAnalyzer from timing_module to detect jitter, flooding bursts,
duplicate payload bursts, communication timeouts, and ECU behavioral deviations.
"""

from __future__ import annotations
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

# Ensure timing_module package is on sys.path
_TIMING_DIR = Path(__file__).resolve().parent.parent / "timing_module"
if str(_TIMING_DIR) not in sys.path:
    sys.path.insert(0, str(_TIMING_DIR))

from timing_module.config import TimingConfig
from timing_module.models import AnomalyType as TimingAnomalyType, Frame as TimingFrame
from timing_module.timing_analyzer import TimingAnalyzer
from core.models import CANFrame, DecodedFrame, UnifiedAnomaly, Severity, AnomalyCategory
from detectors.base import BaseAnomalyDetector
from parsers.dbc_parser import DBCDatabase


class TimingAnomalyDetector(BaseAnomalyDetector):
    """
    Analyzes inter-frame timing intervals, transmission rates, payload repetitions,
    and timeout gaps across CAN streams using TimingAnalyzer.
    """

    def __init__(
        self,
        config: Optional[TimingConfig] = None,
        is_enabled: bool = True,
    ) -> None:
        super().__init__(
            name="Timing & Behavioral Detector",
            description="Detects timing jitter, flooding bursts, replay bursts, and communication timeouts",
            is_enabled=is_enabled,
        )
        self.config = config or TimingConfig(
            flooding_ratio_threshold=0.50,
            min_timeout_seconds=4.0,
            enable_point_jitter=False,
        )
        self.analyzer = TimingAnalyzer(config=self.config)

    def reset(self) -> None:
        """Reset internal profiles and analyzer state."""
        self.analyzer = TimingAnalyzer(config=self.config)

    def analyze(
        self,
        frames: Sequence[CANFrame],
        decoded_frames: Sequence[DecodedFrame],
        db: Optional[DBCDatabase] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[UnifiedAnomaly]:
        if not self.is_enabled or not frames:
            return []

        # Convert canonical CANFrame sequence to TimingFrame objects
        # Resolve ECU sender from DBC if available
        timing_frames: List[TimingFrame] = []
        for f in frames:
            ecu = f.ecu
            if not ecu and db is not None:
                msg_def = db.get_message(f.can_id, f.is_extended)
                if msg_def:
                    ecu = msg_def.sender

            tf = TimingFrame(
                timestamp=f.timestamp,
                can_id=f.can_id,
                can_id_hex=f.hex_id,
                data=f.data_hex,
                dlc=f.dlc,
                ecu=ecu,
            )
            timing_frames.append(tf)

        # Fit baseline on traffic stream
        self.analyzer.fit(timing_frames)

        # Override baseline profiles with DBC-defined cycle times
        if db is not None:
            from timing_module.models import BaselineProfile
            for msg_def in db:
                hex_key = f"0x{msg_def.id:X}"
                if msg_def.cycle_time_ms is not None and msg_def.cycle_time_ms > 0:
                    nominal_s = msg_def.cycle_time_ms / 1000.0
                    existing = self.analyzer.baseline_profiles.get(hex_key)
                    sample_cnt = existing.sample_count if existing else 10
                    self.analyzer.baseline_profiles[hex_key] = BaselineProfile(
                        can_id=hex_key,
                        can_id_int=msg_def.id,
                        sample_count=sample_cnt,
                        median_interval=nominal_s,
                        mean_interval=nominal_s,
                        std_interval=0.0,
                        min_interval=nominal_s,
                        max_interval=nominal_s,
                        frames_per_second=(1.0 / nominal_s) if nominal_s > 0 else 0.0,
                        coefficient_of_variation=0.0,
                        ecu=msg_def.sender or (existing.ecu if existing else None),
                    )

        # Execute temporal & behavioral analysis
        timing_anomalies = self.analyzer.analyze(timing_frames)

        category_map = {
            TimingAnomalyType.TIMING_DEVIATION: AnomalyCategory.TIMING_DEVIATION,
            TimingAnomalyType.TIMING_FLOODING: AnomalyCategory.TIMING_FLOODING,
            TimingAnomalyType.DUPLICATE_BURST: AnomalyCategory.DUPLICATE_BURST,
            TimingAnomalyType.TIMING_TIMEOUT: AnomalyCategory.TIMING_TIMEOUT,
            TimingAnomalyType.ECU_BEHAVIOR_DEVIATION: AnomalyCategory.ECU_BEHAVIOR_DEVIATION,
        }

        severity_map = {
            "CRITICAL": Severity.CRITICAL,
            "HIGH": Severity.HIGH,
            "MEDIUM": Severity.MEDIUM,
            "LOW": Severity.LOW,
        }

        unified_list: List[UnifiedAnomaly] = []
        for ta in timing_anomalies:
            # Parse CAN ID integer if possible
            can_id_int: Optional[int] = None
            try:
                can_id_int = int(ta.can_id, 16) if ta.can_id.startswith("0x") else int(ta.can_id)
            except Exception:
                can_id_int = None

            # Resolve category
            anom_type_enum = ta.anomaly_type
            cat = category_map.get(anom_type_enum, AnomalyCategory.OTHER)
            type_str = anom_type_enum.value if hasattr(anom_type_enum, "value") else str(anom_type_enum)

            sev_str = ta.severity.value if hasattr(ta.severity, "value") else str(ta.severity)
            sev = severity_map.get(sev_str.upper(), Severity.MEDIUM)

            msg_name: Optional[str] = None
            if can_id_int is not None and db is not None:
                mdef = db.get_message(can_id_int)
                if mdef:
                    msg_name = mdef.name

            ctx = {
                "start_time": ta.start_time,
                "end_time": ta.end_time,
                "deviation": ta.deviation,
                "abnormal_frame_count": ta.abnormal_frame_count,
                "possible_causes": ta.possible_causes,
                "evidence": ta.evidence,
            }

            unified_anomaly = UnifiedAnomaly(
                timestamp=ta.timestamp,
                anomaly_type=type_str,
                category=cat,
                severity=sev,
                detector=self.name,
                can_id=can_id_int,
                can_id_hex=ta.can_id,
                message_name=msg_name,
                observed_value=ta.observed_value,
                expected_value=ta.expected_value,
                ecu=ta.ecu,
                reason=ta.diagnosis,
                context=ctx,
            )
            unified_list.append(unified_anomaly)

        return unified_list
