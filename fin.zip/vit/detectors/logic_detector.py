"""
detectors/logic_detector.py
Contradictory Signal & Correlation Anomaly Detector Adapter.
Integrates the rule engine and temporal signal history tracking from can_anomaly_detector_logic.
"""

from __future__ import annotations
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

# Ensure can_anomaly_detector_logic is accessible
_LOGIC_DIR = Path(__file__).resolve().parent.parent / "can_anomaly_detector_logic"
if str(_LOGIC_DIR) not in sys.path:
    sys.path.append(str(_LOGIC_DIR))

from can_anomaly_detector_logic.signal_history import SignalHistory
from can_anomaly_detector_logic.rules import BaseRule, create_all_rules
from core.models import CANFrame, DecodedFrame, UnifiedAnomaly, Severity, AnomalyCategory
from detectors.base import BaseAnomalyDetector
from parsers.dbc_parser import DBCDatabase


class LogicAnomalyDetector(BaseAnomalyDetector):
    """
    Evaluates temporal and multi-signal correlations, state contradictions,
    and physical plausibility rules across CAN signal streams (R-001 through R-007).
    """

    def __init__(
        self,
        rules: Optional[List[BaseRule]] = None,
        max_history: int = 200,
        history_window_seconds: float = 5.0,
        is_enabled: bool = True,
    ) -> None:
        super().__init__(
            name="Logic & Correlation Detector",
            description="Evaluates contradictory signals and physical correlation rules (R-001..R-007)",
            is_enabled=is_enabled,
        )
        self.max_history = max_history
        self.history_window_seconds = history_window_seconds
        self.history = SignalHistory(
            max_history_per_signal=max_history,
            time_window_seconds=history_window_seconds,
        )
        self.rules: List[BaseRule] = list(rules) if rules is not None else create_all_rules()

    def reset(self) -> None:
        """Reset signal history and all rule states."""
        self.history.clear()
        for rule in self.rules:
            rule.reset()

    def analyze(
        self,
        frames: Sequence[CANFrame],
        decoded_frames: Sequence[DecodedFrame],
        db: Optional[DBCDatabase] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[UnifiedAnomaly]:
        if not self.is_enabled:
            return []

        self.reset()
        anomalies: List[UnifiedAnomaly] = []

        for df in decoded_frames:
            if not df.signals:
                continue

            frame = df.frame
            # Update temporal signal history
            self.history.record(frame, df.message_name, df.signals)

            # Evaluate each enabled rule
            for rule in self.rules:
                if not rule.is_enabled:
                    continue

                try:
                    res = rule.evaluate(frame, df.signals, self.history)
                    if res is not None:
                        # Determine category
                        rule_type = str(res.anomaly_type).lower()
                        if "contradictory" in rule_type:
                            cat = AnomalyCategory.CONTRADICTORY_SIGNAL
                            sev = Severity.HIGH
                        elif "correlation" in rule_type:
                            cat = AnomalyCategory.SIGNAL_CORRELATION
                            sev = Severity.MEDIUM
                        else:
                            cat = AnomalyCategory.OTHER
                            sev = Severity.HIGH

                        anomaly = UnifiedAnomaly(
                            timestamp=res.timestamp,
                            anomaly_type=res.anomaly_type,
                            category=cat,
                            severity=sev,
                            detector=self.name,
                            can_id=frame.can_id,
                            can_id_hex=frame.hex_id,
                            message_name=df.message_name,
                            signals=list(res.signals),
                            rule_id=res.rule_id,
                            reason=res.reason,
                            context=dict(res.context) if hasattr(res, "context") and res.context else {},
                        )
                        # Add values to context for transparency
                        if hasattr(res, "values") and res.values:
                            anomaly.context["observed_signals"] = res.values

                        anomalies.append(anomaly)
                except Exception as e:
                    # Isolate rule-specific execution errors without breaking pipeline
                    pass

        return anomalies
