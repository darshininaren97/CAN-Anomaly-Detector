"""
detectors/frame_detector.py
Frame Format, DLC Mismatch, and Out-of-Frame Anomaly Detector Adapter.
Validates raw frame lengths against DBC DLC specifications, catches decoding anomalies,
and detects truncated or malformed payloads.
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional, Sequence
from core.models import CANFrame, DecodedFrame, UnifiedAnomaly, Severity, AnomalyCategory
from detectors.base import BaseAnomalyDetector
from parsers.dbc_parser import DBCDatabase


class FrameAnomalyDetector(BaseAnomalyDetector):
    """
    Detects payload length mismatches against DBC message DLC,
    out-of-frame bit extraction anomalies, and frame decoding failures.
    """

    def __init__(
        self,
        is_enabled: bool = True,
        check_dlc_mismatch: bool = True,
        check_decoding_errors: bool = True,
    ) -> None:
        super().__init__(
            name="Frame & Format Detector",
            description="Detects DLC payload mismatches, out-of-frame errors, and decoding failures",
            is_enabled=is_enabled,
        )
        self.check_dlc_mismatch = check_dlc_mismatch
        self.check_decoding_errors = check_decoding_errors

    def reset(self) -> None:
        pass

    def analyze(
        self,
        frames: Sequence[CANFrame],
        decoded_frames: Sequence[DecodedFrame],
        db: Optional[DBCDatabase] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> List[UnifiedAnomaly]:
        if not self.is_enabled:
            return []

        anomalies: List[UnifiedAnomaly] = []

        # 1. Check DLC mismatches across all frames against DBC
        if self.check_dlc_mismatch and db is not None:
            for frame in frames:
                msg_def = db.get_message(frame.can_id, frame.is_extended)
                if msg_def is None:
                    continue

                actual_len = len(frame.data)
                expected_dlc = msg_def.dlc

                if actual_len < expected_dlc:
                    anomaly = UnifiedAnomaly(
                        timestamp=frame.timestamp,
                        anomaly_type="DLC_MISMATCH",
                        category=AnomalyCategory.FRAME_FORMAT,
                        severity=Severity.HIGH,
                        detector=self.name,
                        can_id=frame.can_id,
                        can_id_hex=frame.hex_id,
                        message_name=msg_def.name,
                        observed_value=actual_len,
                        expected_value=expected_dlc,
                        unit="bytes",
                        is_extended=frame.is_extended,
                        reason=(
                            f"Frame payload length ({actual_len} bytes) is less than DBC DLC "
                            f"({expected_dlc} bytes) for message '{msg_def.name}'"
                        ),
                        context={
                            "actual_payload_len": actual_len,
                            "expected_dlc": expected_dlc,
                            "payload_hex": frame.data_hex,
                        },
                    )
                    anomalies.append(anomaly)

        # 2. Check decoding errors reported during signal extraction
        if self.check_decoding_errors:
            for df in decoded_frames:
                if df.errors:
                    frame = df.frame
                    for err in df.errors:
                        anomaly = UnifiedAnomaly(
                            timestamp=frame.timestamp,
                            anomaly_type="DECODING_ERROR",
                            category=AnomalyCategory.DECODING_ERROR,
                            severity=Severity.HIGH,
                            detector=self.name,
                            can_id=frame.can_id,
                            can_id_hex=frame.hex_id,
                            message_name=df.message_name,
                            is_extended=frame.is_extended,
                            reason=err,
                            context={"payload_hex": frame.data_hex},
                        )
                        anomalies.append(anomaly)

        return anomalies
