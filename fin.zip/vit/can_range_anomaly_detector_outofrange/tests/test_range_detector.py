import pytest
from models import DBCMessage, DBCSignal, CANFrame, RangeAnomaly, DecodedSignal, DBCDatabase
from range_detector import detect_range_anomalies

def test_detect_range_anomalies_basic():
    # Setup test DBC database
    sig = DBCSignal(
        name="Engine_RPM", start_bit=0, length=16, byte_order=1, signed=False,
        factor=0.25, offset=0.0, minimum=0.0, maximum=8000.0, unit="RPM"
    )
    msg = DBCMessage(id=201, name="EngineData", dlc=8, sender="Engine_ECU", signals=[sig])
    dbc_messages = DBCDatabase()
    dbc_messages[(201, False)] = msg
    
    # Test case 1: Valid value within range (Engine_RPM raw = 32000 -> physical = 8000.0)
    frame_valid = CANFrame(
        timestamp=1.0, channel=1, can_id=201, direction="Rx", frame_type="d", dlc=8,
        payload=bytes.fromhex("007D000000000000") # 32000 raw -> 8000.0 physical
    )
    status, details = detect_range_anomalies(frame_valid, dbc_messages)
    assert status == 'VALID'
    assert len(details) == 1
    assert isinstance(details[0], DecodedSignal)
    assert details[0].physical_value == 8000.0
    
    # Test case 2: Out of range (Engine_RPM raw = 65535 -> physical = 16383.75)
    frame_anomaly = CANFrame(
        timestamp=2.0, channel=1, can_id=201, direction="Rx", frame_type="d", dlc=8,
        payload=bytes.fromhex("FFFF000000000000")
    )
    status, details = detect_range_anomalies(frame_anomaly, dbc_messages)
    assert status == 'RANGE_ANOMALY'
    assert len(details) == 1
    assert isinstance(details[0], RangeAnomaly)
    assert details[0].physical_value == 16383.75
    assert details[0].reason == "Value exceeds maximum"

def test_range_boundaries_inclusive():
    # Range [0, 100]
    sig = DBCSignal(
        name="TestSig", start_bit=0, length=8, byte_order=1, signed=False,
        factor=1.0, offset=0.0, minimum=0.0, maximum=100.0, unit="%"
    )
    msg = DBCMessage(id=100, name="TestMsg", dlc=1, sender="ECU", signals=[sig])
    dbc_messages = DBCDatabase()
    dbc_messages[(100, False)] = msg
    
    # Helper to test raw payload value
    def check_val(val: int):
        f = CANFrame(1.0, 1, 100, "Rx", "d", 1, bytes([val]))
        return detect_range_anomalies(f, dbc_messages)
        
    # 0 -> valid
    status, details = check_val(0)
    assert status == 'VALID'
    
    # 100 -> valid
    status, details = check_val(100)
    assert status == 'VALID'
    
    # 101 -> anomaly
    status, details = check_val(101)
    assert status == 'RANGE_ANOMALY'
    assert isinstance(details[0], RangeAnomaly)
    assert details[0].physical_value == 101.0
    assert details[0].reason == "Value exceeds maximum"

def test_floating_point_precision_tolerance():
    # Max is 100.0
    sig = DBCSignal(
        name="TestSig", start_bit=0, length=16, byte_order=1, signed=False,
        factor=0.01, offset=0.0, minimum=0.0, maximum=100.0, unit="%"
    )
    msg = DBCMessage(id=100, name="TestMsg", dlc=2, sender="ECU", signals=[sig])
    dbc_messages = DBCDatabase()
    dbc_messages[(100, False)] = msg
    
    # Suppose raw value is 10000 -> physical = 100.0 (exact max)
    f_exact = CANFrame(1.0, 1, 100, "Rx", "d", 2, bytes.fromhex("1027"))  # 0x2710 = 10000
    status, _ = detect_range_anomalies(f_exact, dbc_messages)
    assert status == 'VALID'
    
    sig_tol = DBCSignal(
        name="TolSig", start_bit=0, length=64, byte_order=1, signed=False,
        factor=1e-10, offset=0.0, minimum=0.0, maximum=1.0, unit=""
    )
    msg_tol = DBCMessage(id=101, name="TolMsg", dlc=8, sender="ECU", signals=[sig_tol])
    dbc_messages_tol = DBCDatabase()
    dbc_messages_tol[(101, False)] = msg_tol
    
    # 1.0000000001 (VALID)
    # Raw = 10000000001 = 0x2540BE3FFF
    # Payload bytes: FF E3 0B 54 02 00 00 00
    f_valid = CANFrame(1.0, 1, 101, "Rx", "d", 8, bytes.fromhex("FFE30B5402000000"))
    status, _ = detect_range_anomalies(f_valid, dbc_messages_tol)
    assert status == 'VALID'
    
    # 1.0000001000 (RANGE_ANOMALY)
    # Raw = 10000000100 = 0x2540BE464
    # Payload bytes: 64 E4 0B 54 02 00 00 00
    f_invalid = CANFrame(1.0, 1, 101, "Rx", "d", 8, bytes.fromhex("64E40B5402000000"))
    status, _ = detect_range_anomalies(f_invalid, dbc_messages_tol)
    assert status == 'RANGE_ANOMALY'

def test_multiplexed_signals():
    # Setup multiplexed message
    # MuxVal at bit 0, len 8 (is multiplexer)
    # Sig0 at bit 8, len 8 (multiplexed for MuxVal=0)
    # Sig1 at bit 8, len 8 (multiplexed for MuxVal=1)
    # NormalSig at bit 16, len 8 (always active)
    
    sig_mux_val = DBCSignal("MuxVal", 0, 8, 1, False, 1.0, 0.0, 0.0, 255.0, "", is_multiplexer=True)
    sig_0 = DBCSignal("Sig0", 8, 8, 1, False, 1.0, 0.0, 0.0, 50.0, "", multiplexer_value=0)
    sig_1 = DBCSignal("Sig1", 8, 8, 1, False, 1.0, 0.0, 0.0, 100.0, "", multiplexer_value=1)
    sig_norm = DBCSignal("NormalSig", 16, 8, 1, False, 1.0, 0.0, 0.0, 20.0, "")
    
    msg = DBCMessage(300, "MuxMsg", 3, "ECU", [sig_mux_val, sig_0, sig_1, sig_norm])
    dbc_messages = DBCDatabase()
    dbc_messages[(300, False)] = msg
    
    # Payload: 00 64 0A -> MuxVal = 0, Sig0 = 100, NormalSig = 10
    # Sig0 range is [0, 50]. So Sig0 is anomalous (100 > 50).
    # Sig1 is not applicable (since MuxVal is 0). It should NOT be decoded/checked.
    # NormalSig = 10 (range [0, 20]) -> valid.
    f_mux0 = CANFrame(1.0, 1, 300, "Rx", "d", 3, bytes([0, 100, 10]))
    status, details = detect_range_anomalies(f_mux0, dbc_messages)
    assert status == 'RANGE_ANOMALY'
    
    # Check that details contains Sig0 anomaly and NormalSig decoded, but NOT Sig1!
    sig_names = [d.signal.name if hasattr(d, 'signal') else (d.signal_name if hasattr(d, 'signal_name') else d) for d in details]
    assert "Sig0" in sig_names
    assert "NormalSig" in sig_names
    assert "Sig1" not in sig_names
    
    # Verify Sig0 is reported as anomaly
    sig0_anomaly = [d for d in details if (hasattr(d, 'signal') and d.signal.name == "Sig0") or (hasattr(d, 'signal_name') and d.signal_name == "Sig0")][0]
    assert isinstance(sig0_anomaly, RangeAnomaly)
    
    # Payload: 01 64 0A -> MuxVal = 1, Sig1 = 100, NormalSig = 10
    # Sig1 range is [0, 100]. So Sig1 is valid (100 == 100).
    # Sig0 is not applicable.
    # NormalSig = 10 -> valid.
    # Total should be VALID.
    f_mux1 = CANFrame(1.0, 1, 300, "Rx", "d", 3, bytes([1, 100, 10]))
    status, details = detect_range_anomalies(f_mux1, dbc_messages)
    assert status == 'VALID'
    
    sig_names_mux1 = [d.signal.name for d in details if isinstance(d, DecodedSignal)]
    assert "Sig1" in sig_names_mux1
    assert "NormalSig" in sig_names_mux1
    assert "Sig0" not in sig_names_mux1

def test_unknown_and_missing_range():
    # Unknown message
    msg = DBCMessage(100, "TestMsg", 1, "ECU", [])
    dbc_messages = DBCDatabase()
    dbc_messages[(100, False)] = msg
    f_unknown = CANFrame(1.0, 1, 200, "Rx", "d", 1, bytes([0]))
    status, details = detect_range_anomalies(f_unknown, dbc_messages)
    assert status == 'UNKNOWN_MESSAGE'
    
    # Message with no ranges on signal
    sig_no_range = DBCSignal("NoRangeSig", 0, 8, 1, False, 1.0, 0.0, None, None, "")
    msg_no_range = DBCMessage(102, "NoRangeMsg", 1, "ECU", [sig_no_range])
    dbc_messages_nr = DBCDatabase()
    dbc_messages_nr[(102, False)] = msg_no_range
    
    f_nr = CANFrame(1.0, 1, 102, "Rx", "d", 1, bytes([100]))
    status, details = detect_range_anomalies(f_nr, dbc_messages_nr)
    assert status == 'NOT_CHECKED'
    assert len(details) == 1
    assert isinstance(details[0], DecodedSignal)
    assert details[0].physical_value == 100.0

def test_distinct_standard_extended():
    # Setup database with same CAN ID but standard and extended distinct messages
    sig_std = DBCSignal("StdSig", 0, 8, 1, False, 1.0, 0.0, 0.0, 50.0, "")
    msg_std = DBCMessage(256, "StandardMsg", 1, "ECU", [sig_std], is_extended=False)
    
    sig_ext = DBCSignal("ExtSig", 0, 8, 1, False, 1.0, 0.0, 0.0, 100.0, "")
    msg_ext = DBCMessage(256, "ExtendedMsg", 1, "ECU", [sig_ext], is_extended=True)
    
    # Store both in a DBCDatabase
    dbc_messages = DBCDatabase()
    dbc_messages[(256, False)] = msg_std
    dbc_messages[(256, True)] = msg_ext
    
    # Check standard frame
    f_std = CANFrame(1.0, 1, 256, "Rx", "d", 1, bytes([75]), is_extended=False)
    status_std, details_std = detect_range_anomalies(f_std, dbc_messages)
    # Should decode against StdSig (max 50). 75 > 50 -> RANGE_ANOMALY
    assert status_std == 'RANGE_ANOMALY'
    assert details_std[0].message_name == "StandardMsg"
    assert details_std[0].signal_name == "StdSig"
    assert details_std[0].is_extended is False
    
    # Check extended frame
    f_ext = CANFrame(1.0, 1, 256, "Rx", "d", 1, bytes([75]), is_extended=True)
    status_ext, details_ext = detect_range_anomalies(f_ext, dbc_messages)
    # Should decode against ExtSig (max 100). 75 <= 100 -> VALID
    assert status_ext == 'VALID'
    assert details_ext[0].signal.name == "ExtSig"

def test_decoding_error_and_anomaly_coexistence():
    # Message with 2 signals
    # Sig1 (Engine_RPM): 0|16, range [0, 8000]
    # Sig2 (Coolant_Temp): 16|8, but DLC of message is 2 bytes (so Sig2 starts beyond the payload!)
    sig_1 = DBCSignal("Engine_RPM", 0, 16, 1, False, 0.25, 0.0, 0.0, 8000.0, "RPM")
    sig_2 = DBCSignal("Coolant_Temp", 16, 8, 1, False, 1.0, -40.0, -40.0, 215.0, "degC")
    msg = DBCMessage(201, "EngineData", 2, "ECU", [sig_1, sig_2])
    
    dbc_messages = DBCDatabase()
    dbc_messages[(201, False)] = msg
    
    # Payload is 2 bytes (matching DLC 2), which is enough for Sig1 but NOT for Sig2!
    # Engine_RPM raw = 0xFFFF -> physical = 16383.75 (Anomaly!)
    # Coolant_Temp extraction will raise ValueError (payload too short) -> DECODING_ERROR
    frame = CANFrame(1.0, 1, 201, "Rx", "d", 2, bytes.fromhex("FFFF"))
    
    status, details = detect_range_anomalies(frame, dbc_messages)
    
    # Status should be DECODING_ERROR because one signal failed to decode
    assert status == 'DECODING_ERROR'
    
    # But details must contain the RangeAnomaly for Engine_RPM!
    anomalies = [d for d in details if isinstance(d, RangeAnomaly)]
    assert len(anomalies) == 1
    assert anomalies[0].signal_name == "Engine_RPM"
    assert anomalies[0].physical_value == 16383.75
    
    # And details must also contain the decoding error message for Coolant_Temp
    errors = [d for d in details if isinstance(d, str) and "DECODING_ERROR" in d]
    assert len(errors) == 1
    assert "Coolant_Temp" in errors[0]

