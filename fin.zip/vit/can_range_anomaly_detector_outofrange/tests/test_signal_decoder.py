import pytest
from signal_decoder import extract_signal, to_signed, decode_signal
from models import DBCSignal

def test_to_signed():
    # Unsigned/signed representation mapping
    assert to_signed(0, 8) == 0
    assert to_signed(127, 8) == 127
    assert to_signed(128, 8) == -128
    assert to_signed(255, 8) == -1
    
    assert to_signed(2047, 12) == 2047
    assert to_signed(2048, 12) == -2048
    assert to_signed(4095, 12) == -1
    
    assert to_signed(65535, 16) == -1
    assert to_signed(32767, 16) == 32767
    assert to_signed(32768, 16) == -32768

def test_extract_intel_unsigned():
    # Intel unsigned, byte-aligned (Engine_RPM equivalent starting at bit 0, len 16)
    # Payload: FF FF 00 00 AA BB CC DD
    payload = bytes.fromhex("FFFF0000AABBCCDD")
    raw = extract_signal(payload, start_bit=0, length=16, byte_order=1, signed=False)
    assert raw == 65535

    # Intel unsigned, non-byte-aligned, single bit (Engine_Status equivalent at bit 24, len 1)
    # Byte 3 is 0x33 = 00110011 binary. Bit 24 is bit 0 of byte 3. So it should be 1.
    payload = bytes.fromhex("1000283300000000")
    raw = extract_signal(payload, start_bit=24, length=1, byte_order=1, signed=False)
    assert raw == 1
    
    # Intel unsigned, spanning multiple bytes, non-byte-aligned
    # Start bit 9, length 12
    # Payload: 00 FF 00 ...
    # Byte 1 = 0xFF, Byte 2 = 0x00.
    # In little-endian, bytes are: B0=00, B1=FF, B2=00...
    # Int value = 0xFF00 = 65280.
    # Bits 9..20 of this integer:
    # 0xFF00 >> 9 = 0x7F = 127.
    payload = bytes.fromhex("00FF000000000000")
    raw = extract_signal(payload, start_bit=9, length=12, byte_order=1, signed=False)
    assert raw == 127

def test_extract_intel_signed():
    # Intel signed, 8-bit, byte-aligned
    # Payload: 80 00 00 ... -> B0 = 0x80 = 128 (unsigned) or -128 (signed)
    payload = bytes.fromhex("8000000000000000")
    raw = extract_signal(payload, start_bit=0, length=8, byte_order=1, signed=True)
    assert raw == -128
    
    # Intel signed, 12-bit, cross-byte
    # Start bit 4, length 12
    # Payload: F0 0F 00 ...
    # B0 = 0xF0, B1 = 0x0F.
    # Int value = 0x0FF0.
    # 0x0FF0 >> 4 = 0x0FF = 255.
    # Since length is 12, max value is 4095, sign bit is bit 11 (which is 0 in 255).
    # So it should be 255.
    payload = bytes.fromhex("F00F000000000000")
    raw = extract_signal(payload, start_bit=4, length=12, byte_order=1, signed=True)
    assert raw == 255
    
    # If B1 was 0xFF, Int value = 0xFFF0.
    # 0xFFF0 >> 4 = 0xFFF = 4095.
    # Since length is 12, signed 4095 should be -1.
    payload = bytes.fromhex("F0FF000000000000")
    raw = extract_signal(payload, start_bit=4, length=12, byte_order=1, signed=True)
    assert raw == -1

def test_extract_motorola_unsigned():
    # Motorola unsigned, byte-aligned
    # Start bit 15, length 8. (Byte 1)
    # Payload: 00 AA 00 ...
    payload = bytes.fromhex("00AA000000000000")
    raw = extract_signal(payload, start_bit=15, length=8, byte_order=0, signed=False)
    assert raw == 0xAA
    
    # Motorola unsigned, non-byte-aligned, cross-byte
    # Start bit 12, length 8.
    # This reads 5 bits from Byte 1 (bits 4..0) and 3 bits from Byte 2 (bits 7..5).
    # Payload: 00 1F E0 00 ...
    # Byte 1 = 0x1F = 00011111 (bits 4..0 are all 1)
    # Byte 2 = 0xE0 = 11100000 (bits 7..5 are all 1)
    # So we should extract 8 bits of 1 -> 255.
    payload = bytes.fromhex("001FE00000000000")
    raw = extract_signal(payload, start_bit=12, length=8, byte_order=0, signed=False)
    assert raw == 255

def test_extract_motorola_signed():
    # Motorola signed, 12-bit, cross-byte (sawtooth check)
    # Start bit 15 (MSB of Byte 1), length 12.
    # Reads Byte 1 (bits 7..0) and top 4 bits of Byte 2 (bits 7..4).
    # Payload: 00 FF F0 00 ...
    # Byte 1 = 0xFF, Byte 2 = 0xF0.
    # Extracted bits: 8 bits of 1, then 4 bits of 1 -> 12 bits of 1 -> 4095 raw.
    # 12-bit signed 4095 is -1.
    payload = bytes.fromhex("00FFF00000000000")
    raw = extract_signal(payload, start_bit=15, length=12, byte_order=0, signed=True)
    assert raw == -1

def test_payload_length_validation():
    # Payload is 4 bytes, try to extract Intel signal at bit 24, length 16 (needs up to bit 39, which requires 5 bytes)
    payload = bytes([0, 1, 2, 3])
    with pytest.raises(ValueError) as excinfo:
        extract_signal(payload, start_bit=24, length=16, byte_order=1, signed=False)
    assert "Payload too short" in str(excinfo.value)
    
    # Try to extract Motorola signal spanning beyond payload
    # Payload is 2 bytes (indices 0, 1). Start bit 12, length 8. Needs Byte 1 and Byte 2.
    # Max index accessed is Byte 2. Since payload has length 2, this is out-of-bounds.
    payload = bytes([0, 1])
    with pytest.raises(ValueError) as excinfo:
        extract_signal(payload, start_bit=12, length=8, byte_order=0, signed=False)
    assert "Payload too short" in str(excinfo.value)

def test_decode_signal():
    sig = DBCSignal(
        name="TestSig", start_bit=0, length=8, byte_order=1, signed=False,
        factor=0.25, offset=-10.0, minimum=0.0, maximum=100.0, unit="V"
    )
    payload = bytes([40])  # raw value 40
    # physical value = 40 * 0.25 - 10.0 = 0.0
    decoded = decode_signal(payload, sig)
    assert decoded.raw_value == 40
    assert decoded.physical_value == 0.0
