import pytest
from dbc_parser import parse_dbc_file

def test_parse_dbc(tmp_path):
    # Setup temporary DBC file
    dbc_content = """VERSION "1.0"
NS_ :
BS_:
BU_: Engine_ECU ABS_ECU

BO_ 201 EngineData: 8 Engine_ECU
 SG_ Engine_RPM : 0|16@1+ (0.25,0) [0|8000] "RPM" ABS_ECU
 SG_ Coolant_Temp : 16|8@1- (1,-40) [-40|215] "degC" Vector__XXX

BO_ 2147483904 ExtendedMessage: 8 Engine_ECU
 SG_ ExtendedSignal : 0|8@1+ (1,0) [ ] "" Vector__XXX

BO_ 300 MuxMessage: 8 Engine_ECU
 SG_ MuxVal M : 0|8@1+ (1,0) [0|255] "" Vector__XXX
 SG_ MuxSig1 m0 : 8|8@1+ (1,0) [0|100] "" Vector__XXX
 SG_ MuxSig2 m1 : 8|8@1+ (1,0) [0|100] "" Vector__XXX
"""
    dbc_file = tmp_path / "test.dbc"
    dbc_file.write_text(dbc_content, encoding="utf-8")
    
    # Parse
    messages = parse_dbc_file(str(dbc_file))
    
    # Validate EngineData
    assert (201, False) in messages
    msg = messages[(201, False)]
    assert msg.name == "EngineData"
    assert msg.dlc == 8
    assert msg.sender == "Engine_ECU"
    assert len(msg.signals) == 2
    
    # Validate Engine_RPM
    sig1 = [s for s in msg.signals if s.name == "Engine_RPM"][0]
    assert sig1.start_bit == 0
    assert sig1.length == 16
    assert sig1.byte_order == 1
    assert sig1.signed is False
    assert sig1.factor == 0.25
    assert sig1.offset == 0.0
    assert sig1.minimum == 0.0
    assert sig1.maximum == 8000.0
    assert sig1.unit == "RPM"
    assert "ABS_ECU" in sig1.receivers
    assert sig1.is_multiplexer is False
    assert sig1.multiplexer_value is None
    
    # Validate Coolant_Temp (signed, offset -40)
    sig2 = [s for s in msg.signals if s.name == "Coolant_Temp"][0]
    assert sig2.start_bit == 16
    assert sig2.length == 8
    assert sig2.byte_order == 1
    assert sig2.signed is True
    assert sig2.factor == 1.0
    assert sig2.offset == -40.0
    assert sig2.minimum == -40.0
    assert sig2.maximum == 215.0
    assert sig2.unit == "degC"
    
    # Validate Extended ID normalization:
    # 2147483904 = 0x80000100
    # Cleared 31st bit should yield 256 (0x100)
    assert (256, True) in messages
    msg_ext = messages[(256, True)]
    assert msg_ext.name == "ExtendedMessage"
    assert len(msg_ext.signals) == 1
    sig_ext = msg_ext.signals[0]
    assert sig_ext.name == "ExtendedSignal"
    assert sig_ext.minimum is None
    assert sig_ext.maximum is None
    assert sig_ext.has_usable_range is False
    
    # Validate Multiplexed message
    assert (300, False) in messages
    msg_mux = messages[(300, False)]
    assert len(msg_mux.signals) == 3
    
    sig_mux_val = [s for s in msg_mux.signals if s.name == "MuxVal"][0]
    assert sig_mux_val.is_multiplexer is True
    assert sig_mux_val.multiplexer_value is None
    
    sig_mux1 = [s for s in msg_mux.signals if s.name == "MuxSig1"][0]
    assert sig_mux1.is_multiplexer is False
    assert sig_mux1.multiplexer_value == 0
    
    sig_mux2 = [s for s in msg_mux.signals if s.name == "MuxSig2"][0]
    assert sig_mux2.is_multiplexer is False
    assert sig_mux2.multiplexer_value == 1

def test_parse_dbc_collision(tmp_path):
    dbc_content = """VERSION "1.0"
BS_:
BU_: ECU

BO_ 256 StandardMsg: 8 ECU
 SG_ Sig1 : 0|8@1+ (1,0) [0|100] "" ECU

BO_ 2147483904 ExtendedMsg: 8 ECU
 SG_ Sig2 : 0|8@1+ (1,0) [0|100] "" ECU
"""
    dbc_file = tmp_path / "collision.dbc"
    dbc_file.write_text(dbc_content, encoding="utf-8")
    
    messages = parse_dbc_file(str(dbc_file))
    
    # Both should be present since one is standard and the other is extended
    assert (256, False) in messages
    assert (256, True) in messages
    assert messages[(256, False)].name == "StandardMsg"
    assert messages[(256, True)].name == "ExtendedMsg"

def test_database_legacy_deprecation_and_ambiguity():
    from models import DBCDatabase, DBCMessage
    import pytest
    import warnings
    
    db = DBCDatabase()
    msg_std = DBCMessage(100, "StandardMsg", 1, "ECU")
    msg_ext = DBCMessage(100, "ExtendedMsg", 1, "ECU", is_extended=True)
    
    # 1. Test single entry deprecation warning and correctness
    db[(100, False)] = msg_std
    
    # Check that contains for plain integer raises a DeprecationWarning but returns True
    with pytest.deprecated_call():
        assert 100 in db
        
    # Check that contains for tuple does NOT raise a warning
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        assert (100, False) in db
        
    # Check that getitem for plain integer raises a DeprecationWarning but returns the message
    with pytest.deprecated_call():
        assert db[100] is msg_std
        
    # Check that getitem for tuple does NOT raise a warning
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        assert db[(100, False)] is msg_std
        
    # 2. Test ambiguous case (both standard and extended exist)
    db[(100, True)] = msg_ext
    
    # Check that contains returns False for plain integer because it is ambiguous
    with pytest.deprecated_call():
        assert 100 not in db
        
    # Check that getitem raises a KeyError due to ambiguity
    with pytest.deprecated_call():
        with pytest.raises(KeyError) as exc_info:
            _ = db[100]
        assert "ambiguous" in str(exc_info.value)


