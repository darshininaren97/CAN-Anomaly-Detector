# Tests package init
