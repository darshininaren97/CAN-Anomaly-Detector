import os
from dbc_parser import parse_dbc_file
from can_log_parser import parse_asc_log
from range_detector import detect_range_anomalies
from models import RangeAnomaly

def test_integration_engine_rpm_anomaly():
    # Paths to files in project directory
    project_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    dbc_path = os.path.join(project_dir, "sample.dbc")
    log_path = os.path.join(project_dir, "vehicle_drive_session.log")
    
    # Assert files exist
    assert os.path.exists(dbc_path), f"DBC file missing at {dbc_path}"
    assert os.path.exists(log_path), f"Log file missing at {log_path}"
    
    # Parse DBC
    dbc_messages = parse_dbc_file(dbc_path)
    assert len(dbc_messages) > 0
    
    # Process log
    anomalies = []
    total_frames = 0
    decoding_errors = 0
    unknown_messages = 0
    
    for item in parse_asc_log(log_path):
        if isinstance(item, tuple) and item[0] == "error":
            decoding_errors += 1
            continue
            
        frame = item
        total_frames += 1
        
        status, details = detect_range_anomalies(frame, dbc_messages)
        
        if status == 'RANGE_ANOMALY':
            for det in details:
                if isinstance(det, RangeAnomaly):
                    anomalies.append(det)
        elif status == 'DECODING_ERROR':
            decoding_errors += 1
        elif status == 'UNKNOWN_MESSAGE':
            unknown_messages += 1

    # 1. Verify Engine_RPM range anomaly is detected at t=4.023105
    rpm_anomalies = [a for a in anomalies if a.signal_name == "Engine_RPM"]
    assert len(rpm_anomalies) == 2, f"Expected exactly 2 Engine_RPM anomalies, got {len(rpm_anomalies)}"
    
    anomaly = [a for a in rpm_anomalies if abs(a.timestamp - 4.023105) < 1e-5][0]
    assert anomaly.can_id == 201, f"Expected CAN ID 201 (0x0C9), got {anomaly.can_id}"
    assert anomaly.message_name == "EngineData", f"Expected message EngineData, got {anomaly.message_name}"
    assert anomaly.raw_value == 65535, f"Expected raw value 65535, got {anomaly.raw_value}"
    assert anomaly.physical_value == 16383.75, f"Expected physical value 16383.75, got {anomaly.physical_value}"
    assert anomaly.minimum == 0.0
    assert anomaly.maximum == 8000.0
    assert anomaly.unit == "RPM"
    assert anomaly.factor == 0.25
    assert anomaly.offset == 0.0
    assert anomaly.reason == "Value exceeds maximum"

    # 2. Verify that other anomalies are NOT reported as range anomalies
    # Flood at t=2.010-2.110 (VehicleSpeed frames 0x1A0 have normal in-range speed)
    # The vehicle speed in those frames is 0x2EE0 = 12000 -> physical = 120 km/h (max is 300) -> valid range!
    # Contradiction at t=4.023000 (Speed=120, Engine=OFF, Gear=PARK) -> values are in range, so NOT range anomalies.
    # Silent timeout for 0x1B0 at t=8.0-18.0 -> not a range anomaly.
    # Malformed data (0xFF stuck high at 6.5, 0x00 stuck low at 6.6)
    # Let's inspect anomalies around those timestamps:
    # At t=6.5: EngineData (0C9) with payload FF FF FF FF FF FF FF FF.
    #   Engine_RPM = 0xFFFF = 65535 -> 16383.75 (Anomaly!)
    #   Coolant_Temp = 0xFF = 255 -> 255 - 40 = 215 (Max is 215) -> Valid!
    #   Engine_Status = 1 (Max 1) -> Valid!
    #   Throttle_Pos = 0xFF = 255 -> 255 * 0.392156 = 100.0 (Max 100) -> Valid!
    #   Engine_Load = 0xFF = 255 -> 255 * 0.392156 = 100.0 (Max 100) -> Valid!
    # So this frame does contain an Engine_RPM anomaly because of the 0xFFFF!
    #
    # At t=6.6: VehicleSpeed (1A0) with payload 00 00 00 00 00 00 00 00.
    #   Vehicle_Speed = 0 (range [0,300]) -> Valid
    #   Brake_Status = 0 (range [0,1]) -> Valid
    #   All speeds are 0 -> Valid.
    # No range anomaly here!
    #
    # At t=6.7: EngineData (0C9) with DLC=0.
    #   Should be reported as DECODING_ERROR because payload is 0 bytes (smaller than DLC 8).
    #   It must NOT be classified as range anomaly.
    
    # Let's assert that the ONLY range anomalies are for Engine_RPM at t=4.023105 and possibly t=6.5
    # (since the t=6.5 stuck-high frame indeed translates to an out-of-range RPM of 16383.75, which is a real range anomaly!).
    # Let's verify:
    # Indeed, at t=6.5, EngineData is FF FF FF FF FF FF FF FF.
    # So Engine_RPM is 0xFFFF = 65535 -> 16383.75 RPM, which is out of range (>8000).
    # This is a legitimate DBC-defined range anomaly triggered by the data corruption, and should be detected!
    # Let's check how many total anomalies were detected.
    assert len(anomalies) >= 1
    
    # Check that the anomaly at 4.023105 is present.
    # Let's check that 6.700000 is reported as a decoding error, and NOT as a range anomaly.
    # Let's verify that there is a decoding error for DLC=0.
    assert decoding_errors >= 1
