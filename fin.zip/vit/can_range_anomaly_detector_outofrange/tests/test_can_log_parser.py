import pytest
from can_log_parser import parse_asc_log, parse_can_id
from models import CANFrame

def test_parse_can_id():
    # Hex prefix
    assert parse_can_id("0x1A0", base_is_hex=False) == 416
    assert parse_can_id("0X1A0", base_is_hex=False) == 416
    
    # Hex base, no prefix
    assert parse_can_id("1A0", base_is_hex=True) == 416
    assert parse_can_id("0C9", base_is_hex=True) == 201
    
    # Decimal base, no prefix
    assert parse_can_id("201", base_is_hex=False) == 201
    
    # Fallback to hex if dec fails but looks like hex
    assert parse_can_id("1A0", base_is_hex=False) == 416

def test_parse_asc_log(tmp_path):
    log_content = """begin asc log
date Thu Apr 15 00:00:00 2025
base hex timestamps absolute
internal events logged
// A comment line
   0.100000 1  0C9  Rx  d 8  20 00 30 50 01 40 00 00
   0.200000 1  1A0  Rx  d 8  A0 0F 00 00 00 00 00 00
   
   0.300000 1  200  Rx  d 4  5C 00 00 00
// Another comment
   6.700000 1  0C9  Rx  d 0
   6.800000 1  0C9  Rx  d 2  ZZ FF
end asc log
"""
    log_file = tmp_path / "test.log"
    log_file.write_text(log_content, encoding="utf-8")
    
    frames = list(parse_asc_log(str(log_file)))
    
    # We should have:
    # 1. CANFrame at 0.100000
    # 2. CANFrame at 0.200000
    # 3. CANFrame at 0.300000
    # 4. CANFrame at 6.700000
    # 5. Error at 6.800000 (invalid hex byte ZZ)
    
    assert len(frames) == 5
    
    # Check 0.1
    f1 = frames[0]
    assert isinstance(f1, CANFrame)
    assert f1.timestamp == 0.100000
    assert f1.channel == 1
    assert f1.can_id == 201  # 0x0C9
    assert f1.direction == "Rx"
    assert f1.dlc == 8
    assert f1.payload == bytes.fromhex("2000305001400000")
    
    # Check 0.3
    f3 = frames[2]
    assert isinstance(f3, CANFrame)
    assert f3.timestamp == 0.300000
    assert f3.dlc == 4
    assert f3.payload == bytes.fromhex("5C000000")
    
    # Check 6.7
    f4 = frames[3]
    assert isinstance(f4, CANFrame)
    assert f4.timestamp == 6.700000
    assert f4.dlc == 0
    assert f4.payload == b""
    
    # Check 6.8 (error)
    err = frames[4]
    assert isinstance(err, tuple)
    assert err[0] == "error"
    assert "Invalid hex byte 'ZZ'" in err[1]

def test_parse_asc_log_extended_and_mismatch(tmp_path):
    log_content = """begin asc log
base hex
   1.000000 1  18FEF123x Rx  d 8  11 22 33 44 55 66 77 88
   2.000000 1  0C9  Rx  d 8  00 11 22
end asc log
"""
    log_file = tmp_path / "extended.log"
    log_file.write_text(log_content, encoding="utf-8")
    
    items = list(parse_asc_log(str(log_file)))
    
    assert len(items) == 3
    
    # 1st item: extended CANFrame
    f1 = items[0]
    assert isinstance(f1, CANFrame)
    assert f1.timestamp == 1.0
    assert f1.can_id == 0x18FEF123
    assert f1.is_extended is True
    assert f1.dlc == 8
    assert len(f1.payload) == 8
    
    # 2nd item: Warning tuple
    w2 = items[1]
    assert isinstance(w2, tuple)
    assert w2[0] == "warning"
    assert "DLC (8) does not match actual payload length" in w2[1]
    
    # 3rd item: CANFrame with mismatched payload still returned
    f2 = items[2]
    assert isinstance(f2, CANFrame)
    assert f2.timestamp == 2.0
    assert f2.can_id == 0x0C9
    assert f2.is_extended is False
    assert f2.dlc == 8
    assert len(f2.payload) == 3

