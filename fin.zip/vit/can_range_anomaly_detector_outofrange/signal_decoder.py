from models import DBCSignal, DecodedSignal

def to_signed(val: int, length: int) -> int:
    """Interpret an unsigned integer as a signed two's-complement integer."""
    if length <= 0:
        return val
    if val >= (1 << (length - 1)):
        return val - (1 << length)
    return val

def extract_signal(payload: bytes, start_bit: int, length: int, byte_order: int, signed: bool) -> int:
    """
    Extract a raw integer from a CAN payload according to DBC bit-ordering conventions.
    
    Parameters:
      payload: bytes buffer of the CAN frame.
      start_bit: Start bit index in standard DBC numbering (0 to 63+).
      length: Length of the signal in bits.
      byte_order: 1 for Intel (little-endian), 0 for Motorola (big-endian).
      signed: True if signed, False if unsigned.
    
    Returns:
      The extracted raw integer (signed or unsigned).
      
    Raises:
      ValueError if the payload is too short to extract the signal.
    """
    if length <= 0:
        raise ValueError(f"Signal length must be positive, got {length}")

    if byte_order == 1:
        # Intel / Little-Endian
        # DBC StartBit is the LSB of the signal.
        # The bits are numbered sequentially: bit_index = byte_index * 8 + bit_in_byte.
        max_byte_idx = (start_bit + length - 1) // 8
        if max_byte_idx >= len(payload):
            raise ValueError(
                f"Payload too short ({len(payload)} bytes) to extract Intel signal at bit {start_bit} with length {length}"
            )
        
        # Build integer from payload bytes
        frame_val = 0
        for i, b in enumerate(payload):
            frame_val |= b << (8 * i)
            
        raw_val = (frame_val >> start_bit) & ((1 << length) - 1)
        
    else:
        # Motorola / Big-Endian (Sawtooth pattern)
        # DBC StartBit is the MSB of the signal.
        # Bits are read from start_bit decreasing within the byte, then wrapping to bit 7 of the next byte.
        bit_list = []
        curr_byte = start_bit // 8
        curr_bit = start_bit % 8
        
        for i in range(length):
            if curr_byte >= len(payload):
                raise ValueError(
                    f"Payload too short ({len(payload)} bytes) to extract Motorola signal at bit {start_bit} with length {length} (failed at bit index {i})"
                )
            
            # Extract current bit
            bit = (payload[curr_byte] >> curr_bit) & 1
            bit_list.append(bit)
            
            # Move to next less-significant bit
            if curr_bit > 0:
                curr_bit -= 1
            else:
                curr_byte += 1
                curr_bit = 7
                
        # Reconstruct integer (first bit read is MSB, last read is LSB)
        raw_val = 0
        for bit in bit_list:
            raw_val = (raw_val << 1) | bit

    if signed:
        raw_val = to_signed(raw_val, length)
        
    return raw_val

def decode_signal(payload: bytes, signal: DBCSignal) -> DecodedSignal:
    """Extract and scale a signal from the CAN payload."""
    raw_val = extract_signal(payload, signal.start_bit, signal.length, signal.byte_order, signal.signed)
    physical_val = raw_val * signal.factor + signal.offset
    return DecodedSignal(signal=signal, raw_value=raw_val, physical_value=physical_val)
