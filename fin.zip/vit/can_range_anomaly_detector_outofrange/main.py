import argparse
import os
import sys
from dbc_parser import parse_dbc_file
from can_log_parser import parse_asc_log
from range_detector import detect_range_anomalies
from models import RangeAnomaly, DecodedSignal
import reporter

def main():
    parser = argparse.ArgumentParser(
        description="Deterministic CAN Bus DBC Range Anomaly Detector.",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument("--dbc", required=True, help="Path to the input DBC database file.")
    parser.add_argument("--log", required=True, help="Path to the input Vector ASC CAN log file.")
    parser.add_argument("--output", help="Optional path to write the formatted report.")
    parser.add_argument(
        "--format",
        choices=["text", "json", "csv"],
        default="text",
        help="Format of the output report file (default: text)."
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Print verbose processing logs (including valid and unknown frames)."
    )
    args = parser.parse_args()

    # Validate files existence
    if not os.path.exists(args.dbc):
        print(f"Error: DBC file not found at '{args.dbc}'", file=sys.stderr)
        sys.exit(1)

    if not os.path.exists(args.log):
        print(f"Error: Log file not found at '{args.log}'", file=sys.stderr)
        sys.exit(1)

    print(f"Parsing DBC file: {args.dbc}")
    try:
        dbc_messages = parse_dbc_file(args.dbc)
        print(f"Successfully loaded {len(dbc_messages)} messages from DBC.")
    except Exception as e:
        print(f"Error parsing DBC file: {str(e)}", file=sys.stderr)
        sys.exit(1)

    print(f"Processing log file: {args.log}\n")

    anomalies = []

    # Counters — separated so the summary reconciles correctly.
    # total_frames counts only successfully parsed CANFrame objects.
    # malformed_line_count counts lines that couldn't be parsed into frames at all.
    # decoding_error_count counts frames that parsed but couldn't be decoded/validated.
    valid_count = 0
    anomaly_count = 0
    decoding_error_count = 0
    unknown_count = 0
    not_checked_count = 0
    total_frames = 0
    malformed_line_count = 0
    warning_count = 0

    # Process the ASC log file in a streaming fashion
    for item in parse_asc_log(args.log):
        if isinstance(item, tuple):
            level, message = item
            if level == "error":
                malformed_line_count += 1
                print(f"PARSING ERROR: {message}", file=sys.stderr)
            elif level == "warning":
                warning_count += 1
                if args.verbose:
                    print(f"WARNING: {message}", file=sys.stderr)
            continue

        # We have a valid CANFrame
        frame = item
        total_frames += 1

        status, details = detect_range_anomalies(frame, dbc_messages)

        if status == 'UNKNOWN_MESSAGE':
            unknown_count += 1
            if args.verbose:
                print(f"[{frame.timestamp:.6f}] UNKNOWN_MESSAGE: CAN ID {hex(frame.can_id)} ({frame.can_id}) not in DBC")

        elif status == 'DECODING_ERROR':
            decoding_error_count += 1
            print(f"[{frame.timestamp:.6f}] DECODING_ERROR on CAN ID {hex(frame.can_id)}:")
            for det in details:
                if isinstance(det, str):
                    print(f"  {det}", file=sys.stderr)
                elif isinstance(det, RangeAnomaly):
                    # Anomalies found alongside a decoding error still get reported/exported,
                    # but the frame is counted only once, under decoding_error_count, so
                    # total_frames = valid + anomaly + decoding_error + unknown + not_checked
                    # still holds.
                    anomalies.append(det)
                    print(reporter.format_anomaly_text(det))

        elif status == 'RANGE_ANOMALY':
            anomaly_count += 1
            for det in details:
                if isinstance(det, RangeAnomaly):
                    anomalies.append(det)
                    # Print anomaly details to stdout immediately
                    print(reporter.format_anomaly_text(det))
                elif isinstance(det, str) and args.verbose:
                    print(f"  Info: {det}")

        elif status == 'VALID':
            valid_count += 1
            if args.verbose:
                key = (frame.can_id, frame.is_extended)
                msg_name = dbc_messages[key].name
                print(f"[{frame.timestamp:.6f}] VALID CAN ID {hex(frame.can_id)} ({msg_name}):")
                for det in details:
                    if isinstance(det, DecodedSignal):
                        print(f"  Signal '{det.signal.name}' = {reporter.clean_float(det.physical_value)} {det.signal.unit}")

        elif status == 'NOT_CHECKED':
            not_checked_count += 1
            if args.verbose:
                print(f"[{frame.timestamp:.6f}] NOT_CHECKED CAN ID {hex(frame.can_id)}")
                for det in details:
                    if isinstance(det, DecodedSignal):
                        print(f"  Signal '{det.signal.name}' = {reporter.clean_float(det.physical_value)} (No range defined)")
                    elif isinstance(det, str):
                        print(f"  Info: {det}")

    # Write report if path specified
    if args.output:
        print(f"\nWriting {args.format.upper()} report to: {args.output}")
        try:
            if args.format == "text":
                reporter.write_text_report(anomalies, args.output)
            elif args.format == "json":
                reporter.write_json_report(anomalies, args.output)
            elif args.format == "csv":
                reporter.write_csv_report(anomalies, args.output)
            print("Report written successfully.")
        except Exception as e:
            print(f"Error writing report file: {str(e)}", file=sys.stderr)

    # Print execution summary
    # total_frames = valid + anomaly + decoding_error + unknown + not_checked
    print("\n" + "=" * 40)
    print("DETECTION SUMMARY")
    print("=" * 40)
    print(f"Total Frames Processed:   {total_frames}")
    print(f"  Valid:                  {valid_count}")
    print(f"  Range Anomalies:        {anomaly_count}")
    print(f"  Decoding Errors:        {decoding_error_count}")
    print(f"  Unknown CAN Messages:   {unknown_count}")
    print(f"  Not Checked:            {not_checked_count}")
    if malformed_line_count > 0:
        print(f"Malformed Log Lines:      {malformed_line_count}")
    if warning_count > 0:
        print(f"Parser Warnings:          {warning_count}")
    print("=" * 40)

if __name__ == "__main__":
    main()
