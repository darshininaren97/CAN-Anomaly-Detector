import csv
import json
from typing import List, Union
from models import RangeAnomaly

def clean_float(val: Union[int, float]) -> str:
    """Format floats cleanly, removing trailing zeros and unnecessary decimal points."""
    if isinstance(val, int):
        return str(val)
    if val == int(val):
        return str(int(val))
    s = f"{val:.6f}"
    while s.endswith('0'):
        s = s[:-1]
    if s.endswith('.'):
        s = s[:-1]
    return s

def format_anomaly_text(anomaly: RangeAnomaly) -> str:
    """Format a single RangeAnomaly as a clean text block matching requirements."""
    width = 8 if anomaly.is_extended else 3
    can_id_hex = f"0x{anomaly.can_id:0{width}X}"
    range_str = f"{clean_float(anomaly.minimum)}-{clean_float(anomaly.maximum)}"
    
    return (
        f"RANGE ANOMALY\n"
        f"Timestamp:       {anomaly.timestamp:.6f}\n"
        f"CAN ID:          {can_id_hex}\n"
        f"Extended:        {'Yes' if anomaly.is_extended else 'No'}\n"
        f"Message:         {anomaly.message_name}\n"
        f"Signal:          {anomaly.signal_name}\n"
        f"Raw Value:       {anomaly.raw_value}\n"
        f"Physical Value:  {clean_float(anomaly.physical_value)}\n"
        f"Valid Range:     {range_str}\n"
        f"Unit:            {anomaly.unit}\n"
        f"Factor:          {clean_float(anomaly.factor)}\n"
        f"Offset:          {clean_float(anomaly.offset)}\n"
        f"Reason:          {anomaly.reason}\n"
    )

def write_text_report(anomalies: List[RangeAnomaly], filepath: str) -> None:
    """Write human-readable report to a file."""
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write("=== CAN RANGE ANOMALY DETECTOR REPORT ===\n\n")
        if not anomalies:
            f.write("No range anomalies detected.\n")
            return
            
        f.write(f"Total Range Anomalies Detected: {len(anomalies)}\n\n")
        for i, anomaly in enumerate(anomalies, 1):
            f.write(f"[{i}] ")
            f.write(format_anomaly_text(anomaly))
            f.write("\n" + "-"*50 + "\n\n")

def write_json_report(anomalies: List[RangeAnomaly], filepath: str) -> None:
    """Write anomalies as structured JSON data."""
    data = []
    for anomaly in anomalies:
        width = 8 if anomaly.is_extended else 3
        can_id_hex = f"0x{anomaly.can_id:0{width}X}"
        data.append({
            "timestamp": anomaly.timestamp,
            "can_id_hex": can_id_hex,
            "can_id_dec": anomaly.can_id,
            "is_extended": anomaly.is_extended,
            "message_name": anomaly.message_name,
            "signal_name": anomaly.signal_name,
            "raw_value": anomaly.raw_value,
            "physical_value": anomaly.physical_value,
            "minimum": anomaly.minimum,
            "maximum": anomaly.maximum,
            "unit": anomaly.unit,
            "factor": anomaly.factor,
            "offset": anomaly.offset,
            "reason": anomaly.reason
        })
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2)

def write_csv_report(anomalies: List[RangeAnomaly], filepath: str) -> None:
    """Write anomalies as structured CSV data."""
    fields = [
        "timestamp", "can_id_hex", "can_id_dec", "is_extended", "message_name", "signal_name",
        "raw_value", "physical_value", "minimum", "maximum", "unit",
        "factor", "offset", "reason"
    ]
    with open(filepath, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for anomaly in anomalies:
            width = 8 if anomaly.is_extended else 3
            can_id_hex = f"0x{anomaly.can_id:0{width}X}"
            writer.writerow({
                "timestamp": f"{anomaly.timestamp:.6f}",
                "can_id_hex": can_id_hex,
                "can_id_dec": anomaly.can_id,
                "is_extended": anomaly.is_extended,
                "message_name": anomaly.message_name,
                "signal_name": anomaly.signal_name,
                "raw_value": anomaly.raw_value,
                "physical_value": anomaly.physical_value,
                "minimum": anomaly.minimum,
                "maximum": anomaly.maximum,
                "unit": anomaly.unit,
                "factor": anomaly.factor,
                "offset": anomaly.offset,
                "reason": anomaly.reason
            })
