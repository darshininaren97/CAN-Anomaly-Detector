import re
import sys
from typing import Dict, List, Optional, Tuple
from models import DBCMessage, DBCSignal, DBCDatabase

# Regex to match BO_ line: BO_ <message_id> <message_name>: <dlc> <sender>
BO_REGEX = re.compile(r'^\s*BO_\s+(\d+)\s+(\w+)\s*:\s*(\d+)\s+(\w+)')

SG_REGEX = re.compile(
    r'^\s*SG_\s+(\w+)\s*(?:(M|m\d+))?\s*:\s*(\d+)\|(\d+)@([01])([+-])\s*\(([^,]+),([^)]+)\)(?:\s*\[\s*([^|\]]*?)\s*(?:\|\s*([^\]]*?))?\s*\])?\s*"([^"]*)"\s*(.*)'
)

def parse_dbc_file(file_path: str) -> DBCDatabase:
    """
    Parse a DBC file and return a DBCDatabase dictionary of (CAN ID, is_extended) -> DBCMessage.
    
    Extended CAN IDs (where raw ID >= 0x80000000) have bit 31 cleared to
    obtain the 29-bit identifier, and are stored with is_extended=True on
    the DBCMessage.
    """
    messages = DBCDatabase()
    # Auxiliary dict to check for exact duplicate messages (same numeric ID and same is_extended)
    _seen_messages: Dict[Tuple[int, bool], str] = {}
    current_message: Optional[DBCMessage] = None
    
    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line in f:
            stripped = line.strip()
            if not stripped:
                continue
                
            # Match Message
            bo_match = BO_REGEX.match(stripped)
            if bo_match:
                raw_id = int(bo_match.group(1))
                name = bo_match.group(2)
                dlc = int(bo_match.group(3))
                sender = bo_match.group(4)
                
                # Determine extended-frame flag and normalize
                is_extended = (raw_id & 0x80000000) != 0
                normalized_id = raw_id & 0x1FFFFFFF  # 29-bit mask
                
                key = (normalized_id, is_extended)
                
                # Warn on collision/overwrite of exact same message type
                if key in _seen_messages:
                    prev_name = _seen_messages[key]
                    print(
                        f"WARNING: DBC message '{name}' (ID 0x{normalized_id:X}, extended={is_extended}) "
                        f"overwrites previously parsed message '{prev_name}' with the same ID and type.",
                        file=sys.stderr
                    )
                
                _seen_messages[key] = name
                
                current_message = DBCMessage(
                    id=normalized_id,
                    name=name,
                    dlc=dlc,
                    sender=sender,
                    is_extended=is_extended,
                    signals=[]
                )
                messages[key] = current_message
                continue
                
            # Match Signal
            sg_match = SG_REGEX.match(stripped)
            if sg_match and current_message is not None:
                sig_name = sg_match.group(1)
                mux_indicator = sg_match.group(2)  # M or m<val>
                start_bit = int(sg_match.group(3))
                length = int(sg_match.group(4))
                byte_order = int(sg_match.group(5))  # 1 = Intel, 0 = Motorola
                sign_char = sg_match.group(6)  # + or -
                signed = (sign_char == '-')
                
                factor = float(sg_match.group(7))
                offset = float(sg_match.group(8))
                
                # Parse range limits
                min_str = sg_match.group(9)
                max_str = sg_match.group(10)
                
                minimum: Optional[float] = None
                maximum: Optional[float] = None
                
                if min_str is not None and min_str.strip():
                    try:
                        minimum = float(min_str.strip())
                    except ValueError:
                        minimum = None
                if max_str is not None and max_str.strip():
                    try:
                        maximum = float(max_str.strip())
                    except ValueError:
                        maximum = None
                        
                unit = sg_match.group(11)
                receivers_raw = sg_match.group(12)
                receivers = [r.strip() for r in receivers_raw.split(',') if r.strip()]
                
                # Determine multiplexer attributes
                is_multiplexer = False
                multiplexer_value: Optional[int] = None
                
                if mux_indicator:
                    if mux_indicator == 'M':
                        is_multiplexer = True
                    elif mux_indicator.startswith('m'):
                        try:
                            multiplexer_value = int(mux_indicator[1:])
                        except ValueError:
                            multiplexer_value = None
                            
                signal = DBCSignal(
                    name=sig_name,
                    start_bit=start_bit,
                    length=length,
                    byte_order=byte_order,
                    signed=signed,
                    factor=factor,
                    offset=offset,
                    minimum=minimum,
                    maximum=maximum,
                    unit=unit,
                    receivers=receivers,
                    is_multiplexer=is_multiplexer,
                    multiplexer_value=multiplexer_value
                )
                current_message.signals.append(signal)
                
    return messages
