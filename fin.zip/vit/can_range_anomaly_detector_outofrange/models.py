from dataclasses import dataclass, field
from typing import List, Optional, Union

@dataclass
class DBCSignal:
    name: str
    start_bit: int
    length: int
    byte_order: int  # 1 = Intel (little-endian), 0 = Motorola (big-endian)
    signed: bool
    factor: float
    offset: float
    minimum: Optional[float]
    maximum: Optional[float]
    unit: str
    receivers: List[str] = field(default_factory=list)
    is_multiplexer: bool = False
    multiplexer_value: Optional[int] = None  # None means always active (unless message has a mux and this signal is not the mux)

    @property
    def has_usable_range(self) -> bool:
        return self.minimum is not None and self.maximum is not None

@dataclass
class DBCMessage:
    id: int  # Numeric representation of CAN ID (e.g. 201)
    name: str
    dlc: int
    sender: str
    signals: List[DBCSignal] = field(default_factory=list)
    is_extended: bool = False  # True if this message uses a 29-bit extended CAN ID

class DBCDatabase(dict):
    """
    A dictionary subclass that keys messages by (can_id, is_extended).
    It ensures standard and extended IDs are treated as strictly distinct and non-interchangeable.
    
    NOTE: Plain integer CAN ID lookups (e.g. database[201]) are deprecated and supported 
    only for legacy backward compatibility where the key is unambiguous (i.e. only one version exists).
    """
    def __contains__(self, key) -> bool:
        if isinstance(key, tuple):
            return super().__contains__(key)
        
        import warnings
        warnings.warn(
            "Plain integer CAN ID lookups are deprecated. Use (can_id, is_extended) tuple keys instead.",
            DeprecationWarning,
            stacklevel=2
        )
        has_std = super().__contains__((key, False))
        has_ext = super().__contains__((key, True))
        if has_std and has_ext:
            return False  # Ambiguous key is not uniquely/unambiguously contained
        return has_std or has_ext

    def __getitem__(self, key) -> DBCMessage:
        if isinstance(key, tuple):
            return super().__getitem__(key)
        
        import warnings
        warnings.warn(
            "Plain integer CAN ID lookups are deprecated. Use (can_id, is_extended) tuple keys instead.",
            DeprecationWarning,
            stacklevel=2
        )
        has_std = super().__contains__((key, False))
        has_ext = super().__contains__((key, True))
        if has_std and has_ext:
            raise KeyError(
                f"CAN ID {key} is ambiguous (both standard and extended versions exist in database). "
                f"Lookup must use a tuple key (can_id, is_extended)."
            )
        if has_std:
            return super().__getitem__((key, False))
        if has_ext:
            return super().__getitem__((key, True))
        raise KeyError(key)

@dataclass
class CANFrame:
    timestamp: float
    channel: int
    can_id: int  # Normalized numeric CAN ID
    direction: str  # 'Rx' or 'Tx'
    frame_type: str  # 'd' (data), etc.
    dlc: int
    payload: bytes
    is_extended: bool = False  # True if this frame uses a 29-bit extended CAN ID

@dataclass
class DecodedSignal:
    signal: DBCSignal
    raw_value: Union[int, float]
    physical_value: Union[int, float]

@dataclass
class RangeAnomaly:
    timestamp: float
    can_id: int
    message_name: str
    signal_name: str
    raw_value: Union[int, float]
    physical_value: Union[int, float]
    minimum: float
    maximum: float
    unit: str
    factor: float
    offset: float
    reason: str
    is_extended: bool = False  # True if standard/extended
