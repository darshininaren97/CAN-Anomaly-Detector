import re
from typing import Generator, Tuple, Union
from models import CANFrame

# Regex to match valid CAN data line.
# Fields:  <timestamp> <channel> <id>[x] <direction> <frame_type> <dlc> [<payload...>]
#
# The frame_type field (typically 'd' for data, 'r' for remote) is required
# and separated explicitly from the DLC digit(s) by whitespace, removing
# the previous ambiguity that relied on regex backtracking.

# The optional trailing 'x' (case-insensitive) on the CAN ID marks an
# extended (29-bit) identifier in Vector ASC files.
#
# Examples:
#   4.023105 1  0C9       Rx  d 8  FF FF 00 00 AA BB CC DD
#   6.700000 1  0C9       Rx  d 0
#   1.234567 1  18FEF123x Rx  d 8  00 11 22 33 44 55 66 77
DATA_LINE_REGEX = re.compile(
    r'^\s*'
    r'(\d+\.\d+)'                           # 1: timestamp
    r'\s+(\d+)'                              # 2: channel
    r'\s+((?:0x)?[0-9a-fA-F]+)(x)?'          # 3: CAN ID hex digits, 4: optional 'x' (extended)
    r'\s+(Rx|Tx)'                             # 5: direction
    r'\s+([a-zA-Z]+)'                         # 6: frame type (one or more letters: d, r, …)
    r'\s+(\d+)'                               # 7: DLC
    r'(?:\s+(.*))?$'                          # 8: optional payload bytes
)

def parse_can_id(id_str: str, base_is_hex: bool) -> int:
    """Parse CAN ID string to an integer, automatically handling hex prefixes and base settings."""
    id_str = id_str.strip()
    if id_str.lower().startswith("0x"):
        return int(id_str, 16)

    # If base is hex or if it contains hex alphabetical characters, parse as hex
    if base_is_hex or any(c in id_str.lower() for c in 'abcdef'):
        return int(id_str, 16)

    try:
        return int(id_str, 10)
    except ValueError:
        # Fallback to hex
        return int(id_str, 16)

def parse_asc_log(file_path: str) -> Generator[Union[CANFrame, Tuple[str, str]], None, None]:
    """
    Stream and parse a Vector ASC log file line by line.

    Yields either:
      - CANFrame object for successfully parsed CAN frames.
      - Tuple[str, str] representing ("error", error_message) for malformed lines,
        or ("warning", warning_message) for non-fatal discrepancies.
    """
    base_is_hex = True  # Vector ASC defaults to hex for IDs and data

    with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
        for line_num, line in enumerate(f, 1):
            stripped = line.strip()

            # Skip empty lines or comment lines
            if not stripped or stripped.startswith("//"):
                continue

            # Parse header details
            if stripped.startswith("begin asc log") or stripped.startswith("end asc log"):
                continue
            if stripped.startswith("date") or stripped.startswith("internal events logged"):
                continue
            if stripped.startswith("base"):
                if "hex" in stripped:
                    base_is_hex = True
                elif "dec" in stripped:
                    base_is_hex = False
                continue

            # Match data line
            match = DATA_LINE_REGEX.match(stripped)
            if not match:
                # If it looks like it was meant to be a data line but is malformed, yield an error
                # (For instance, starts with a float, but doesn't match the rest)
                parts = stripped.split()
                if parts:
                    try:
                        float(parts[0])  # check if it starts with timestamp
                        yield ("error", f"Line {line_num}: Malformed CAN data format: '{stripped}'")
                    except ValueError:
                        # Probably a header or comment we don't care about
                        pass
                continue

            try:
                timestamp = float(match.group(1))
                channel = int(match.group(2))
                id_str = match.group(3)
                ext_marker = match.group(4)  # 'x' or None
                direction = match.group(5)
                frame_type = match.group(6)
                dlc = int(match.group(7))
                payload_str = match.group(8) or ""

                is_extended = ext_marker is not None
                can_id = parse_can_id(id_str, base_is_hex)
                # Parse payload bytes
                payload_parts = payload_str.strip().split()
                payload_bytes = []
                for p in payload_parts:
                    if not p:
                        continue
                    try:
                        val = int(p, 16)
                        if not (0 <= val <= 255):
                            raise ValueError(f"Byte value {p} out of range [0, 255]")
                        payload_bytes.append(val)
                    except ValueError as e:
                        raise ValueError(f"Invalid hex byte '{p}': {str(e)}")

                payload = bytes(payload_bytes)

                # Bug #6 fix: Surface DLC/payload length mismatch as a warning
                if len(payload) != dlc:
                    yield (
                        "warning",
                        f"Line {line_num}: DLC ({dlc}) does not match actual payload "
                        f"length ({len(payload)} bytes) for CAN ID "
                        f"{'0x' + id_str.upper() if base_is_hex else id_str}"
                    )

                yield CANFrame(
                    timestamp=timestamp,
                    channel=channel,
                    can_id=can_id,
                    direction=direction,
                    frame_type=frame_type,
                    dlc=dlc,
                    payload=payload,
                    is_extended=is_extended,
                )

            except Exception as e:
                yield ("error", f"Line {line_num}: Error parsing line '{stripped}': {str(e)}")
