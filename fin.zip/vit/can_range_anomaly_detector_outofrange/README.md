# DBC-Driven CAN Signal Range Anomaly Detector

A deterministic, production-quality, dependency-free Python tool to detect range anomalies in CAN signal values based on DBC database definitions.

---

## Table of Contents
1. [Overview](#overview)
2. [What is a Range Anomaly?](#what-is-a-range-anomaly)
3. [DBC File and Signal Ranges](#dbc-file-and-signal-ranges)
4. [Signal Decoding & Scaling](#signal-decoding--scaling)
5. [Vector ASC Log Parsing](#vector-asc-log-parsing)
6. [Supported Features & Limitations](#supported-features--limitations)
7. [System Architecture](#system-architecture)
8. [Installation](#installation)
9. [Usage](#usage)
10. [Test Suite](#test-suite)
11. [Example Execution](#example-execution)

---

## 1. Overview
This project parses standard Controller Area Network (CAN) database files (`.dbc`) and log files in Vector ASC format (`.log`/`.asc`). It extracts CAN signal bit fields, converts them into physical engineering values, and validates them against the inclusive ranges defined in the DBC. 

**This is a strictly deterministic range validator.** It does not use machine learning, timing anomalies, message flooding, or behavioral predictions.

---

## 2. What is a Range Anomaly?
A **Range Anomaly** occurs when a successfully decoded physical signal value lies outside its DBC-defined boundaries:
$$\text{physical\_value} < \text{minimum} \quad\text{or}\quad \text{physical\_value} > \text{maximum}$$

Range boundaries are **inclusive**. Values mathematically equal to the minimum or maximum boundaries are classified as **valid**.

---

## 3. DBC File and Signal Ranges
A DBC file defines the network architecture, messages, and signals.
- **Messages** are declared with:
  `BO_ <message_id> <message_name>: <dlc> <sender>`
- **Signals** are defined inside messages with:
  `SG_ <signal_name> [mux] : <start_bit>|<length>@<byte_order><sign> (<factor>,<offset>) [<minimum>|<maximum>] "<unit>" <receivers>`

### Example:
```
BO_ 201 EngineData: 8 Engine_ECU
 SG_ Engine_RPM : 0|16@1+ (0.25,0) [0|8000] "RPM" Vector__XXX
```
Here, the valid physical range is $[0.0, 8000.0]$. A physical value of $8000.25$ is a range anomaly, while $8000.0$ is valid.

---

## 4. Signal Decoding & Scaling

### Bit Extraction
1. **Intel / Little-Endian (`@1`)**: Start bit is the Least Significant Bit (LSB). Bits are extracted sequentially towards higher-order indices.
2. **Motorola / Big-Endian (`@0`)**: Start bit is the Most Significant Bit (MSB). Bits are extracted using a "sawtooth" pattern, reading downwards from the bit offset and wrapping to bit 7 of the next sequential byte index.

### Signedness
Signed signals (`-`) use two's-complement interpretation. For an $N$-bit value:
$$\text{If } \text{raw\_value} \ge 2^{N-1}: \text{signed\_value} = \text{raw\_value} - 2^N$$
$$\text{Otherwise}: \text{signed\_value} = \text{raw\_value}$$

### Scaling
Once the raw integer is extracted and interpreted, DBC scaling is applied:
$$\text{physical\_value} = \text{raw\_value} \times \text{factor} + \text{offset}$$

### Floating-Point Precision
To prevent false-positive anomaly reports due to floating-point rounding errors (e.g. `0.1 + 0.2` or binary division approximations), a tiny tolerance of $10^{-9}$ is applied during boundary checks:
$$\text{Is Anomalous If: } \text{physical\_value} < (\text{minimum} - 10^{-9}) \quad\text{or}\quad \text{physical\_value} > (\text{maximum} + 10^{-9})$$

---

## 5. Vector ASC Log Parsing
Vector ASC files contain metadata/header lines and CAN data frames.

### Input Format
A typical data line looks like:
`   4.023105 1  0C9  Rx  d 8  FF FF 00 00 AA BB CC DD`
- `4.023105`: Timestamp (seconds)
- `1`: Channel index
- `0C9`: CAN Identifier (represented as hex `0x0C9 = 201`)
- `Rx`: Direction
- `d`: Frame type (data)
- `8`: DLC (Data Length Code)
- `FF FF 00 00 AA BB CC DD`: Payload bytes in hex

The parser automatically detects base format declarations (e.g., `base hex` or `base dec` headers) and strips extended CAN identifier flags (bit 31) from DBC messages.

---

## 6. Supported Features & Limitations

### Supported DBC Features
- Intel (little-endian `@1`) and Motorola (big-endian `@0`) byte orders.
- Signed and unsigned signal encodings.
- Custom scale factors and positive/negative offsets.
- Inclusive limits parsing and validation.
- Standard 11-bit and Extended 29-bit CAN IDs.
- **Multiplexed Messages**: Evaluates the multiplexer signal first, determines the active mode, and range-checks only applicable multiplexed signals for that frame.

### Known Limitations & Fail-Safes
- If a signal does not specify a valid range in the DBC, it is classified as `NOT_CHECKED` rather than generating a fake range boundary.
- If a frame has a shorter payload than its DBC message DLC or signal requirements, it is reported as a `DECODING_ERROR` (rather than a range anomaly).
- Frames with unknown CAN IDs are recorded as `UNKNOWN_MESSAGE` and ignored for range checking.
- Parsing errors (e.g. invalid hex bytes like `ZZ`) are logged separately without crashing.

---

## 7. System Architecture
```
Vector ASC Log File ────┐
                        ▼
DBC Database File ──► [DBC Parser] ──► {CAN ID -> DBCMessage}
                                             │
                                             ▼
                      [ASC Parser] ──► [Signal Decoder]
                                             │
                                             ▼
                                     [Range Detector] ──► Inclusive Float Comparison
                                             │
                                             ▼
                                        [Reporter] ──► Console / CSV / JSON
```

---

## 8. Installation
This program uses Python built-ins. To install pytest for running tests:
```bash
pip install -r requirements.txt
```

---

## 9. Usage
Run the detector from the command line:
```bash
python main.py --dbc <path_to_dbc> --log <path_to_asc_log> [--output <report_path>] [--format <text|json|csv>] [--verbose]
```

### Options:
- `--dbc`: (Required) Path to the `.dbc` database file.
- `--log`: (Required) Path to the `.log`/`.asc` file.
- `--output`: Optional path to write report.
- `--format`: Report file format (`text`, `json`, `csv`; default `text`).
- `--verbose`: Enable detailed log prints for every parsed CAN frame.

---

## 10. Test Suite
To run the automated unit and integration tests:
```bash
python -m pytest tests/
```

---

## 11. Example Execution
Given `sample.dbc` and `vehicle_drive_session.log` in this directory:
```bash
python main.py --dbc sample.dbc --log vehicle_drive_session.log
```

### Output:
```
RANGE ANOMALY
Timestamp:       4.023105
CAN ID:          0x0C9
Message:         EngineData
Signal:          Engine_RPM
Raw Value:       65535
Physical Value:  16383.75
Valid Range:     0–8000
Unit:            RPM
Factor:          0.25
Offset:          0
Reason:          Value exceeds maximum

RANGE ANOMALY
Timestamp:       6.500000
CAN ID:          0x0C9
Message:         EngineData
Signal:          Engine_RPM
Raw Value:       65535
Physical Value:  16383.75
Valid Range:     0–8000
Unit:            RPM
Factor:          0.25
Offset:          0
Reason:          Value exceeds maximum

[6.700000] DECODING_ERROR on CAN ID 0x0c9:
  Frame payload length (0 bytes) is less than DBC DLC (8 bytes) for message 'EngineData'

========================================
DETECTION SUMMARY
========================================
Total Frames Processed:   133
Valid Frames:             130
Range Anomalies Found:    2
Decoding/Parsing Errors:  1
Unknown CAN Messages:     0
Not Checked Frames:       0
========================================
```
