import math
from typing import Dict, List, Tuple, Union
from models import DBCMessage, DBCSignal, CANFrame, DecodedSignal, RangeAnomaly, DBCDatabase
from signal_decoder import extract_signal, decode_signal

def detect_range_anomalies(
    frame: CANFrame, 
    dbc_messages: DBCDatabase
) -> Tuple[str, List[Union[DecodedSignal, RangeAnomaly, str]]]:
    """
    Evaluate a CANFrame against the DBC database definitions.
    
    Returns a Tuple of (status, details):
      - status: One of 'VALID', 'RANGE_ANOMALY', 'DECODING_ERROR', 'UNKNOWN_MESSAGE', 'NOT_CHECKED'
      - details: A list containing:
          - DecodedSignal objects for valid signals
          - RangeAnomaly objects for out-of-range signals
          - str messages for errors or status details
    """
    # 1. Match message using normalized CAN ID and extendedness
    key = (frame.can_id, frame.is_extended)
    if key in dbc_messages:
        message = dbc_messages[key]
    else:
        return 'UNKNOWN_MESSAGE', [f"CAN ID {hex(frame.can_id)} (extended={frame.is_extended}) not found in DBC"]
    
    # 2. Check basic frame payload length against DBC message DLC
    if len(frame.payload) < message.dlc:
        return 'DECODING_ERROR', [
            f"Frame payload length ({len(frame.payload)} bytes) is less than DBC DLC ({message.dlc} bytes) for message '{message.name}'"
        ]
        
    # 3. Determine applicable signals based on multiplexing
    # NOTE: This implementation only supports single-level multiplexing (one multiplexer signal per message).
    # Multi-level or nested/extended multiplexing layouts are not supported.
    mux_signals = [sig for sig in message.signals if sig.is_multiplexer]
    mux_signal = mux_signals[0] if mux_signals else None
            
    applicable_signals: List[DBCSignal] = []
    
    if mux_signal is not None:
        try:
            # Extract raw multiplexer value
            mux_raw_val = extract_signal(
                frame.payload,
                mux_signal.start_bit,
                mux_signal.length,
                mux_signal.byte_order,
                mux_signal.signed
            )
            applicable_signals.append(mux_signal)
            
            # Determine which other signals are active for this multiplexer raw value
            for sig in message.signals:
                if sig is mux_signal:
                    continue
                if sig.multiplexer_value is None:
                    applicable_signals.append(sig)
                elif sig.multiplexer_value == mux_raw_val:
                    applicable_signals.append(sig)
        except ValueError as e:
            return 'DECODING_ERROR', [
                f"Failed to extract multiplexer signal '{mux_signal.name}' in message '{message.name}': {str(e)}"
            ]
    else:
        applicable_signals = message.signals
        
    # If no signals are defined in the DBC for this message, status is NOT_CHECKED
    if not applicable_signals:
        return 'NOT_CHECKED', ["No signals defined for this message"]
        
    # 4. Decode and check each applicable signal
    results = []
    has_anomaly = False
    has_decoding_error = False
    checked_count = 0
    
    for sig in applicable_signals:
        # Check if payload contains enough bytes to safely extract this signal
        # (This is a safety check to prevent unsafe extraction)
        try:
            # Try to extract raw value
            raw_val = extract_signal(
                frame.payload,
                sig.start_bit,
                sig.length,
                sig.byte_order,
                sig.signed
            )
        except ValueError as e:
            has_decoding_error = True
            results.append(f"DECODING_ERROR: Signal '{sig.name}' extraction failed: {str(e)}")
            continue
            
        # Decode fully (raw and physical)
        physical_val = raw_val * sig.factor + sig.offset
        
        # Check for NaN / Infinity
        if not math.isfinite(physical_val):
            has_decoding_error = True
            results.append(f"DECODING_ERROR: Signal '{sig.name}' physical value is non-finite ({physical_val})")
            continue
            
        decoded = DecodedSignal(signal=sig, raw_value=raw_val, physical_value=physical_val)
        
        # Check range
        if not sig.has_usable_range:
            results.append(decoded)
            continue
            
        # Inclusive range check with floating-point tolerance
        # Tolerance of 1e-9 prevents false positives due to floats
        tol = 1e-9
        is_under = physical_val < (sig.minimum - tol)
        is_over = physical_val > (sig.maximum + tol)
        
        if is_under or is_over:
            has_anomaly = True
            reason = "Value below minimum" if is_under else "Value exceeds maximum"
            anomaly = RangeAnomaly(
                timestamp=frame.timestamp,
                can_id=frame.can_id,
                message_name=message.name,
                signal_name=sig.name,
                raw_value=raw_val,
                physical_value=physical_val,
                minimum=sig.minimum,
                maximum=sig.maximum,
                unit=sig.unit,
                factor=sig.factor,
                offset=sig.offset,
                reason=reason,
                is_extended=frame.is_extended
            )
            results.append(anomaly)
        else:
            results.append(decoded)
            
        checked_count += 1
        
    # Determine overall status of this CANFrame check
    if has_decoding_error:
        return 'DECODING_ERROR', results
    elif has_anomaly:
        return 'RANGE_ANOMALY', results
    elif checked_count > 0:
        return 'VALID', results
    else:
        return 'NOT_CHECKED', results
