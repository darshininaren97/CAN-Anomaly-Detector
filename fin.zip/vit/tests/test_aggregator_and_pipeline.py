"""
tests/test_aggregator_and_pipeline.py
Integration tests for AnomalyAggregator, UnifiedAnomalyPipeline, and Reporters.
"""

from pathlib import Path
import json
import pytest
from core.aggregator import AnomalyAggregator
from core.models import UnifiedAnomaly, Severity, AnomalyCategory
from core.pipeline import PipelineConfig, UnifiedAnomalyPipeline
from core.reporter import UnifiedReporter

ROOT = Path(__file__).resolve().parent.parent
SAMPLE_DBC = ROOT / "parse" / "CAN.dbc"
SAMPLE_LOG = ROOT / "parse" / "CAN.log.txt"


def test_aggregator_deduplication():
    agg = AnomalyAggregator()

    a1 = UnifiedAnomaly(
        timestamp=4.023,
        anomaly_type="CONTRADICTORY_SIGNAL",
        category=AnomalyCategory.CONTRADICTORY_SIGNAL,
        severity=Severity.HIGH,
        detector="Logic Detector",
        reason="Speed > 0 while engine OFF",
        can_id=201,
        rule_id="R-001",
        signals=["Vehicle_Speed", "Engine_Status"],
    )

    # Identical finding
    a2 = UnifiedAnomaly(
        timestamp=4.023,
        anomaly_type="CONTRADICTORY_SIGNAL",
        category=AnomalyCategory.CONTRADICTORY_SIGNAL,
        severity=Severity.HIGH,
        detector="Logic Detector",
        reason="Speed > 0 while engine OFF",
        can_id=201,
        rule_id="R-001",
        signals=["Vehicle_Speed", "Engine_Status"],
    )

    # Different detector finding at same timestamp - must NOT be merged
    a3 = UnifiedAnomaly(
        timestamp=4.023,
        anomaly_type="RANGE_ANOMALY",
        category=AnomalyCategory.RANGE,
        severity=Severity.HIGH,
        detector="Range Detector",
        reason="RPM exceeds max",
        can_id=201,
        signal_name="Engine_RPM",
    )

    assert agg.add(a1) is True
    assert agg.add(a2) is False  # Duplicate prevented
    assert agg.add(a3) is True   # Distinct detector/category preserved

    anomalies = agg.get_anomalies()
    assert len(anomalies) == 2


def test_end_to_end_pipeline():
    config = PipelineConfig(
        dbc_path=str(SAMPLE_DBC),
        log_path=str(SAMPLE_LOG),
        detectors="all",
    )
    pipeline = UnifiedAnomalyPipeline(config)
    result = pipeline.run()

    assert result.success is True
    assert result.total_frames == 289
    assert result.decoded_frames == 289
    assert len(result.anomalies) > 0
    assert "total_anomalies" in result.summary
    assert result.report_text is not None
    assert "CAN BUS UNIFIED ANOMALY DETECTION REPORT" in result.report_text


def test_pipeline_export_formats(tmp_path):
    json_out = tmp_path / "report.json"
    csv_out = tmp_path / "report.csv"
    txt_out = tmp_path / "report.txt"

    # Test JSON export
    config_json = PipelineConfig(
        dbc_path=str(SAMPLE_DBC),
        log_path=str(SAMPLE_LOG),
        output_path=str(json_out),
        output_format="json",
    )
    res_json = UnifiedAnomalyPipeline(config_json).run()
    assert res_json.success is True
    assert json_out.exists()
    with open(json_out, "r", encoding="utf-8") as f:
        data = json.load(f)
        assert "anomalies" in data
        assert "summary" in data

    # Test CSV export
    config_csv = PipelineConfig(
        dbc_path=str(SAMPLE_DBC),
        log_path=str(SAMPLE_LOG),
        output_path=str(csv_out),
        output_format="csv",
    )
    res_csv = UnifiedAnomalyPipeline(config_csv).run()
    assert res_csv.success is True
    assert csv_out.exists()

    # Test Text export
    config_txt = PipelineConfig(
        dbc_path=str(SAMPLE_DBC),
        log_path=str(SAMPLE_LOG),
        output_path=str(txt_out),
        output_format="text",
    )
    res_txt = UnifiedAnomalyPipeline(config_txt).run()
    assert res_txt.success is True
    assert txt_out.exists()


def test_export_parsed_can_csv(tmp_path):
    parsed_csv_out = tmp_path / "decoded_output.csv"
    config = PipelineConfig(
        dbc_path=str(SAMPLE_DBC),
        log_path=str(SAMPLE_LOG),
        export_parsed_csv_path=str(parsed_csv_out),
    )
    res = UnifiedAnomalyPipeline(config).run()
    assert res.success is True
    assert parsed_csv_out.exists()
    with open(parsed_csv_out, "r", encoding="utf-8") as f:
        first_line = f.readline()
        assert "timestamp" in first_line
        assert "signal" in first_line
        assert "value" in first_line
