"""
tests/test_detectors.py
Tests for each individual anomaly detector module.
"""

import pytest
from core.models import CANFrame, DecodedFrame, DecodedSignal, Severity, AnomalyCategory
from detectors.range_detector import RangeAnomalyDetector
from detectors.logic_detector import LogicAnomalyDetector
from detectors.timing_detector import TimingAnomalyDetector
from detectors.frame_detector import FrameAnomalyDetector
from parsers.dbc_parser import DBCParser, MessageDef, SignalDef, DBCDatabase


def test_range_anomaly_detector():
    detector = RangeAnomalyDetector()

    # Normal signal
    sig_normal = DecodedSignal(
        name="Vehicle_Speed",
        message_name="VehicleSpeed",
        can_id=416,
        timestamp=1.0,
        raw_value=10000,
        physical_value=100.0,
        unit="km/h",
        minimum=0.0,
        maximum=300.0,
    )
    df_normal = DecodedFrame(
        frame=CANFrame(timestamp=1.0, can_id=416, dlc=8, data=b"\x00"*8),
        message_name="VehicleSpeed",
        signals={"Vehicle_Speed": sig_normal},
    )

    # Out of range signal (speed = 350 km/h > 300)
    sig_out = DecodedSignal(
        name="Vehicle_Speed",
        message_name="VehicleSpeed",
        can_id=416,
        timestamp=1.1,
        raw_value=35000,
        physical_value=350.0,
        unit="km/h",
        minimum=0.0,
        maximum=300.0,
    )
    df_out = DecodedFrame(
        frame=CANFrame(timestamp=1.1, can_id=416, dlc=8, data=b"\x00"*8),
        message_name="VehicleSpeed",
        signals={"Vehicle_Speed": sig_out},
    )

    anomalies = detector.analyze(
        frames=[df_normal.frame, df_out.frame],
        decoded_frames=[df_normal, df_out],
    )

    assert len(anomalies) == 1
    assert anomalies[0].anomaly_type == "RANGE_ANOMALY"
    assert anomalies[0].category == AnomalyCategory.RANGE
    assert anomalies[0].observed_value == 350.0
    assert anomalies[0].expected_range == (0.0, 300.0)


def test_logic_anomaly_detector_r001():
    detector = LogicAnomalyDetector()

    # Create frames simulating speed = 100 while engine = OFF (0)
    sig_speed = DecodedSignal(
        name="Vehicle_Speed",
        message_name="VehicleSpeed",
        can_id=416,
        timestamp=2.0,
        raw_value=10000,
        physical_value=100.0,
        unit="km/h",
    )
    sig_engine = DecodedSignal(
        name="Engine_Status",
        message_name="EngineData",
        can_id=201,
        timestamp=2.01,
        raw_value=0,
        physical_value=0.0,
        enum_name="OFF",
    )

    df1 = DecodedFrame(
        frame=CANFrame(timestamp=2.0, can_id=416, dlc=8, data=b"\x00"*8),
        message_name="VehicleSpeed",
        signals={"Vehicle_Speed": sig_speed},
    )
    df2 = DecodedFrame(
        frame=CANFrame(timestamp=2.01, can_id=201, dlc=8, data=b"\x00"*8),
        message_name="EngineData",
        signals={"Engine_Status": sig_engine},
    )

    anomalies = detector.analyze(
        frames=[df1.frame, df2.frame],
        decoded_frames=[df1, df2],
    )

    assert any(a.rule_id == "R-001" for a in anomalies)


def test_frame_dlc_detector():
    detector = FrameAnomalyDetector()

    db = DBCDatabase()
    msg = MessageDef(id=201, name="EngineData", dlc=8, sender="Engine_ECU")
    db.add_message(msg)

    # Frame with truncated payload (4 bytes instead of 8)
    truncated_frame = CANFrame(timestamp=1.0, can_id=201, dlc=4, data=bytes([1, 2, 3, 4]))
    df = DecodedFrame(frame=truncated_frame, message_name="EngineData", signals={})

    anomalies = detector.analyze(
        frames=[truncated_frame],
        decoded_frames=[df],
        db=db,
    )

    assert len(anomalies) == 1
    assert anomalies[0].anomaly_type == "DLC_MISMATCH"
    assert anomalies[0].observed_value == 4
    assert anomalies[0].expected_value == 8


def test_integrity_detector():
    from detectors.integrity_detector import IntegrityAnomalyDetector
    detector = IntegrityAnomalyDetector()

    # Frame with DLC 0 on a data frame
    empty_frame = CANFrame(
        timestamp=6.7,
        can_id=0x0C9,
        dlc=0,
        data=b"",
        frame_type="d",
    )
    df = DecodedFrame(frame=empty_frame, message_name="EngineData", signals={})

    anomalies = detector.analyze(
        frames=[empty_frame],
        decoded_frames=[df],
    )

    assert len(anomalies) == 1
    assert anomalies[0].anomaly_type == "DATA_CORRUPTION"
    assert anomalies[0].category == AnomalyCategory.DATA_CORRUPTION
