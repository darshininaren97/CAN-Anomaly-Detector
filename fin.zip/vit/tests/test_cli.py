"""
tests/test_cli.py
Tests for the main CLI application entry point and error handling.
"""

from pathlib import Path
import pytest
from main import run_app, EXIT_SUCCESS, EXIT_FILE_NOT_FOUND, EXIT_INVALID_ARGS

ROOT = Path(__file__).resolve().parent.parent
SAMPLE_DBC = ROOT / "parse" / "CAN.dbc"
SAMPLE_LOG = ROOT / "parse" / "CAN.log.txt"


def test_cli_success():
    code = run_app(["--dbc", str(SAMPLE_DBC), "--log", str(SAMPLE_LOG)])
    assert code == EXIT_SUCCESS


def test_cli_missing_dbc():
    code = run_app(["--dbc", "non_existent.dbc", "--log", str(SAMPLE_LOG)])
    assert code == EXIT_FILE_NOT_FOUND


def test_cli_missing_log():
    code = run_app(["--dbc", str(SAMPLE_DBC), "--log", "non_existent.log"])
    assert code == EXIT_FILE_NOT_FOUND


def test_cli_invalid_detector():
    code = run_app(["--dbc", str(SAMPLE_DBC), "--log", str(SAMPLE_LOG), "--detectors", "invalid_detector"])
    assert code == EXIT_INVALID_ARGS


def test_cli_selective_detectors(tmp_path):
    out_file = tmp_path / "out.json"
    code = run_app([
        "--dbc", str(SAMPLE_DBC),
        "--log", str(SAMPLE_LOG),
        "--detectors", "range,logic",
        "--format", "json",
        "--output", str(out_file)
    ])
    assert code == EXIT_SUCCESS
    assert out_file.exists()
