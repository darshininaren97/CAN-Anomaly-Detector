"""
tests/test_parsers.py
Tests for DBC parser, CAN log parser, and signal decoder.
"""

from pathlib import Path
import pytest
from parsers.dbc_parser import DBCParser, parse_dbc
from parsers.log_parser import CANLogParser, parse_can_log
from parsers.signal_decoder import SignalDecoder, extract_raw_signal
from core.models import CANFrame

SAMPLE_DBC = """
VERSION ""
NS_ :
BS_:
BU_: Engine_ECU ABS_ECU

BO_ 201 EngineData: 8 Engine_ECU
 SG_ Engine_RPM : 0|16@1+ (0.25,0) [0|8000] "RPM" ABS_ECU
 SG_ Engine_Status : 16|1@1+ (1,0) [0|1] "" ABS_ECU

BO_ 416 VehicleSpeed: 8 ABS_ECU
 SG_ Vehicle_Speed : 0|16@1+ (0.01,0) [0|300] "km/h" Engine_ECU
 SG_ Wheel_Speed_FL : 16|16@1+ (0.01,0) [0|300] "km/h" Engine_ECU
 SG_ Wheel_Speed_FR : 32|16@1+ (0.01,0) [0|300] "km/h" Engine_ECU

VAL_ 201 Engine_Status 0 "OFF" 1 "RUNNING";
"""

SAMPLE_ASC = """date Mon Apr 15 10:00:00 2024
base hex  timestamps absolute
internal events logged
// Sample log
   0.000000 1  0C9             Rx   d 8 00 00 00 00 00 00 00 00
   0.010000 1  1A0             Rx   d 8 20 4E 00 00 00 00 00 00
"""


def test_parse_dbc_string():
    db = DBCParser.parse_string(SAMPLE_DBC)
    assert len(db.messages) == 2
    msg201 = db.get_message(201)
    assert msg201 is not None
    assert msg201.name == "EngineData"
    assert len(msg201.signals) == 2

    rpm_sig = msg201.get_signal("Engine_RPM")
    assert rpm_sig is not None
    assert rpm_sig.factor == 0.25
    assert rpm_sig.min_val == 0.0
    assert rpm_sig.max_val == 8000.0

    status_sig = msg201.get_signal("Engine_Status")
    assert status_sig is not None
    assert status_sig.enums.get(0) == "OFF"
    assert status_sig.enums.get(1) == "RUNNING"


def test_parse_asc_stream():
    lines = SAMPLE_ASC.splitlines()
    frames = [f for f in CANLogParser.parse_asc_stream(lines) if isinstance(f, CANFrame)]
    assert len(frames) == 2
    assert frames[0].can_id == 0x0C9
    assert frames[0].timestamp == 0.0
    assert frames[0].dlc == 8
    assert frames[1].can_id == 0x1A0
    assert frames[1].timestamp == 0.01


def test_signal_decoder():
    db = DBCParser.parse_string(SAMPLE_DBC)
    decoder = SignalDecoder(db)

    # Frame for EngineData: RPM = 4000 (raw = 16000 = 0x3E80 -> bytes 80 3E)
    raw_payload = bytes([0x80, 0x3E, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00])
    frame = CANFrame(timestamp=1.0, can_id=201, dlc=8, data=raw_payload)
    df = decoder.decode_frame(frame)

    assert df is not None
    assert df.message_name == "EngineData"
    assert "Engine_RPM" in df.signals
    assert df.signals["Engine_RPM"].raw_value == 16000
    assert df.signals["Engine_RPM"].physical_value == 4000.0
    assert df.signals["Engine_Status"].physical_value == 1.0
    assert df.signals["Engine_Status"].enum_name == "RUNNING"


def test_motorola_bit_extraction():
    # Big-endian extraction test
    payload = bytes([0x12, 0x34, 0x56, 0x78])
    # Extract 8 bits starting at bit 7 (first byte MSB)
    val = extract_raw_signal(payload, start_bit=7, length=8, byte_order=0, is_signed=False)
    assert val == 0x12
