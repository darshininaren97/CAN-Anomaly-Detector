"""
tests/test_models.py
Tests for core canonical data models.
"""

import pytest
from core.models import (
    CANFrame,
    DecodedSignal,
    DecodedFrame,
    UnifiedAnomaly,
    Severity,
    AnomalyCategory,
)


def test_can_frame_properties():
    frame = CANFrame(
        timestamp=1.234567,
        can_id=0x1A0,
        dlc=8,
        data=bytes([0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08]),
        is_extended=False,
    )
    assert frame.hex_id == "0x1A0"
    assert frame.data_hex == "0102030405060708"
    assert not frame.is_remote
    d = frame.to_dict()
    assert d["timestamp"] == 1.234567
    assert d["can_id"] == 416
    assert d["hex_id"] == "0x1A0"


def test_extended_can_frame():
    frame = CANFrame(
        timestamp=2.0,
        can_id=0x18FEF100,
        dlc=4,
        data=bytes([0xAA, 0xBB, 0xCC, 0xDD]),
        is_extended=True,
    )
    assert frame.hex_id == "0x18FEF100"
    assert frame.is_extended is True


def test_decoded_signal():
    sig = DecodedSignal(
        name="Engine_RPM",
        message_name="EngineData",
        can_id=0x0C9,
        timestamp=3.5,
        raw_value=4000,
        physical_value=1000.0,
        unit="RPM",
        minimum=0.0,
        maximum=8000.0,
        factor=0.25,
        offset=0.0,
    )
    assert sig.has_usable_range is True
    d = sig.to_dict()
    assert d["name"] == "Engine_RPM"
    assert d["physical_value"] == 1000.0


def test_unified_anomaly_serialization():
    anomaly = UnifiedAnomaly(
        timestamp=4.023,
        anomaly_type="CONTRADICTORY_SIGNAL",
        category=AnomalyCategory.CONTRADICTORY_SIGNAL,
        severity=Severity.HIGH,
        detector="Logic & Correlation Detector",
        reason="Vehicle moving while engine status is OFF",
        can_id=0x0C9,
        signals=["Vehicle_Speed", "Engine_Status"],
        rule_id="R-001",
    )
    assert anomaly.can_id_hex == "0x0C9"
    d = anomaly.to_dict()
    assert d["rule_id"] == "R-001"
    assert d["category"] == "CONTRADICTORY_SIGNAL"
    assert d["severity"] == "HIGH"
    json_str = anomaly.to_json()
    assert "Vehicle moving while engine status is OFF" in json_str
