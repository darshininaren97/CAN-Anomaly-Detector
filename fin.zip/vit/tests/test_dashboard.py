"""
tests/test_dashboard.py
Tests for core/dashboard.py — signal-timeline HTML dashboard generation.

Follows the style of tests/test_aggregator_and_pipeline.py.
All tests are side-effect-free; temp paths are managed by pytest's tmp_path fixture.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

import pytest

# ── Shared project root wiring (matches other test files) ──────────────────────
ROOT = Path(__file__).resolve().parent.parent
SAMPLE_DBC = ROOT / "parse" / "CAN.dbc"
SAMPLE_LOG = ROOT / "parse" / "CAN.log.txt"

# ── Minimal fake model constructors ────────────────────────────────────────────
from core.models import (
    AnomalyCategory,
    CANFrame,
    DecodedFrame,
    DecodedSignal,
    Severity,
    UnifiedAnomaly,
)
from core.dashboard import generate_dashboard_html
from core.pipeline import PipelineConfig, UnifiedAnomalyPipeline
from main import run_app


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _make_frame(ts: float, can_id: int = 0x1A0) -> CANFrame:
    return CANFrame(
        timestamp=ts,
        can_id=can_id,
        dlc=8,
        data=bytes(8),
        channel=1,
    )


def _make_signal(name: str, ts: float, value: float, unit: str = "RPM") -> DecodedSignal:
    return DecodedSignal(
        name=name,
        message_name="TestMessage",
        can_id=0x0C9,
        timestamp=ts,
        raw_value=int(value),
        physical_value=value,
        unit=unit,
        minimum=0.0,
        maximum=8000.0,
    )


def _make_decoded_frame(ts: float, signals: Dict[str, DecodedSignal]) -> DecodedFrame:
    frame = _make_frame(ts)
    return DecodedFrame(frame=frame, message_name="TestMessage", signals=signals)


def _make_anomaly(
    ts: float,
    sig_name: str | None = "Engine_RPM",
    sev: Severity = Severity.HIGH,
) -> UnifiedAnomaly:
    return UnifiedAnomaly(
        timestamp=ts,
        anomaly_type="RANGE_ANOMALY",
        category=AnomalyCategory.RANGE,
        severity=sev,
        detector="Range Detector",
        reason="Signal exceeds maximum allowed value",
        can_id=0x0C9,
        signal_name=sig_name,
        observed_value=16383.75,
        expected_value=8000.0,
    )


def _dummy_summary() -> dict:
    return {
        "total_anomalies": 1,
        "by_severity": {"critical": 0, "high": 1, "medium": 0, "low": 0},
        "by_category": {"RANGE": 1},
        "by_detector": {"Range Detector": 1},
    }


def _dummy_metadata() -> dict:
    return {
        "DBC File": "CAN.dbc",
        "CAN Log File": "CAN.log.txt",
        "Active Detectors": "Range Detector",
        "Total Frames Processed": 10,
        "Execution Time": "0.01 s",
    }


# ──────────────────────────────────────────────────────────────────────────────
# Test 1: Normal operation produces valid HTML with required artefacts
# ──────────────────────────────────────────────────────────────────────────────

def test_dashboard_normal(tmp_path):
    """generate_dashboard_html writes a file that exists and contains
    expected HTML landmarks: <canvas, JSON payload, and Chart.js reference."""
    out = tmp_path / "dashboard.html"

    # Build two signal timelines and one anomaly
    frames = []
    for i in range(10):
        ts = i * 0.1
        sig = _make_signal("Engine_RPM", ts, float(i * 800))
        spd = _make_signal("Vehicle_Speed", ts, float(i * 10), unit="km/h")
        frames.append(_make_decoded_frame(ts, {"Engine_RPM": sig, "Vehicle_Speed": spd}))

    anomaly = _make_anomaly(0.5, sev=Severity.CRITICAL)

    generate_dashboard_html(
        decoded_frames=frames,
        anomalies=[anomaly],
        summary=_dummy_summary(),
        metadata=_dummy_metadata(),
        output_path=str(out),
    )

    assert out.exists(), "Dashboard HTML file should be created"
    html = out.read_text(encoding="utf-8")

    # Must contain chart canvas elements
    assert "<canvas" in html, "HTML must contain at least one <canvas> element"

    # Must reference Chart.js (inline or CDN)
    assert "chart" in html.lower(), "HTML must reference Chart.js"

    # Must embed the JSON payload
    assert '"Engine_RPM"' in html, "Signal data should be embedded in HTML payload"
    assert '"Vehicle_Speed"' in html, "Vehicle_Speed signal should be in HTML payload"

    # Must contain anomaly data
    assert "RANGE_ANOMALY" in html, "Anomaly type should appear in the payload"
    assert "CRITICAL" in html, "Severity CRITICAL should appear"

    # File must be loadable and the payload parseable
    payload_start = html.find("const PAYLOAD =") + len("const PAYLOAD =")
    # Find matching closing for the JSON object (basic sanity check)
    assert payload_start > len("const PAYLOAD ="), "Payload assignment must be present"


# ──────────────────────────────────────────────────────────────────────────────
# Test 2: Empty decoded_frames → valid HTML with "no data" message
# ──────────────────────────────────────────────────────────────────────────────

def test_dashboard_empty_decoded_frames(tmp_path):
    """Dashboard must not crash on empty decoded_frames; should produce
    graceful 'No signal data' message without corrupting HTML structure."""
    out = tmp_path / "empty_dashboard.html"

    generate_dashboard_html(
        decoded_frames=[],
        anomalies=[],
        summary={},
        metadata=_dummy_metadata(),
        output_path=str(out),
    )

    assert out.exists(), "Dashboard file must be created even with no frames"
    html = out.read_text(encoding="utf-8")
    assert "<!DOCTYPE html>" in html
    assert "<canvas" in html  # summary charts still render
    # No signal points → signals dict will be empty
    assert '"signals": {}' in html or '"signals":{}' in html


# ──────────────────────────────────────────────────────────────────────────────
# Test 3: Anomaly with signal_name not present in decoded_frames → no crash
# ──────────────────────────────────────────────────────────────────────────────

def test_dashboard_anomaly_orphan_signal(tmp_path):
    """Anomaly referencing a signal absent from decoded_frames must not crash.
    The anomaly should appear in anomaly_index but no chart series for it."""
    out = tmp_path / "orphan.html"

    # Decoded frame only has Vehicle_Speed
    spd = _make_signal("Vehicle_Speed", 1.0, 60.0, "km/h")
    df = _make_decoded_frame(1.0, {"Vehicle_Speed": spd})

    # Anomaly references Engine_RPM which has NO decoded timeline
    orphan = _make_anomaly(1.0, sig_name="Engine_RPM", sev=Severity.HIGH)

    generate_dashboard_html(
        decoded_frames=[df],
        anomalies=[orphan],
        summary=_dummy_summary(),
        metadata=_dummy_metadata(),
        output_path=str(out),
    )

    assert out.exists()
    html = out.read_text(encoding="utf-8")
    # Vehicle_Speed timeline must be present
    assert '"Vehicle_Speed"' in html
    # Engine_RPM should appear in anomaly_index but NOT in signals
    assert '"Engine_RPM"' in html  # present in anomaly_index


# ──────────────────────────────────────────────────────────────────────────────
# Test 4: Anomaly with no signal_name → goes to __lane__ activity index
# ──────────────────────────────────────────────────────────────────────────────

def test_dashboard_lane_anomaly(tmp_path):
    """Anomaly with signal_name=None (e.g. TIMING_TIMEOUT) must be placed in
    the __lane__ bucket of anomaly_index, not cause a crash."""
    out = tmp_path / "lane_anom.html"

    timeout_anomaly = UnifiedAnomaly(
        timestamp=8.0,
        anomaly_type="TIMING_TIMEOUT",
        category=AnomalyCategory.TIMING_TIMEOUT,
        severity=Severity.CRITICAL,
        detector="Timing & Behavioral Detector",
        reason="CAN message timeout detected; gap of 10.0s exceeds nominal period 0.01s",
        can_id=0x1B0,
        signal_name=None,
        message_name="TransmissionData",
        observed_value=10.0,
        expected_value=0.01,
    )

    frame = _make_frame(1.0, 0x1B0)
    spd = _make_signal("Vehicle_Speed", 1.0, 120.0, "km/h")
    df = DecodedFrame(frame=frame, message_name="TransmissionData", signals={"Vehicle_Speed": spd})

    generate_dashboard_html(
        decoded_frames=[df],
        anomalies=[timeout_anomaly],
        summary=_dummy_summary(),
        metadata=_dummy_metadata(),
        output_path=str(out),
    )

    assert out.exists()
    html = out.read_text(encoding="utf-8")
    assert '"__lane__"' in html, "__lane__ bucket must be present in anomaly_index"
    assert "TIMING_TIMEOUT" in html


# ──────────────────────────────────────────────────────────────────────────────
# Test 5: All four severity levels render correct colors in payload
# ──────────────────────────────────────────────────────────────────────────────

def test_dashboard_severity_colors(tmp_path):
    """The severity color map must appear in the embedded payload."""
    out = tmp_path / "sev.html"

    anoms = [
        _make_anomaly(1.0, sev=Severity.CRITICAL),
        _make_anomaly(2.0, sev=Severity.HIGH),
        _make_anomaly(3.0, sev=Severity.MEDIUM),
        _make_anomaly(4.0, sev=Severity.LOW),
    ]
    generate_dashboard_html(
        decoded_frames=[],
        anomalies=anoms,
        summary=_dummy_summary(),
        metadata=_dummy_metadata(),
        output_path=str(out),
    )

    html = out.read_text(encoding="utf-8")
    for sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
        assert sev in html, f"Severity {sev} must appear in HTML"


# ──────────────────────────────────────────────────────────────────────────────
# Test 6: End-to-end via CLI -- --dashboard flag produces the file, exit 0
# ──────────────────────────────────────────────────────────────────────────────

@pytest.mark.skipif(not SAMPLE_DBC.exists(), reason="Sample DBC not available")
def test_cli_dashboard_end_to_end(tmp_path):
    """run_app(['--dbc', ..., '--log', ..., '--dashboard', ...]) must:
    - exit with code 0
    - produce a non-empty HTML file at the given path
    - existing text report must still work alongside the dashboard flag
    """
    dash_path = tmp_path / "report.html"

    exit_code = run_app([
        "--dbc", str(SAMPLE_DBC),
        "--log", str(SAMPLE_LOG),
        "--dashboard", str(dash_path),
    ])

    assert exit_code == 0, f"run_app returned non-zero exit code: {exit_code}"
    assert dash_path.exists(), "--dashboard path must be created by the pipeline"

    html = dash_path.read_text(encoding="utf-8")
    assert "<!DOCTYPE html>" in html
    assert "<canvas" in html
    assert "Engine_RPM" in html or "Vehicle_Speed" in html  # at least one signal


# ──────────────────────────────────────────────────────────────────────────────
# Test 7: PipelineConfig.dashboard_path integration (no CLI, direct API)
# ──────────────────────────────────────────────────────────────────────────────

@pytest.mark.skipif(not SAMPLE_DBC.exists(), reason="Sample DBC not available")
def test_pipeline_config_dashboard_path(tmp_path):
    """Passing dashboard_path directly to PipelineConfig must generate the file."""
    dash_path = tmp_path / "pipeline_dashboard.html"

    config = PipelineConfig(
        dbc_path=str(SAMPLE_DBC),
        log_path=str(SAMPLE_LOG),
        dashboard_path=str(dash_path),
    )
    result = UnifiedAnomalyPipeline(config).run()

    assert result.success is True
    assert dash_path.exists(), "dashboard_path must generate the HTML file"
    html = dash_path.read_text(encoding="utf-8")
    assert len(html) > 1000, "Generated HTML must have substantial content"


# ──────────────────────────────────────────────────────────────────────────────
# Test 8: No --dashboard flag → no file created, existing behavior unchanged
# ──────────────────────────────────────────────────────────────────────────────

@pytest.mark.skipif(not SAMPLE_DBC.exists(), reason="Sample DBC not available")
def test_no_dashboard_flag_unchanged_behavior(tmp_path):
    """Without --dashboard, the existing pipeline must work exactly as before."""
    config = PipelineConfig(
        dbc_path=str(SAMPLE_DBC),
        log_path=str(SAMPLE_LOG),
        # dashboard_path is None by default
    )
    result = UnifiedAnomalyPipeline(config).run()

    assert result.success is True
    # No HTML files should have been produced in tmp_path
    assert list(tmp_path.glob("*.html")) == []


# ──────────────────────────────────────────────────────────────────────────────
# Test 9: signals filter limits which signals appear in output
# ──────────────────────────────────────────────────────────────────────────────

def test_dashboard_signal_filter(tmp_path):
    """Passing signals=['Engine_RPM'] must include Engine_RPM but exclude
    Vehicle_Speed from the signal series (though anomaly_index may still contain it)."""
    out = tmp_path / "filtered.html"

    frames = []
    for i in range(5):
        ts = i * 0.1
        rpm = _make_signal("Engine_RPM", ts, float(i * 1000))
        spd = _make_signal("Vehicle_Speed", ts, float(i * 10), "km/h")
        frames.append(_make_decoded_frame(ts, {"Engine_RPM": rpm, "Vehicle_Speed": spd}))

    generate_dashboard_html(
        decoded_frames=frames,
        anomalies=[],
        summary=_dummy_summary(),
        metadata=_dummy_metadata(),
        output_path=str(out),
        signals=["Engine_RPM"],
    )

    assert out.exists()
    html = out.read_text(encoding="utf-8")
    assert '"Engine_RPM"' in html

    # Parse the embedded JSON payload by locating its object boundaries precisely
    payload_marker = "const PAYLOAD ="
    idx = html.find(payload_marker)
    assert idx > 0
    json_start = html.index("{", idx + len(payload_marker))

    # Walk through the HTML string counting braces to find the matching closing }
    depth = 0
    json_end = json_start
    in_string = False
    escape = False
    for i, ch in enumerate(html[json_start:], start=json_start):
        if escape:
            escape = False
            continue
        if ch == "\\" and in_string:
            escape = True
            continue
        if ch == '"' and not escape:
            in_string = not in_string
            continue
        if not in_string:
            if ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    json_end = i + 1
                    break

    payload = json.loads(html[json_start:json_end])
    assert "Engine_RPM" in payload["signals"]
    assert "Vehicle_Speed" not in payload["signals"], (
        "Filtered-out signal must not appear in payload['signals']"
    )
